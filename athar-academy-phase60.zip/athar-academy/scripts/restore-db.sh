#!/usr/bin/env bash
# Restore a PostgreSQL custom-format backup into a dedicated, EMPTY database.
set -euo pipefail
if [[ $# -ne 1 || ! -f "$1" ]]; then echo 'Usage: scripts/restore-db.sh /path/to/backup.dump' >&2; exit 2; fi
if [[ -z "${DATABASE_URL:-}" ]]; then echo 'DATABASE_URL is required' >&2; exit 2; fi
if [[ "${CONFIRM_RESTORE:-}" != 'RESTORE_TO_EMPTY_DATABASE' ]]; then echo 'Set CONFIRM_RESTORE=RESTORE_TO_EMPTY_DATABASE after confirming target is empty' >&2; exit 2; fi
command -v pg_restore >/dev/null || { echo 'pg_restore is required' >&2; exit 2; }
command -v psql >/dev/null || { echo 'psql is required' >&2; exit 2; }
# Refuse to overwrite an existing application schema, even when confirmed.
existing=$(psql "$DATABASE_URL" -X -A -t -v ON_ERROR_STOP=1 -c "SELECT COUNT(*) FROM pg_tables WHERE schemaname='public' AND tablename <> '_prisma_migrations'")
if [[ "$existing" != '0' ]]; then echo 'Target database contains tables. Restore refused.' >&2; exit 1; fi
pg_restore --no-owner --no-privileges --exit-on-error --single-transaction --dbname="$DATABASE_URL" "$1"
echo 'Restore finished. Run application smoke checks before accepting traffic.'
