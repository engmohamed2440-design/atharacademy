#!/usr/bin/env node
// Creates local development credentials only; never overwrites existing secrets.
import { existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
const root = resolve(import.meta.dirname, '..');
const dest = resolve(root, '.env');
if (existsSync(dest)) {
  console.error('.env already exists. Refusing to overwrite existing credentials.');
  process.exit(1);
}
const secret = () => randomBytes(36).toString('base64url');
const dbPassword = randomBytes(24).toString('hex');
const content = [
  '# LOCAL DEVELOPMENT ONLY. Never commit this file.',
  `DATABASE_URL="postgresql://athar:${dbPassword}@127.0.0.1:5432/athar?schema=public"`,
  `POSTGRES_PASSWORD="${dbPassword}"`,
  `SESSION_SECRET="${secret()}"`,
  `RATE_LIMIT_SECRET="${secret()}"`,
  'APP_ORIGIN="http://localhost:3000"',
  'TRUST_PROXY_HEADERS="false"',
  'AI_PRIMARY_PROVIDER="deepseek"',
  'DEEPSEEK_MODEL="deepseek-chat"',
  'GEMINI_MODEL="gemini-2.5-flash"',
  'DEEPSEEK_API_KEY=""',
  'GEMINI_API_KEY=""',
  '# For first-time admin creation, set these temporarily before npm run db:seed:',
  '# BOOTSTRAP_ADMIN_EMAIL=""',
  '# BOOTSTRAP_ADMIN_PASSWORD=""',
  ''
].join('\n');
writeFileSync(dest, content, {flag:'wx', mode:0o600});
console.log('Created private .env with unique local PostgreSQL and application secrets.');
console.log('Next: docker compose up -d; npm install; npm run db:baseline (only if missing); npm run db:migrate');
