#!/usr/bin/env node
// Non-destructive post-deployment probe. Does not create users or modify data.
const base = process.env.APP_ORIGIN;
if (!base) { console.error('APP_ORIGIN is required'); process.exit(2); }
let origin;
try { origin = new URL(base); } catch { console.error('APP_ORIGIN must be a URL'); process.exit(2); }
if (!['http:', 'https:'].includes(origin.protocol)) { console.error('Unsupported protocol'); process.exit(2); }
if (process.env.NODE_ENV === 'production' && origin.protocol !== 'https:') { console.error('Production requires HTTPS'); process.exit(2); }
let failures = 0;
async function check(path, acceptable) {
  try {
    const response = await fetch(new URL(path, origin), { redirect: 'manual', signal: AbortSignal.timeout(10000), headers: { Accept: 'application/json' } });
    const pass = acceptable.includes(response.status);
    console.log(`${pass ? 'PASS' : 'FAIL'} ${path}: HTTP ${response.status}`);
    if (!pass) failures++;
  } catch (err) { failures++; console.error(`FAIL ${path}: ${err.message}`); }
}
await check('/api/health', [200]);
// Protected endpoint must reject unauthenticated access; never accept HTTP 200.
await check('/api/admin/exports/students', [401, 403]);
await check('/api/admin/codes', [401, 403, 405]);
process.exitCode = failures ? 1 : 0;
