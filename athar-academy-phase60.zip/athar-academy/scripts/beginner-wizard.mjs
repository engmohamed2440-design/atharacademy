#!/usr/bin/env node
/** Beginner-friendly local setup assistant. Does not transmit secrets or modify a DB without confirmation. */
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const cli = createInterface({ input: stdin, output: stdout });
const onWindows = process.platform === 'win32';
const npm = onWindows ? 'npm.cmd' : 'npm';
const node = process.execPath;
function run(command, args) {
  console.log(`\n> ${command} ${args.join(' ')}\n`);
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit', shell: onWindows && command === npm });
  if (result.error) console.error(`تعذر تنفيذ الأمر: ${result.error.message}`);
  else if (result.status !== 0) console.error(`الأمر انتهى بخطأ (رمز ${result.status}). انسخ الخطأ وأرسله للمطور بدون كلمات مرور.`);
  return !result.error && result.status === 0;
}
async function confirm(message) { return (await cli.question(`${message} اكتب نعم للتأكيد: `)).trim() === 'نعم'; }
async function main() {
  console.log('\n=== مساعد تشغيل أثر أكاديمي للمبتدئين ===');
  console.log('شغّل الخيارات بالترتيب. لا تشارك ملف .env أو روابط قاعدة البيانات.');
  console.log(`Node.js: ${process.version} | نظام التشغيل: ${process.platform}`);
  if (Number(process.versions.node.split('.')[0]) < 22) {
    console.error('يُفضّل تثبيت Node.js LTS إصدار 22 أو أحدث أولًا.');
    return;
  }
  while (true) {
    console.log('\n1) تجهيز ملف الإعدادات .env (مرة واحدة)');
    console.log('2) تثبيت الحزم npm install');
    console.log('3) إنشاء ملف Migration التأسيسي (بدون الاتصال بقاعدة البيانات)');
    console.log('4) فحص الإعدادات npm run doctor');
    console.log('5) تطبيق Migrations على قاعدة البيانات (يغير قاعدة البيانات)');
    console.log('6) تشغيل اختبارات الكود');
    console.log('7) تشغيل الموقع محليًا');
    console.log('8) اختبار بناء نسخة الإنتاج');
    console.log('0) خروج');
    const choice = (await cli.question('اختار رقم: ')).trim();
    if (choice === '0') break;
    switch (choice) {
      case '1':
        if (existsSync(resolve(root, '.env'))) console.log('ملف .env موجود بالفعل؛ لن يتم استبداله. افتحه باستخدام Notepad لتعديل DATABASE_URL.');
        else run(node, ['scripts/setup-local.mjs']);
        break;
      case '2': run(npm, ['install']); break;
      case '3': run(npm, ['run', 'db:baseline']); break;
      case '4': run(npm, ['run', 'doctor']); break;
      case '5':
        console.log('تنبيه: تأكد من DATABASE_URL والنسخ الاحتياطي ومراجعة ملفات SQL قبل المتابعة.');
        if (await confirm('هل تريد تطبيق Migrations على قاعدة البيانات المحددة في .env؟')) run(npm, ['run', 'db:migrate']);
        break;
      case '6': run(npm, ['test']); break;
      case '7':
        console.log('بعد بدء السيرفر افتح http://localhost:3000 . للإيقاف اضغط Ctrl+C.');
        run(npm, ['run', 'dev']); break;
      case '8': run(npm, ['run', 'build']); break;
      default: console.log('اختيار غير معروف.');
    }
  }
}
try { await main(); } catch (error) { console.error(error.message); process.exitCode = 1; } finally { cli.close(); }
