#!/usr/bin/env node
/** Fail-closed release verification. Never modifies a database or deploys. */
import { spawnSync } from 'node:child_process';
import { existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const steps = [
  ['Environment and dependencies', process.execPath, ['scripts/doctor.mjs']],
  ['Automated tests', process.execPath, ['--experimental-strip-types', '--test', 'tests/*.test.mjs']],
  ['Prisma schema validation', process.platform === 'win32' ? 'node_modules/.bin/prisma.cmd' : 'node_modules/.bin/prisma', ['validate']],
  ['Production build', process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build']],
];
const results=[];
const reportPath=resolve(root,'release-verification.json');
for(const [name, command, args] of steps){
  console.log(`\n=== ${name} ===`);
  // Tests need shell glob expansion on Windows; use npm test instead.
  const actualCommand = name==='Automated tests' ? (process.platform==='win32'?'npm.cmd':'npm') : command;
  const actualArgs = name==='Automated tests' ? ['test'] : args;
  const executable = command.startsWith('node_modules/') ? resolve(root,command) : actualCommand;
  const run = spawnSync(name==='Automated tests'?actualCommand:executable,actualArgs,{cwd:root,stdio:'inherit',shell:false,env:process.env});
  const passed = !run.error && run.status===0;
  results.push({name,passed,exitCode:run.status,error:run.error?.message});
  if(!passed){console.error(`STOP: ${name} failed. Fix this before continuing.`);break;}
}
const ready=results.length===steps.length && results.every(r=>r.passed);
const report={readyForDatabaseIntegration:ready,productionReady:false,checkedAt:new Date().toISOString(),results,remaining:['Apply reviewed migrations to a real PostgreSQL database','Run integration and browser tests','Perform security and load testing','Verify backups and deployment configuration']};
writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');
console.log(`\nReport: ${reportPath}`);
console.log(ready?'Local build gates passed; database and production checks remain.':'Release verification FAILED; project is not verified.');
process.exitCode=ready?0:1;
