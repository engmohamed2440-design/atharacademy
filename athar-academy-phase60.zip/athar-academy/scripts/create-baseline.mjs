#!/usr/bin/env node
/** Generate the initial migration on Windows/macOS/Linux without Bash.
 * No database connection is made. Never overwrites an existing baseline.
 */
import { existsSync, mkdirSync, openSync, closeSync, writeFileSync, unlinkSync, rmdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
export const baselineDir = resolve(root, 'prisma/migrations/202610310000_initial_baseline');
export const baselineFile = resolve(baselineDir, 'migration.sql');
export function generateBaseline({ cwd = root, runner = spawnSync, destination = baselineFile } = {}) {
  if (existsSync(destination)) throw new Error('Baseline already exists; refusing to overwrite it.');
  const cli = resolve(cwd, 'node_modules/prisma/build/index.js');
  if (!existsSync(cli)) throw new Error('Prisma CLI is missing. Run npm install first.');
  const schema = resolve(cwd, 'prisma/schema.prisma');
  if (!existsSync(schema)) throw new Error('Prisma schema is missing.');
  // Prisma 6 migrate diff supports --to-schema-datamodel; this does not touch the database.
  const result = runner(process.execPath, [cli, 'migrate', 'diff', '--from-empty', '--to-schema-datamodel', schema, '--script'], {
    cwd, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024,
  });
  if (result.error || result.status !== 0) throw new Error(`Prisma migration generation failed: ${result.error?.message ?? result.stderr ?? result.status}`);
  const sql = result.stdout?.trim();
  if (!sql || !/CREATE TABLE/i.test(sql)) throw new Error('Prisma produced an empty or unexpected baseline; nothing was written.');
  const dir = resolve(destination, '..');
  const createdDir = !existsSync(dir);
  mkdirSync(dir, { recursive: true });
  try {
    // wx prevents clobbering a concurrent baseline generation.
    const fd = openSync(destination, 'wx', 0o600);
    try { writeFileSync(fd, `${sql}\n`, 'utf8'); } finally { closeSync(fd); }
  } catch (error) {
    if (createdDir) { try { rmdirSync(dir); } catch { /* preserve other files */ } }
    throw error;
  }
  return destination;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    console.log(`Generated initial migration: ${generateBaseline()}`);
    console.log('Review the SQL before running npm run db:migrate.');
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
