#!/usr/bin/env node
// Offline project diagnostic. Does not connect to or mutate a database.
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'..');
const failures=[];const warnings=[];const passed=[];
const path=(...p)=>resolve(root,...p);
const check=(condition,description,critical=true)=>{(condition?passed:critical?failures:warnings).push(description);};
const pkg=JSON.parse(readFileSync(path('package.json'),'utf8'));
check(Boolean(pkg.scripts?.build && pkg.scripts?.['db:migrate'] && pkg.scripts?.test),'Build, migration and test commands present');
check(existsSync(path('node_modules','.bin','next')),'Next.js dependencies installed');
check(existsSync(path('node_modules','.bin','prisma')),'Prisma CLI installed');
const dirs=existsSync(path('prisma','migrations'))?readdirSync(path('prisma','migrations')).filter(d=>existsSync(path('prisma','migrations',d,'migration.sql'))).sort():[];
check(dirs.some(d=>/initial|baseline/i.test(d)),'Initial database migration exists');
check(dirs.every((d,i)=>i===0 || d>dirs[i-1]),'Migration names ordered');
check(existsSync(path('prisma','schema.prisma')),'Prisma schema exists');
const envFile=path('.env');
check(existsSync(envFile),'Local .env exists');
const vars={...process.env};
if(existsSync(envFile)) for(const line of readFileSync(envFile,'utf8').split(/\r?\n/)) {
 const m=line.match(/^([A-Z_][A-Z_0-9]*)=(.*)$/);
 if(m && !vars[m[1]]) vars[m[1]]=m[2].trim().replace(/^(['"])(.*)\1$/,'$2');
}
for(const key of ['DATABASE_URL','APP_ORIGIN','SESSION_SECRET','RATE_LIMIT_SECRET'])check(Boolean(vars[key]),`${key} configured`);
for(const key of ['SESSION_SECRET','RATE_LIMIT_SECRET'])if(vars[key])check(vars[key].length>=32 && !/REPLACE|CHANGE_ME/i.test(vars[key]),`${key} length and placeholder check`);
if(vars.SESSION_SECRET && vars.RATE_LIMIT_SECRET)check(vars.SESSION_SECRET!==vars.RATE_LIMIT_SECRET,'Session and rate-limit secrets differ');
if(vars.DATABASE_URL)try{const u=new URL(vars.DATABASE_URL);check(['postgres:','postgresql:'].includes(u.protocol),'Database URL is PostgreSQL');}catch{failures.push('Database URL parses correctly');}
if(!vars.DEEPSEEK_API_KEY && !vars.GEMINI_API_KEY)warnings.push('AI provider key not configured (AI features disabled)');
const result={readyForBuild:failures.length===0,passed,failures,warnings};
console.log(JSON.stringify(result,null,2));
process.exitCode=failures.length?1:0;
