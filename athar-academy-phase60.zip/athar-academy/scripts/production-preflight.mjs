import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
const root = resolve(import.meta.dirname, '..');
const envPath = resolve(root, '.env');
if (existsSync(envPath)) for (const line of readFileSync(envPath,'utf8').split(/\r?\n/)) {
  const m = line.match(/^([A-Z_][A-Z_0-9]*)=(.*)$/);
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g,'');
}
const errors=[]; const warnings=[];
const get=k=>(process.env[k]||'').trim();
for(const key of ['DATABASE_URL','SESSION_SECRET','RATE_LIMIT_SECRET','APP_ORIGIN']) if(!get(key)) errors.push(`${key} is required`);
for(const key of ['SESSION_SECRET','RATE_LIMIT_SECRET']) if(get(key).length<32 || /REPLACE|CHANGE_ME|example|123456/i.test(get(key))) errors.push(`${key} must be a strong unique value (32+ characters)`);
if(get('SESSION_SECRET') && get('SESSION_SECRET')===get('RATE_LIMIT_SECRET')) errors.push('SESSION_SECRET and RATE_LIMIT_SECRET must be different');
try {const u=new URL(get('APP_ORIGIN')); if(u.protocol!=='https:' && !['localhost','127.0.0.1'].includes(u.hostname)) errors.push('APP_ORIGIN must use HTTPS outside localhost');} catch {errors.push('APP_ORIGIN is not a valid URL');}
try {const u=new URL(get('DATABASE_URL')); if(!['postgres:','postgresql:'].includes(u.protocol)) errors.push('DATABASE_URL must be PostgreSQL'); if(/CHANGE_ME|localhost:5432\/athar/.test(get('DATABASE_URL')) && process.env.NODE_ENV==='production') warnings.push('Review local/default DATABASE_URL');} catch {errors.push('DATABASE_URL is invalid');}
if(get('TRUST_PROXY_HEADERS')==='true') warnings.push('Ensure proxy overwrites X-Forwarded-For; never trust client-provided values');
if(!get('DEEPSEEK_API_KEY') && !get('GEMINI_API_KEY')) warnings.push('AI chat and quiz generation cannot work without at least one provider key');
const migrationDir=resolve(root,'prisma/migrations');
const migrations=existsSync(migrationDir)?(await import('node:fs')).readdirSync(migrationDir).filter(x=>existsSync(resolve(migrationDir,x,'migration.sql'))):[];
if(!migrations.some(x=>/baseline|initial/i.test(x))) errors.push('Initial schema migration missing: do not deploy migrations until a baseline is generated and reviewed');
if(!existsSync(resolve(root,'node_modules/.bin/next'))) errors.push('Dependencies not installed; npm ci / npm install required');
console.log(JSON.stringify({ready:errors.length===0,errors,warnings},null,2));
process.exitCode=errors.length?1:0;
