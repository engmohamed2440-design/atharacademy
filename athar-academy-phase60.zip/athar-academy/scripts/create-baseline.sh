#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -x node_modules/.bin/prisma ]]; then echo 'Install dependencies first: npm install' >&2; exit 1; fi
if [[ -e prisma/migrations/202610310000_initial_baseline/migration.sql ]]; then echo 'Baseline already exists; refusing overwrite' >&2; exit 1; fi
mkdir -p prisma/migrations/202610310000_initial_baseline
./node_modules/.bin/prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > prisma/migrations/202610310000_initial_baseline/migration.sql
if [[ ! -s prisma/migrations/202610310000_initial_baseline/migration.sql ]]; then echo 'Empty migration generated' >&2; exit 1; fi
printf '%s\n' 'Generated initial migration. Review SQL before running prisma migrate deploy.'
