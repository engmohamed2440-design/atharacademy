/** Safe, offline PostgreSQL connection configuration checks. Never prints credentials. */
export function inspectDatabaseUrl(value, { production = false } = {}) {
  const errors = [];
  const warnings = [];
  if (!value) return { ok: false, errors: ['DATABASE_URL is missing'], warnings };
  let u;
  try { u = new URL(value); } catch { return { ok: false, errors: ['DATABASE_URL is not a valid URL'], warnings }; }
  if (!['postgresql:', 'postgres:'].includes(u.protocol)) errors.push('DATABASE_URL must use postgresql:// or postgres://');
  if (!u.hostname || !u.username || !u.password || !u.pathname || u.pathname === '/') errors.push('Database host, user, password and database name are required');
  if (u.hash) errors.push('DATABASE_URL must not contain a fragment');
  if (/CHANGE_ME|REPLACE|YOUR_PASSWORD/i.test(u.password)) errors.push('Replace the placeholder database password');
  const hosted = !['localhost','127.0.0.1','::1','[::1]'].includes(u.hostname);
  if (hosted && !['require','verify-full','verify-ca'].includes(u.searchParams.get('sslmode'))) {
    (production ? errors : warnings).push('Hosted PostgreSQL should use sslmode=require (or stronger)');
  }
  if (/neon\.tech$/i.test(u.hostname) && /-pooler\./i.test(u.hostname)) {
    warnings.push('Neon pooled URL detected. For Prisma migrations use a direct (non-pooler) connection.');
  }
  if (production && !hosted) warnings.push('Local database URL detected in production');
  return { ok: errors.length === 0, errors, warnings, host: u.hostname, hosted };
}

if (process.argv[1] && import.meta.url === new URL(`file://${process.argv[1]}`).href) {
  const result = inspectDatabaseUrl(process.env.DATABASE_URL, { production: process.env.NODE_ENV === 'production' });
  console.log(JSON.stringify(result, null, 2));
  if (!result.ok) process.exitCode = 1;
}
