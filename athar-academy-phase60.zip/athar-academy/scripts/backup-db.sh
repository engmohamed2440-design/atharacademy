#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL must be set}"
: "${BACKUP_DIR:?Set BACKUP_DIR to a protected directory}"
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
file="$BACKUP_DIR/athar-$(date -u +%Y%m%dT%H%M%SZ).dump"
umask 077
pg_dump --format=custom --no-owner --no-acl --dbname="$DATABASE_URL" --file="$file"
echo "Backup created at $file; test restore in an isolated database."
