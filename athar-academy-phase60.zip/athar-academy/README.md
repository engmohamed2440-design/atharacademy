# ATHAR ACADEMY — مرحلة الأساس (غير جاهزة للإنتاج)

## المتطلبات
Node.js 22، PostgreSQL 16+، npm. لم يجر تثبيت التبعيات في بيئة إنشاء هذا الأرشيف بسبب عدم إتاحة اتصال npm.

## التشغيل
1. `npm install`
2. `cp .env.example .env` ثم اضبط DATABASE_URL وقيمة SESSION_SECRET عشوائية قوية.
3. `npx prisma migrate dev --name init` (ينشئ migration فعلية عند الاتصال بقاعدة البيانات).
4. `BOOTSTRAP_ADMIN_EMAIL=admin@example.org BOOTSTRAP_ADMIN_PASSWORD='choose-a-unique-strong-password' npm run db:seed` (استبدل القيم؛ لا تستخدم المثال في الإنتاج).
5. `npm run dev` ثم افتح http://localhost:3000.
6. `npm run test` و `npm run build`.

## الوظائف المنفذة مبدئيًا
Landing RTL، مخطط PostgreSQL Prisma، حسابات وجلسات مخزنة في DB، تفعيل أكواد لمرة واحدة بمعاملة، إصدار أكواد من endpoint خاص بالمدير، صفحة تسجيل دخول الفريق، لوحة مبسطة للطالب. جميعها تحتاج اختبار تشغيل بعد تثبيت التبعيات.

## قيود ومهام حرجة قبل الإطلاق
- لم يكتمل نظام دخول الطالب بعد التفعيل (يتطلب إضافة معرف دخول فريد واستعادة حساب آمنة).
- لا يوجد Rate Limiting موزع بعد؛ لا تنشر endpoint التفعيل قبل إضافته.
- لا يوجد CSRF protection شامل أو تحقق Origin، ولا حماية brute-force لتسجيل الدخول.
- لا توجد واجهة إصدار الأكواد، أو لوحة متابعة، أو AI، أو كويزات، أو RAG، أو دعم، أو إشعارات.
- يتطلب تصميم RLS/Authorization أوسع، سياسة خصوصية وموافقة ولي الأمر، تدقيق أمني واختبارات تكامل.
- `prisma/schema.prisma` هو مخطط أولي؛ migration لم تُنشأ بعد لعدم وجود PostgreSQL متصل.
- يجب إضافة عمليات تجديد/إلغاء الاشتراك، ضبط صلاحيات تصدير البيانات، تشفير البيانات الحساسة، وتخزين الملفات الآمن.

## النشر لاحقًا
استضافة Node.js مع PostgreSQL وHTTPS؛ ضبط الأسرار عبر مدير أسرار الاستضافة، تشغيل `npm run db:migrate` بعد إنشاء migrations، إعداد النسخ الاحتياطية، وتفعيل مراقبة الأخطاء دون تسجيل بيانات حساسة. لا تنشر هذا الإصدار علنًا.

## المرحلة الثانية — توسعة Backend (غير مختبرة تكامليًا)
- إضافة بريد إلكتروني لحساب الطالب عند التفعيل لتمكين تسجيل الدخول مجددًا.
- إضافة `APP_ORIGIN` للتحقق من Origin في طلبات الكتابة (يتطلب ضبط عنوان الإنتاج الصحيح).
- إضافة صلاحيات وصول لكل طالب، وقائمة طلاب عضو المتابعة مع pagination.
- إضافة إسناد الطلاب ونقلهم، المهام وتحديث حالتها وسجل التحديثات، وتقييمات المتابعة والملاحظات الداخلية.
- فصل ملاحظات المتابعة الداخلية عن التحديثات المعروضة للطالب.
- تم توسيع Prisma schema؛ **يجب إنشاء migration حقيقية** بعد الاتصال بـ PostgreSQL عبر `npm run db:dev -- --name phase2`.
- لا تزال هناك متطلبات إطلاق أساسية غير منجزة: rate limiting موزع، استرداد الحساب، تدقيق حماية CSRF، اختبارات DB حقيقية، واجهات الإدارة الكاملة، التشفير لبعض بيانات التواصل، AI، الاختبارات التعليمية، والدعم.

## المرحلة الثالثة — محادثات AI (تنفيذ أولي)
- تمت إضافة `/ai` وواجهات المحادثات وقاعدة بيانات AIConversation/AIMessage/AIUsageLog.
- إعداد DeepSeek من `DEEPSEEK_API_KEY` وGemini من `GEMINI_API_KEY`، واختيار المزود الأول من `AI_PRIMARY_PROVIDER=deepseek` أو `gemini`، واختيار الموديلات من `DEEPSEEK_MODEL` و`GEMINI_MODEL`.
- Fallback عند أخطاء الشبكة/429/5xx، ومهلة 20 ثانية، وحد 40 رسالة مستخدم لكل 24 ساعة (حد قاعدة بيانات تقريبي، وليس Rate Limit ذريًا آمنًا ضد الطلبات المتزامنة).
- يلزم تشغيل `npx prisma migrate dev --name ai_conversations` على قاعدة PostgreSQL متصلة. لم تُختبر طلبات المزودين الحقيقيين دون مفاتيح.
- **غير مكتمل:** RAG، رفع ملفات المنهج، إعدادات المزود من لوحة المدير، Markdown/KaTeX، إعادة التوليد والإبلاغ، اختبارات تكامل، وقفل الطلبات المتزامنة ومنع الإنفاق الزائد. لا تنشر هذه المرحلة في الإنتاج.

## المرحلة الرابعة: الاختبارات الذكية (تنفيذ أولي)

- الواجهة: `/quizzes`.
- `POST /api/quizzes` ينشئ اختبارًا باستخدام مزود AI مُعد مسبقًا، بحد أولي 5 اختبارات يوميًا (الحد غير ذري).
- `GET /api/quizzes` يسرد آخر 30 اختبارًا.
- `GET /api/quizzes/:id` يعرض الأسئلة والخيارات دون مفاتيح الإجابة.
- `POST /api/quizzes/:id/submit` يحفظ الإجابات ويصححها بمعاملة قاعدة بيانات، ثم يعرض الإجابات الصحيحة والتفسيرات.
- نموذج البيانات الجديد: Quiz, QuizQuestion, QuizAttempt, QuizAnswer.
- لتطبيق تغييرات المخطط محليًا بعد تهيئة PostgreSQL: `npm install && npx prisma migrate dev --name add_quizzes`.
- لم يتم تنفيذ migration فعلية أو اختبار اتصال حقيقي بقاعدة بيانات في هذه البيئة. لم يتم التحقق من build كامل.
- القيود الحالية: إعادة فتح اختبار مُسلّم لا تعرض النتيجة المحفوظة بعد، والأسئلة المفتوحة/الرقمية غير مدعومة، ولا يوجد تدقيق بشري للأسئلة المولدة. حد الإنشاء اليومي غير آمن ضد التزامن الشديد ويحتاج إلى Rate Limiting ذري قبل الإنتاج.


## المرحلة الخامسة (تنفيذ أولي)
تمت إضافة نماذج StudentFeedback وNotification وSupportTicket وSupportReply ومسارات API للتقييمات والإشعارات والدعم وإعدادات روابط التواصل. سياسة التقييم: تقييم واحد لكل طالب/عضو؛ لا توجد آلية تعديل. تتطلب هذه الإضافات `npx prisma migrate dev --name phase5` في بيئة PostgreSQL متصلة. لم يتم التحقق من بناء Next.js أو اتصال قاعدة البيانات أو اختبارات E2E. لا توجد رسائل واتساب/تيليجرام تلقائية.


## المرحلة السادسة — تقوية الأمان (قيد العمل)

- تمت إضافة `RATE_LIMIT_SECRET` (32 حرفًا عشوائيًا على الأقل) و`TRUST_PROXY_HEADERS` إلى `.env.example`.
- يحفظ الخادم محاولات تسجيل الدخول والتفعيل في `AuditLog` ويطبق حدًا مبدئيًا خلال 15 دقيقة. عند استخدام أكثر من نسخة من التطبيق يلزم **محدد معدل ذري** في البنية التحتية، لأن آلية العد الحالية ليست ذرية، وقد تؤثر الشبكات المشتركة على المستخدمين.
- نقطة `POST /api/sessions/revoke-others` تلغي جلسات الحساب الأخرى مع الاحتفاظ بالجلسة الحالية.
- لم تُنشأ migrations في قاعدة بيانات متصلة، ولم تنجح عملية تثبيت حزم npm في بيئة التنفيذ الحالية. لا تنشر التطبيق للاستخدام العام قبل تشغيل اختبارات تكامل وأمان حقيقية.

### خطوات التحقق في بيئة تتوفر فيها PostgreSQL و npm

```bash
npm install
cp .env.example .env
# اضبط DATABASE_URL و APP_ORIGIN و RATE_LIMIT_SECRET
npx prisma migrate dev --name initial
npx prisma generate
npm test
npm run build
```

لا تشغّل `prisma migrate dev` على قاعدة إنتاج؛ أنشئ migrations وراجعها في التطوير ثم استخدم `prisma migrate deploy` للإنتاج.

## تحديث المرحلة السابعة: واجهات الإدارة والمتابعة (2026-11-01)
- `/admin`: لوحة مدير محمية على الخادم، تعرض إحصائيات قاعدة البيانات وإسنادات الطلاب الأخيرة ونموذج إصدار أكواد الاشتراك؛ الأكواد الجديدة تظهر مرة واحدة في استجابة الإصدار.
- `/staff`: لوحة عضو متابعة محمية على الخادم، لا تسترجع إلا الطلاب المسندين للعضو الحالي، مع ملخص المهام.
- `/dashboard`: توجيه المدير والمتابع إلى لوحتهما.
- تم إضافة اختبارات بنيوية للتحقق من قيود الوصول في الصفحات الجديدة.
- **لم يتم** التحقق من `next build` أو إجراء اختبارات تكامل PostgreSQL؛ تثبيت npm لم يكتمل في بيئة التنفيذ. لم يتم إجراء نشر فعلي.
- ما زال يلزم تنفيذ صفحات إدارة الموظفين وإسناد الطلاب تفاعليًا، وتجهيز migrations واختبارات الصلاحيات والتزامن الحقيقية.

## Phase 8: إدارة الفريق (إضافة 2026-11-01)

- `/admin/team`: إنشاء أعضاء متابعة، عرض السعة وعدد الطلاب، البحث في الطلاب وإسنادهم.
- `GET/POST /api/admin/staff`: قراءة قائمة الأعضاء وإنشاء عضو جديد مع كلمة مرور bcrypt وسجل تدقيق.
- `GET /api/admin/students?page=1&q=...`: استرجاع الطلاب على صفحات (30 في الصفحة) للمدير فقط.
- الإسناد يستخدم المسار الموجود `/api/admin/assignments` ويغلق الإسناد السابق في transaction.

**قيود لم تُحل بعد:** لا توجد قاعدة PostgreSQL أو حزم npm مثبتة في بيئة التنفيذ؛ لم يتم تشغيل Prisma migrations أو فحص بناء Next.js. لا تستخدم هذا الإصدار في الإنتاج. إدارة تعطيل أعضاء الفريق، إعادة تعيين كلمات المرور الآمنة، التحقق من سعة العضو، والتعامل مع تعارضات الإسناد المتزامن تحتاج استكمالًا. إضافة حسابات أعضاء الفريق حاليًا تتطلب أن يسلم المدير كلمة المرور المؤقتة بطريقة آمنة؛ يجب بناء تدفق دعوات وإعادة تعيين قبل الإطلاق.

## المرحلة التاسعة — سلامة إسناد الطلاب (2026-11-01)
- يدعم `/api/admin/assignments` الإسناد والنقل وإلغاء الإسناد (`staffId: null`).
- يتم تسلسل التعديلات المتزامنة على الطالب بقفل PostgreSQL داخل transaction، مع منع الإسناد إلى عضو متابعة موقوف، وتسجيل التغيير في AuditLog.
- تمت إضافة migration جزئية لفهرس PostgreSQL فريد على الإسناد النشط للطالب. **تنبيه:** لا توجد حتى الآن baseline migration للجداول؛ لا تستخدم `prisma migrate deploy` على قاعدة فارغة قبل توليد baseline وفحصها. يجب تنظيف أي إسنادات نشطة مكررة قبل تطبيق الفهرس.
- نتيجة `npm test`: 37/37 اختبار بنيوي ناجح؛ لم يتم تنفيذ اختبارات PostgreSQL أو Next.js build أو اختبار مزودي AI.
- لا تضع بيانات طلاب حقيقية في هذا الإصدار حتى اكتمال التحقق الأمني والتشغيلي.

## Phase 10 — subscription access hardening (2026-11-01)
- Paid endpoints now check subscription start/end against server time AND require both subscription and activation code to be ACTIVE. Suspending or revoking a code therefore blocks paid access even if its subscription row still says ACTIVE.
- Staff/student authorization remains enforced in server handlers. Login email is normalized to lowercase consistently with activation and input lengths are bounded.
- Added `tests/subscription-policy.test.mjs` and `src/lib/subscription-policy.ts` (the policy helper is for future unit-level reuse; the active guard uses an equivalent database predicate).
- `npm test`: 41/41 structural tests passed. These do **not** replace integration, security, or browser tests.
- `npm install --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=12000` failed with `EAI_AGAIN` (npm registry DNS unavailable). `next build`, Prisma generation and PostgreSQL integration remain unverified.
- **Deployment blocker:** a complete baseline Prisma migration has not yet been generated; the existing assignment-integrity migration assumes the tables already exist. Generate and review the initial migration against a disposable PostgreSQL database before any deployment. Do not apply the current migration set to a new production database.

## Phase 11: operational hardening (2026-11-01)

Added `docker-compose.yml` for local PostgreSQL 16 (bound to 127.0.0.1 only), security response headers, and `/api/health` (checks database, returns HTTP 503 on failure). No external database or provider credentials are bundled. To run locally, copy `.env.example` to `.env`, set a strong `POSTGRES_PASSWORD` and matching `DATABASE_URL`, then run `docker compose up -d postgres` and `npm install`.

**Critical blocker:** The repository does not yet contain a complete initial Prisma migration; do not run `prisma migrate deploy` against a new production database expecting all tables to exist. After reviewing the Prisma schema and installing dependencies, generate the baseline with `npx prisma migrate dev --name initial_schema` in a fresh local development database. Review the SQL and reconcile the existing assignment-index migration before applying to production. No live database migration, Next build, or E2E run has been verified in this environment.

Security headers are baseline defense-in-depth, not a replacement for a full nonce-based CSP, independent penetration test, and review of personal data handling before admitting real students.

## Phase 12 — Quiz result persistence and access hardening

- `GET /api/quizzes/:id/result` returns answer explanations **only** when the authenticated student owns a submitted attempt. It requires a currently active subscription.
- Reopening a completed quiz now fetches its saved score and explanations instead of presenting a second submission flow.
- Quiz submission rejects duplicate question identifiers, foreign identifiers, and incomplete answer sets.
- Added structural tests for result authorization and response shape. These are not substitutes for database-backed integration tests.

**Release blocker:** Database baseline migrations, installed dependencies, end-to-end tests, and external AI connectivity have not been verified in this environment. Do not deploy to students until those checks pass.

## Phase 13 — behavioral subscription tests and policy drafts
- Added executable behavioral tests of subscription eligibility for every status, boundary dates, and month-end rollover, plus code generation checks. `npm test` uses Node 22 experimental TypeScript stripping; Node 22+ required for this test mode.
- Added `/privacy` and `/terms` draft pages and linked them from the landing page. These are **drafts**, not legally approved policies.
- Verified 65/65 tests pass locally (mostly static/structural; 14 new behavior tests). PostgreSQL migrations, Next.js build, integration/security tests, and live AI provider connectivity remain **unverified**. Do not launch with real student data yet.

## Production readiness gate (Phase 14)

**Not production ready yet.** Do not accept real student data until all checks pass.

1. Install dependencies (`npm install`; commit the resulting lockfile, then use `npm ci` in CI).
2. Set secrets privately in `.env`, never in Git. Run `npm run preflight` to see blockers.
3. Generate a **real initial SQL migration** with `npm run db:baseline` after installing Prisma. Review its SQL carefully, then run `npm run db:migrate` on a **fresh** database. Existing databases need a separately planned migration/baselining procedure; never blindly apply an initial migration to populated data.
4. Run `npx prisma validate`, `npx prisma generate`, `npx tsc --noEmit`, `npm run build`, and `npm test`.
5. Run authenticated integration tests against disposable PostgreSQL and browser E2E tests; verify role isolation, CSRF, subscription concurrency, session invalidation, quiz answer secrecy, file handling, and provider fallback. These tests are **not yet implemented or passed**.
6. Use a TLS-terminating reverse proxy, atomic external rate limiting, restricted database access, encrypted backups, monitoring, and a reviewed guardian/privacy consent flow before any real student onboarding.
7. Backups: with `DATABASE_URL` and `BACKUP_DIR` set, run `bash scripts/backup-db.sh` on a scheduled secure host. Test restores using `pg_restore` on a separate database. Retention and off-site encryption are operator responsibilities.

No live API provider, PostgreSQL migration, or production deployment was verified in this environment.

## Phase 15 — follow-up reassignment race protection

Follow-up assessment writes now acquire the same PostgreSQL per-student advisory transaction lock as staff reassignment, then recheck that the staff member is still assigned before writing an assessment or internal note. This prevents a reassigned staff member from committing a follow-up note after their access has been revoked in a concurrent transaction. Two new static regression tests were added. `npm test`: 70/70 passed in this environment. This does **not** replace live PostgreSQL concurrency tests, dependency installation, full build, baseline migration, RAG, or security review; the application is not production-ready.

## المرحلة 16 — حماية طلبات تغيير البيانات من CSRF

أضيف `src/middleware.ts` للتحقق من ترويسة `Origin` في جميع طلبات API غير القرائية، ومقارنتها بصورة صارمة بـ `APP_ORIGIN`. الطلبات التي لا تحتوي على Origin أو التي تأتي من موقع مختلف تُرفض بـ 403. هذا دفاع إضافي بجانب ملفات الارتباط `SameSite=Strict`؛ يجب ضبط `APP_ORIGIN` إلى عنوان HTTPS النهائي حرفيًا عند النشر. أدوات API غير المتصفحية يجب أن ترسل ترويسة Origin مطابقة عند إجراء عمليات تغيير. لا تستبدل هذه الحماية اختبارات الأمان أو مراجعة إعدادات الوكيل العكسي.

**حالة التحقق:** اختبارات بنيوية فقط. لم يُنفذ بناء Next.js أو اختبار متصفح أو اتصال قاعدة بيانات؛ حزم npm غير متوفرة محليًا.

## Phase 17 — audited, privacy-limited student CSV export

`GET /api/admin/exports/students?page=1` exports up to 500 students per page, for authenticated SUPER_ADMIN only. The export includes only internal student ID, display name, account active flag, creation timestamp and current staff ID; it deliberately excludes guardian contact details, internal notes, passwords and activation codes. Each successful export is written to AuditLog. The CSV formatter quotes all cells and neutralizes spreadsheet formula injection. Downloaded exports are sensitive; store them securely and delete when no longer required. No real database or browser integration test has been performed yet.

## Phase 18 — Operational verification and recovery

- `npm run smoke` runs non-destructive live HTTP checks against `APP_ORIGIN`. The check expects `/api/health` to succeed and admin exports to deny anonymous users. Run it against a staging deployment before production.
- `scripts/restore-db.sh backup.dump` restores a PostgreSQL custom-format backup **only into an empty database**, and only with `CONFIRM_RESTORE=RESTORE_TO_EMPTY_DATABASE`. Set `DATABASE_URL` privately in the environment. Test restores on staging; never run this against a populated production database.
- These scripts do **not** establish production readiness. A complete migration, successful dependency installation/build, DB integration tests, E2E testing, security review, and RAG/content moderation remain required.


## Phase 19 — curated knowledge excerpts (not full RAG)
Admin-only `POST /api/admin/knowledge` creates a text excerpt, `GET` lists it, and `PATCH /api/admin/knowledge/:id` changes approval. Only approved excerpts can be included in AI prompts. Retrieval uses basic PostgreSQL substring matching (not embeddings), up to three short excerpts. This does **not** support PDF/DOCX ingestion, semantic search, or citation verification; do not market it as complete RAG. Run Prisma schema migration before using these endpoints.

## المرحلة 20 — واجهة إدارة المعرفة
أضيفت صفحة `/admin/knowledge` للمدير الرئيسي، تتيح إضافة مراجع نصية كمسودات واعتمادها وإلغاء اعتمادها، مع ربطها بمسارات API الموجودة وتسجيل عمليات التغيير في Audit Logs. تعرض الصفحة آخر 30 مرجعًا. رفع PDF/DOCX والبحث الدلالي ومراجعة جودة الاسترجاع ما زالت غير مكتملة.

التحقق: `npm test` نجح في 88/88 اختبارًا، معظمها بنيوي. لم يتم تشغيل بناء Next.js أو اختبارات PostgreSQL أو مزودي AI في هذه البيئة. لا تنشر المشروع لطلاب حقيقيين قبل استكمال الاختبارات التشغيلية والأمنية.

## Phase 21 — Student portal and support inbox (2026-11-01)

- Student dashboard now reads real tasks, notifications, support tickets and assigned follow-up member from Prisma/PostgreSQL; it exposes actions for task status, notification read-state, creating support tickets, and submitting a one-time follow-up rating.
- Student support ticket detail and replies are connected to existing protected APIs. Staff support inbox lists recent tickets with server-side role verification.
- These features require the existing PostgreSQL schema, migrations, and secure sessions. They are not substitutes for database integration or security testing.
- `npm test`: 92/92 passing (mostly structural and unit checks). **No production build, connected PostgreSQL integration, or real AI provider test has been demonstrated.**
- IMPORTANT: `scripts/create-baseline.sh` generates a baseline migration from the *current* schema, and the existing assignment integrity migration needs reconciliation with that baseline before `prisma migrate deploy` is safe on a fresh database. Review and resolve migration ordering/duplication before deployment.

## المرحلة الثانية والعشرون — إدارة حالة طلبات الدعم
- `PATCH /api/support/:id/status` متاح حصريًا لموظف الدعم والمدير، مع فحص Origin والتحقق الصارم من `OPEN` أو `CLOSED`.
- تغيير الحالة يُنفذ بمعاملة قاعدة بيانات ويضيف سجل تدقيق؛ إعادة إرسال الحالة نفسها لا تنشئ سجلًا مكررًا.
- صفحة الطلب تعرض زر إغلاق/إعادة فتح لموظفي الدعم والمدير فقط، وتُخفي نموذج الرد عندما يكون الطلب مغلقًا.
- الاختبارات البنيوية: `npm test` نجح 95/95. **لم يتم** اختبار قاعدة PostgreSQL أو تشغيل بناء Next.js في هذه البيئة؛ لا تعتبر هذه المرحلة جاهزة للإنتاج.

### المرحلة 23 — سجل الطلاب الإداري
- `/admin/students`: بحث وصفحات تعرض حالة الحساب والاشتراك الحالي وعضو المتابعة.
- `/admin/students/[id]`: ملف الطالب مع آخر الاشتراكات والإسنادات والمهام، محمي بصلاحية SUPER_ADMIN.
- لا تُعرض كلمات المرور أو بيانات ولي الأمر في هذه الواجهات.
- اجتازت اختبارات `npm test` (98 اختبارًا)، لكن لم يتم التحقق من بناء Next.js أو تشغيل PostgreSQL في هذه البيئة.

## Phase 24 — Account password security

- `/account` is an authenticated account-security page for all roles.
- `POST /api/account/password` verifies request origin and current password, requires a different new password (12–128 characters), hashes it with bcrypt, conditionally updates the account to prevent concurrent overwrite, revokes existing sessions and issues a new cookie, and writes a password-change audit record.
- The student dashboard now links to account settings.
- `npm test` currently passes 101 tests, including three new structural checks. This does **not** replace database-backed integration testing.
- **Deployment remains blocked** pending an initial Prisma migration, dependency installation, a successful Next.js build, a live PostgreSQL test, and end-to-end security verification.

## Phase 25 — Neon / free PostgreSQL configuration

Neon is optional: the application remains PostgreSQL-compatible and does not require a specific hosting provider. In the Neon console create a database and obtain its **direct (non-pooled)** connection URL. Set `DATABASE_URL` in a private `.env` file (never commit it), with `sslmode=require`. URL-encode special characters in usernames/passwords. Run `npm run db:check-url` to validate URL syntax and TLS configuration **offline** without displaying the password. This check does not connect to Neon.

**Migration warning:** A complete initial migration has **not** been committed. Before running `npm run db:migrate` on a fresh database, install dependencies, generate/review the baseline using `npm run db:baseline`, and check the ordering of the existing partial unique-index migration. Test first on an empty staging database; never mark migrations applied without executing their SQL. Only then run `npm run db:migrate`, `npm run build`, and integration tests. No live Neon database was connected during this phase. Never send your DATABASE_URL, API keys, or session secrets in chat.

## Phase 26 — Student AI conversation privacy

- `DELETE /api/ai/conversations/:id` allows an authenticated, subscribed student to permanently delete **only their own** conversation. The scoped `deleteMany` mutation avoids authorization race conditions; Prisma cascades deletion of associated messages.
- The AI chat interface now provides a confirmation before deletion and clears the selected conversation's messages.
- Added four structural safety tests. These do not replace real PostgreSQL/Next.js integration tests.
- This operation does not erase AI usage logs or external AI provider retention; a full data-erasure workflow is still required before production.

## Phase 27 — local setup and honest readiness checks

From the project directory, on a machine with Node.js, npm and Docker installed:

```bash
npm run setup:local      # creates .env with secure random local credentials; never overwrites
npm install
npm run doctor           # checks prerequisites; expected to flag missing baseline initially
npm run db:baseline      # generate and REVIEW initial migration SQL before applying
# After verifying the migration and local .env credentials:
docker compose up -d
npm run db:migrate
npm run db:seed          # only after setting BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD
npm run dev
```

**Important:** The baseline migration is not shipped yet; generate it with the pinned Prisma CLI and review the SQL. Do not apply an unreviewed baseline to a populated database. The project has not passed a real Next.js build or database integration test in the development environment, because npm registry DNS resolution was unavailable. `npm run doctor` is a prerequisite diagnostic, **not** proof that the app is production-ready. Neon deployments must use their own secure `DATABASE_URL` and direct connection for migrations; `setup:local` is for local Docker only.

## Phase 28 — Windows-compatible initial database migration

`npm run db:baseline` now uses a Node.js script instead of Bash, so it works in
Windows PowerShell, macOS and Linux. After `npm install`, run it **once** to
produce `prisma/migrations/202610310000_initial_baseline/migration.sql` from the
Prisma schema. Inspect the generated SQL before running `npm run db:migrate`.
It refuses to overwrite an existing baseline and does not connect to a database.

**Windows + Neon:** use a non-pooled Neon `DATABASE_URL` with `sslmode=require`
for migration deployment. If you ran `npm run setup:local`, edit `.env` and
replace its local Docker `DATABASE_URL` with your private Neon connection URL.
Do not share or commit that URL. The setup script's local Docker password is
not a Neon credential. Database migration, actual Next.js build, and end-to-end
behavior still require verification on a machine with npm access and PostgreSQL.

### المرحلة 29 — حماية محاولات الدخول والتفعيل
- يعتمد الحد من المحاولات الآن على بصمة HMAC للبريد الإلكتروني (الدخول) أو كود التفعيل، حتى عند عدم تفعيل الثقة في ترويسات البروكسي؛ فلا يشترك كل المستخدمين خلف شبكة واحدة في حد عالمي.
- إذا كان `TRUST_PROXY_HEADERS=true` خلف بروكسي موثوق يضبط ترويسات العميل، يُفرض حد إضافي على عنوان IP، ولا تُحفظ عناوين IP أو البريد أو الأكواد كنص صريح في سجلات تحديد المعدل.
- تتم عمليات العد والتسجيل داخل معاملة PostgreSQL واحدة مع أقفال استشارية لكل هوية لتجنب تجاوز الحد بسبب الطلبات المتزامنة. لا يزال اختبار التكامل بقاعدة PostgreSQL حقيقية مطلوبًا.
- يتطلب هذا التغيير `RATE_LIMIT_SECRET` بطول 32 حرفًا على الأقل، كما كان مطلوبًا من قبل.

### المرحلة 30 — منع تجاوز حد الاختبارات بالتزامن
- أصبح فحص حد إنشاء 5 اختبارات خلال 24 ساعة وحفظ الاختبار داخل معاملة PostgreSQL واحدة بقفل استشاري خاص بالطالب؛ فلا يستطيع طلبان متزامنان تجاوز الحد عبر سباق العدّ.
- ما زال فحص الحد المبكر موجودًا لتجنب استدعاء الذكاء الاصطناعي عندما يكون الحد مستنفدًا، بينما الفحص داخل المعاملة هو المرجع النهائي.
- عند استنفاد الحد في أثناء التوليد ترجع الواجهة HTTP 429. قد تُستهلك تكلفة توليد الذكاء الاصطناعي قبل اكتشاف السباق؛ تقليل هذه التكلفة يتطلب نظام حجز حصص مسبقًا.
- نجحت الاختبارات المحلية البنيوية، لكن التحقق من سلوك القفل في PostgreSQL الحقيقية والبناء الكامل لم يتم بعد.

### Phase 31 — private response caching

`next.config.ts` applies `Cache-Control: private, no-store, max-age=0` and `X-Robots-Tag: noindex, nofollow, noarchive` to API endpoints and authenticated pages. Existing `src/middleware.ts` continues to enforce origin checks for API mutations. This reduces the risk of browser/proxy caching of student data. This is **not** an authorization mechanism; server-side role and ownership checks remain required. Validate these headers in a deployed environment with `curl -I` and test authenticated responses end to end.

### Phase 32 — atomic AI request quota

The AI messages endpoint now reserves each student request in a PostgreSQL transaction
with a per-student advisory lock before invoking the external AI provider. This
prevents concurrent requests from exceeding the 40-user-messages-per-rolling-24h
limit. Reservations are persisted as user messages and **failed provider requests
still count** against the limit to prevent unlimited paid retries. Conversation
ownership is rechecked inside the transaction, and the API returns HTTP 429 when
quota is exhausted. Database integration testing is still required to validate
transaction locking and the behavior of concurrent requests on real PostgreSQL.

### Phase 33: database schema readiness

`GET /api/health` verifies that PostgreSQL is reachable (`SELECT 1`).
`GET /api/health/ready` additionally verifies that essential application tables exist
and can be queried using Prisma. It returns HTTP 200 `{ "status": "ready" }`
when the schema is accessible, or HTTP 503 `{ "status": "unavailable" }` otherwise.
Neither endpoint proves all migrations are current, and neither reveals database
errors to anonymous callers. Use `npm run db:migrate` after reviewing the generated
baseline and setting the correct direct PostgreSQL connection URL.

## تشغيل مبسط على Windows (المرحلة 34)

للمبتدئين: اقرأ `START-HERE-AR.md` ثم شغّل `START-HERE-WINDOWS.bat` بالنقر المزدوج، أو استخدم `npm run easy`. المساعد يتيح تثبيت الحزم، إنشاء ملف البيئة، إنشاء Migration، فحص المشروع، تشغيل الاختبارات، بناء المشروع وتشغيل خادم التطوير. **لا يطبق أي Migration دون تأكيد صريح**، ولا يستبدل `.env` موجودًا.

### Phase 35 — AI API error handling
- AI conversation endpoints now use the shared error response handler instead of turning every failure into HTTP 403.
- Expired subscriptions return the existing HTTP 402 contract, while unauthorized requests return 403.
- AI message GET responses explicitly disable caching; message POST preserves the subscription status instead of misreporting a provider outage.
- The tests added here are static contract tests. A real Next.js build, Prisma migration and PostgreSQL integration test are **still required** before production use.

### Phase 36 — honest release verification (Windows supported)

After `npm install`, configuring `.env`, and generating/reviewing the initial migration,
run `npm run verify:release` in PowerShell. The command checks the local setup,
runs all automated tests, validates the Prisma schema, and builds Next.js. It stops
at the first failure and writes `release-verification.json` (a local report, not a
certificate). It **never** applies migrations or deploys. A passing result means
only the local build gates passed: real database integration, browser tests,
security/load testing, and backup/restore drills are still required. Never upload
`.env` or secret connection strings with the report.

## المرحلة 37 — جودة واجهات المستخدم

- صفحة تسجيل الدخول تدعم أدوار الطالب والمدير والمتابعة والدعم وتحوّل كل حساب للوحة المناسبة؛ تمنع النقر المتكرر وتعرض أخطاء الشبكة وتحديد المعدل بوضوح.
- صفحات عامة للأخطاء و404 والتحميل، وتحسين الوصول بلوحة المفاتيح وتقليل الحركة.
- معالجة نقص تفاصيل تصحيح سؤال الكويز دون انهيار الواجهة.
- اختبارات مسارات الأدوار، حالات الخطأ، وحماية واجهة نتائج الكويز.

**التحقق:** `npm test` نجح محليًا (152 اختبارًا). لم يتم التحقق من `npm run build` أو قاعدة بيانات PostgreSQL في هذه البيئة؛ لا تعتبر هذه النسخة جاهزة للإنتاج قبل نجاحهما واختبارات التكامل.

## المرحلة 38 — إدارة أعضاء المتابعة
- يمكن للمدير إيقاف/تفعيل عضو المتابعة من صفحة `/admin/team` وتعديل سعته المستهدفة.
- endpoint: `PATCH /api/admin/staff/:id` بمدخلات `active` أو `capacity`، مع حماية الصلاحيات وOrigin وسجل تدقيق.
- إيقاف الحساب ينهي جلساته الحالية. الإسنادات القائمة **لا تُحذف تلقائيًا**؛ يجب إعادة توزيع الطلاب يدويًا قبل إيقاف العضو لضمان استمرار المتابعة.
- تغيير السعة يُحفظ عند مغادرة حقل العدد (onBlur). السعة هدف تنظيمي وليست حدًا صارمًا.
- يلزم اختبار تفاعلي في المتصفح وPostgreSQL حقيقية قبل اعتماد هذه الوظيفة للإنتاج.

### المرحلة 39 — روابط التواصل
- من لوحة المدير افتح «إعدادات روابط التواصل» (`/admin/contact`).
- أضف روابط WhatsApp وTelegram الصحيحة واضغط حفظ. يمكن تركها فارغة لإخفائها من الصفحة الرئيسية.
- الإعدادات محفوظة في جدول `PlatformSetting`، ولا يستطيع تغييرها سوى المدير.
- تعرض الصفحة الرئيسية الروابط المخزنة عند توافر قاعدة البيانات. عند تعذر الاتصال، لا تظهر الروابط بدلاً من تعطيل الصفحة.
- تحقق من الروابط في المتصفح قبل مشاركة المنصة. لم يتم التحقق من بناء Next.js في بيئة التطوير هذه لعدم توافر الحزم المثبتة.

### المرحلة 40 — إدارة جلسات الحساب وتصدير الطلاب
- صفحة `/account` تحتوي الآن على زر لإنهاء الجلسات على الأجهزة الأخرى مع تأكيد ورسالة نتيجة. الجلسة الحالية لا تُلغى.
- صفحة `/admin/students` تعرض رابط تصدير CSV لأول 500 طالب. تصدير الصفحات الإضافية متاح من خلال `?page=2` وما بعدها. يجب التعامل مع ملفات CSV كبيانات شخصية وعدم نشرها.
- التحقق البنيوي لا يحل محل اختبار المتصفح وقاعدة البيانات الحقيقية.

### المرحلة 41 — سجل تدقيق المدير وتحسين تصدير الطلاب
- صفحة `/admin/audit` تعرض آخر أنشطة التدقيق على دفعات من 50، للمدير فقط، ولا تعرض معرفات الأهداف أو كلمات مرور أو رموز تفعيل.
- تمت إضافة رابط مباشر إلى سجل التدقيق من لوحة الإدارة.
- تصدير CSV من سجل الطلاب يحترم الآن البحث بالاسم، بدل تصدير كل الطلاب بغض النظر عن نتائج البحث. كل دفعة لا تتجاوز 500 صف.
- **تنبيه:** ما زال مطلوبًا تشغيل البناء وقاعدة البيانات واختبار الواجهات داخل المتصفح قبل اعتماد الإنتاج.


## المرحلة 42 — ملف الطالب لفريق المتابعة
- صفحة `/staff/students/[id]` محمية بعضوية فريق المتابعة وإسناد نشط للطالب.
- إضافة مهام وتسجيل تقييمات وملاحظات داخلية وتحديثات ظاهرة للطالب من واجهة فعلية عبر API.
- تظهر المهام والتقييمات الأخيرة، مع روابط من لوحة المتابعة.
- لا تزال اختبارات البناء وقاعدة البيانات والمتصفح مطلوبة قبل الإطلاق.

### المرحلة 43 — إدارة المراجع التعليمية

أصبحت واجهة المدير `/admin/knowledge` تدعم تعديل المرجع النصي وحذفه وتصفحه على صفحات من 30 مرجعًا، بالإضافة إلى الاعتماد وإلغاء الاعتماد. أي تعديل على بيانات المرجع يلغي اعتماده تلقائيًا حتى لا يستخدم المساعد نصًا معدلًا دون مراجعة. عمليات التعديل والحذف والاعتماد محمية بصلاحية المدير، وتُسجل في سجل التدقيق داخل معاملة قاعدة بيانات واحدة. حذف المرجع دائم؛ راجع النسخ الاحتياطية قبل حذف بيانات حقيقية.

الاختبارات الحالية لا تعني نجاح بناء Next.js أو الاتصال بقاعدة PostgreSQL؛ لا يزال مطلوبًا تنفيذ `npm install` و`npm run verify:release` على بيئة مكتملة.

## Phase 44 — public UI refresh

The public landing page now has a responsive Arabic RTL layout, accessible navigation, feature links to existing routes, a subscription CTA, and contact links controlled by administrator settings. Login and activation pages share improved form styling; activation now includes a login link and only renders an error alert when needed. Global styles improve keyboard focus, table readability and mobile layouts. No external images or frontend packages are required. **These are source-level improvements, not proof that all platform screens or backend flows have passed browser testing.**

### المرحلة 45 — تحسين تجربة الواجهات
- أضيف مكون `src/components/dashboard-nav.tsx` موحد لبطاقات التنقل في لوحتي المدير والطالب.
- تم تحسين حالات التركيز بلوحة المفاتيح، تجاوب بطاقات التنقل، حالات الضغط والتعطيل، وأسلوب الجداول والنماذج.
- التنقل يعتمد على روابط Next.js حقيقية للصفحات الموجودة، وليس أزرارًا شكلية.
- هذه تحسينات واجهة واختبارات بنيوية؛ لا تعني إثبات تشغيل قاعدة البيانات أو نجاح بناء Next.js.

### المرحلة 46 — تحسينات اللغة العربية وسهولة الاستخدام
- بقيت واجهات التطبيق باللغة العربية وباتجاه `rtl`، مع رابط «انتقل إلى المحتوى الرئيسي» لمستخدمي لوحة المفاتيح.
- زر «أعلى الصفحة» يظهر عند التمرير الطويل ويعمل دون أي طلب للشبكة.
- تحسين حقول البريد وكلمة المرور والمحتوى العربي، وتحسين الوصول إلى الأزرار على الموبايل.
- الاختبارات المضافة تتحقق من وجود الميزات في الكود، **ولا تثبت تشغيل المتصفح أو قاعدة البيانات**.


## تهيئة حساب المالك (Neon)

تم تحديد بريد المالك في `.env` ضمن `BOOTSTRAP_ADMIN_EMAIL`. لحماية الحساب لا تضع كلمة مرور سبق إرسالها في محادثة؛ أنشئ كلمة مرور جديدة فريدة لا تقل عن 16 حرفًا، وضعها محليًا فقط في `BOOTSTRAP_ADMIN_PASSWORD`. بعد ضبط `DATABASE_URL` وتشغيل الترحيلات (`npm run db:migrate`)، نفّذ `npm run db:seed` مرة واحدة لإنشاء حساب `SUPER_ADMIN`. يحفظ النظام تجزئة bcrypt لكلمة المرور في قاعدة البيانات، ولا تنشر `.env` أو ملف ZIP الذي يحتوي عليه. إذا كان هناك مالك سابق في قاعدة البيانات، فلن ينشئ seed حسابًا آخر.

### المرحلة 48 — تجربة محادثة مساعد أثر
- واجهة عربية RTL جديدة للمحادثة، وسجل المحادثات، ورسائل واضحة، واقتراحات للأسئلة، وزر نسخ الإجابات.
- إرسال Enter وسطر جديد Shift+Enter، واستعادة نص السؤال عند فشل الطلب، ومنع اختلاط الرسائل عند تغيير المحادثات أثناء الإرسال.
- تحسين الهاتف وإمكانية الوصول وحالات التحميل والخطأ. هذه التحسينات لا تعني اختبارًا فعليًا لمفاتيح مزودي AI أو Neon.

### المرحلة 49 — تحسين تجربة مساعد أثر
- بحث فوري في عناوين المحادثات السابقة دون إرسال استعلامات إضافية.
- زر للانتقال إلى أحدث رسالة عند تصفح محادثة طويلة.
- عدّاد أحرف لرسالة الطالب، وتحسين حالات التركيز بلوحة المفاتيح.
- الواجهة عربية RTL. لا تزال اختبارات المتصفح والتكامل الفعلي مع Neon ومزودي الذكاء الاصطناعي مطلوبة.

## مراجعة هندسية — المرحلة 50
- تم فصل المراجع التعليمية عن رسائل الطالب عند استدعاء DeepSeek/Gemini، مع توضيح أنها محتوى مرجعي وليس تعليمات.
- تم تحديد الحد الأقصى لنص استجابة المساعد بـ 16000 حرف قبل الحفظ.
- **لا تعتبر هذه التغييرات اعتمادًا للإنتاج:** لم يُنفذ `next build` أو اختبار تكامل فعلي مع Neon أو مزودي AI في بيئة التشغيل الحالية بسبب عدم تثبيت الاعتماديات.
- يلزم قبل النشر: إنشاء ومراجعة baseline migration، تشغيل `npm install` و`npm run build` و`npm run preflight`، ثم اختبار تسجيل الدخول والاشتراكات والاختبارات وAI على بيئة staging بمفاتيح خاصة بها.
- يجب تغيير أي كلمة مرور تمت مشاركتها في المحادثة وعدم إعادة استخدامها.

## المرحلة 51 — إصلاح سجل المساعد الذكي
- جلب أحدث 100 رسالة بترتيب عكسي من قاعدة البيانات ثم ترتيبها زمنيًا للعرض؛ تجنب عرض أقدم 100 رسالة في المحادثات الطويلة.
- تحديث عنوان المحادثة وتاريخ آخر نشاط داخل عملية حجز رسالة الطالب حتى لو فشل الاتصال بمزود الذكاء الاصطناعي.
- فحص بنيوي إضافي في `tests/ai-history-phase51.test.mjs`.
- لا تعني الاختبارات البنيوية نجاح تشغيل Next.js أو اتصال Neon/DeepSeek؛ يلزم اختبار تكاملي قبل الإنتاج.

### المرحلة 52 — واجهات الطالب وفريق المتابعة
- تصميم عربي RTL موحد للوحة الطالب والمتابعة، ببطاقات مؤشرات مستمدة من بيانات الحساب والمهام والإشعارات.
- إعادة تنظيم إجراءات الطالب والروابط الرئيسية وبطاقات الطلاب والمهام لدى فريق المتابعة.
- تحسين استجابة الصفحات للأجهزة الصغيرة وحالات الفراغ والوضوح البصري.
- نجحت اختبارات `npm test` (200 اختبار). لم يُنفذ بناء Next.js أو اختبار Neon في هذه البيئة.

## المرحلة 53 — تحسين صفحات الحساب
- تصميم عربي موحد لتسجيل الدخول وتفعيل الاشتراك، متجاوب مع الهاتف.
- إظهار وإخفاء كلمة المرور مع حالات التحميل والأخطاء وتحسينات الوصول.
- حدود إدخال كود التفعيل وكلمة المرور متوافقة مع مخطط واجهة API.
- اختبارات واجهة بنيوية جديدة في `tests/auth-ui-phase53.test.mjs`.
- هذه الاختبارات ليست بديلًا عن بناء Next.js وتشغيل المتصفح وقاعدة البيانات الفعلية.

### المرحلة 54 — تنسيق إجابات مساعد أثر
- عرض آمن للعناوين والقوائم والكتل البرمجية في إجابات المساعد، دون تحويل النص إلى HTML غير موثوق.
- دعم التمرير الأفقي للأكواد والحفاظ على اتجاه النص العربي RTL.
- اختبارات ثابتة إضافية؛ لا تغني عن اختبار البناء الفعلي وNeon وواجهات المتصفح.

### المرحلة 55 — مراجع إجابات مساعد أثر
- عرض عناوين المراجع التعليمية المعتمدة المرتبطة بإجابة المساعد عند وصول الرد، دون كشف نصوص المراجع الخام.
- تنسيق عربي RTL للمراجع داخل المحادثة.
- حاليًا لا تُحفظ بيانات الاستشهادات مع الرسالة عند إعادة تحميل سجل المحادثة؛ هذا تحسين لاحق.
- اجتازت الاختبارات البنيوية 207/207، ولم يتم التحقق من بناء Next.js أو الاتصال الفعلي بـ Neon ومزودي AI.

### المرحلة 56 — واجهة الكويزات العربية
- إعادة بناء صفحة `/quizzes` بتصميم عربي RTL متجاوب، مع اختيار المادة والوحدة والدرس والصعوبة وعدد الأسئلة.
- عرض الاختبارات السابقة ونتائجها، شريط تقدم الحل، تأكيد التسليم، وتصحيح مرئي مع شرح كل إجابة.
- الحفاظ على آلية التوليد والتصحيح وحماية مفاتيح الإجابة الموجودة في الخادم.
- الاختبارات البنيوية ناجحة، لكن التشغيل الفعلي باستخدام Neon وDeepSeek والبناء النهائي لم يتم التحقق منهما في هذه البيئة.

### المرحلة 57 — تحسين نظام الكويزات
- عرض إجمالي الاختبارات وعدد المكتملة ومتوسط نسبة النجاح في آخر 30 اختبارًا محملًا.
- البحث في سجل الاختبارات باسم المادة وتصفية المكتملة وغير المكتملة.
- التحقق من عدم تكرار نص السؤال أو خيارات الإجابة في الاختبار المولّد.
- لا تعني هذه التحسينات اعتماد التشغيل الإنتاجي؛ يلزم اختبار Next.js وقاعدة Neon ومزودي AI عمليًا.

### المرحلة 58 — التحقق من جودة الكويزات
- إضافة `src/lib/quiz-validation.mjs` للتحقق من الأسئلة المولدة قبل حفظها.
- أسئلة الاختيار المتعدد تتطلب أربعة اختيارات مختلفة، وأسئلة صح/خطأ تتطلب خيارين متقابلين واضحين.
- رفض الأسئلة المكررة بعد توحيد المسافات وحروف Unicode، والتحقق من نطاق الإجابة الصحيحة.
- تشغيل الاختبارات: `npm test` (216 اختبارًا ناجحًا في بيئة التطوير). هذا لا يغني عن بناء Next.js أو اختبار Neon وDeepSeek فعليًا.

### المرحلة 59 — تعزيز سلامة تسليم الاختبارات
- إضافة `src/lib/quiz-submission-validation.mjs` للتحقق من أن كل سؤال تمت الإجابة عنه مرة واحدة فقط، وأن المعرّفات تخص الاختبار، وأن اختيار الطالب يقع ضمن عدد خيارات السؤال الفعلي (خصوصًا صح/خطأ).
- تشغيل التحقق داخل معاملة تسليم الاختبار قبل التصحيح والحفظ؛ تظل مفاتيح الإجابات مخفية قبل التسليم.
- تصحيح استجابة أخطاء الخادم غير المتوقعة إلى HTTP 500 بدل تصنيفها خطأً كرفض صلاحيات 403، وتمييز انتهاء الاشتراك عن الخطأ الداخلي.
- الاختبارات البرمجية وحدها لا تثبت جاهزية الإنتاج؛ لا يزال يلزم اختبار البناء، Neon، والتفاعل داخل المتصفح.

### المرحلة 60 — تجربة المحادثة
- مسودات مستقلة للمحادثات، وإعادة استخدام سؤال سابق، وتحسين التمرير أثناء القراءة.
- قائمة جانبية للموبايل مع طبقة إغلاق، وتوحيد أسلوب الأزرار وفق هوية المنصة.
- الاختبارات الحالية هي اختبارات بنيوية/منطقية محلية؛ يجب تشغيل التطبيق وتجربة المتصفح وقاعدة Neon ومزودي AI قبل الإنتاج.
