import { NextRequest, NextResponse } from 'next/server';

/** Cookie-authenticated mutations must originate from the configured first-party site.
 * Fail closed when APP_ORIGIN is missing; never trust forwarded-host as an allowlist.
 */
export function middleware(request: NextRequest) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(request.method)) return NextResponse.next();
  const expected = process.env.APP_ORIGIN;
  const origin = request.headers.get('origin');
  if (!expected || !origin) return NextResponse.json({ error: 'الطلب غير مسموح' }, { status: 403 });
  try {
    const allowed = new URL(expected);
    const actual = new URL(origin);
    if (allowed.origin !== actual.origin || actual.origin !== origin) {
      return NextResponse.json({ error: 'الطلب غير مسموح' }, { status: 403 });
    }
  } catch {
    return NextResponse.json({ error: 'الطلب غير مسموح' }, { status: 403 });
  }
  return NextResponse.next();
}
export const config = { matcher: ['/api/:path*'] };
