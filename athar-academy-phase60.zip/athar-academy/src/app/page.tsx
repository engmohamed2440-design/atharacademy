import Link from 'next/link';
import {db} from '@/lib/db';
export const dynamic='force-dynamic';

const features=[
 {symbol:'✦',title:'مساعد أثر AI',description:'اسأل عن المفاهيم والدروس واحصل على مساعدة تعليمية تدعم مذاكرتك.',href:'/ai',action:'استكشف المساعد'},
 {symbol:'◈',title:'اختبارات تفاعلية',description:'اختبر فهمك، راجع إجاباتك وتابع مستوى تقدمك باستمرار.',href:'/quizzes',action:'اذهب للاختبارات'},
 {symbol:'◇',title:'متابعة منظمة',description:'تابع المهام والمواعيد والتوجيهات من خلال لوحة طالب واحدة.',href:'/dashboard',action:'لوحة الطالب'},
];
export default async function Home(){
 const rows=await db.platformSetting.findMany({where:{key:{in:['whatsappUrl','telegramUrl']}}}}).catch(()=>[]);
 const settings=Object.fromEntries(rows.map(r=>[r.key,r.value]));
 const whatsapp=typeof settings.whatsappUrl==='string'&&/^https:\/\/(wa\.me|api\.whatsapp\.com)\//.test(settings.whatsappUrl)?settings.whatsappUrl:null;
 const telegram=typeof settings.telegramUrl==='string'&&/^https:\/\/t\.me\//.test(settings.telegramUrl)?settings.telegramUrl:null;
 return <>
  <header className="site-header"><Link href="/" className="brand" aria-label="أثر أكاديمي — الرئيسية"><span className="brand-mark" aria-hidden="true">✦</span><span>أثر أكاديمي<small>ATHAR ACADEMY</small></span></Link><nav className="header-links" aria-label="التنقل الرئيسي"><a href="#features">مميزات المنصة</a><Link href="/login">تسجيل الدخول</Link><Link className="btn btn-sm" href="/activate">تفعيل الاشتراك</Link></nav></header>
  <main id="main-content">
   <section className="hero hero-premium"><div className="hero-orb" aria-hidden="true"/><div className="hero-content"><span className="eyebrow"><span className="eyebrow-dot"/> رحلة تعلم أوضح، خطوة بخطوة</span><h1>خلّي كل خطوة في مذاكرتك <span className="gold">تسيب أثر.</span></h1><p>مساحة واحدة تساعدك تنظم مذاكرتك، تراجع دروسك، تختبر نفسك وتتابع تقدمك بثقة خلال الثانوية العامة.</p><div className="actions"><Link className="btn" href="/activate">ابدأ بتفعيل اشتراكك <span aria-hidden="true">←</span></Link><Link className="btn outline" href="/login">عندي حساب بالفعل</Link></div><div className="hero-trust"><span>✧ تعلم منظم</span><span>✧ متابعة مستمرة</span><span>✧ اختبارات ومراجعة</span></div></div><div className="hero-art" aria-hidden="true"><div className="art-glow"/><div className="art-card art-card-main"><div className="art-label">لوحة مذاكرتك</div><div className="art-bars"><i/><i/><i/><i/><i/><i/><i/></div><div className="art-stat">كل خطوة بتفرق <span>↗</span></div></div><div className="art-card art-card-float">✦ <span>تعلّم على طريقتك</span></div></div></section>
   <section className="features-section" id="features"><div className="section-heading"><span className="eyebrow">كل أدواتك في مكان واحد</span><h2>ركّز على التعلّم، وسيب التنظيم علينا</h2><p>تجربة متكاملة تربط المذاكرة بالتدريب والمتابعة.</p></div><div className="grid feature-grid">{features.map(feature=><article className="card feature-card" key={feature.title}><div className="feature-icon" aria-hidden="true">{feature.symbol}</div><h3>{feature.title}</h3><p>{feature.description}</p><Link className="feature-link" href={feature.href}>{feature.action} <span aria-hidden="true">←</span></Link></article>)}</div></section>
   <section className="cta-section"><div><span className="eyebrow">جاهز تبدأ؟</span><h2>خطوتك الجاية تبدأ من هنا</h2><p>فعّل كود اشتراكك وابدأ رحلتك داخل أثر أكاديمي.</p></div><Link className="btn" href="/activate">تفعيل الاشتراك ←</Link></section>
  </main><footer className="site-footer"><div><strong>✦ أثر أكاديمي</strong><p>أثر في كل خطوة</p></div><div className="footer-links"><Link href="/privacy">سياسة الخصوصية</Link><Link href="/terms">شروط الاستخدام</Link>{whatsapp&&<a href={whatsapp} target="_blank" rel="noopener noreferrer">واتساب</a>}{telegram&&<a href={telegram} target="_blank" rel="noopener noreferrer">تيليجرام</a>}</div><small>المنصة قيد التطوير والاختبار.</small></footer></>;
}
