'use client';
import Link from 'next/link';
import {useState, type FormEvent} from 'react';

export default function Login(){
 const [message,setMessage]=useState('');
 const [busy,setBusy]=useState(false);
 const [showPassword,setShowPassword]=useState(false);
 const [capsLock,setCapsLock]=useState(false);
 async function submit(event:FormEvent<HTMLFormElement>){
  event.preventDefault();if(busy)return;
  setBusy(true);setMessage('');
  const data=Object.fromEntries(new FormData(event.currentTarget));
  try{
   const response=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),cache:'no-store'});
   const result=await response.json().catch(()=>({}));
   if(!response.ok){setMessage(response.status===429?'محاولات كثيرة، حاول مرة أخرى بعد 15 دقيقة':result.error||'تعذر تسجيل الدخول');return;}
   const {roleDestination}=await import('@/lib/role-destination.mjs');
   const destination=roleDestination(result.role);
   if(!destination){setMessage('نوع الحساب غير معروف، تواصل مع الدعم');return;}
   window.location.assign(destination);
  }catch{setMessage('تعذر الاتصال بالخادم. تحقق من اتصالك وحاول مرة أخرى.');}
  finally{setBusy(false);}
 }
 return <main className="auth-page" id="auth-login"><section className="auth-story" aria-label="مميزات أثر أكاديمي"><Link href="/" className="auth-brand"><span className="auth-brand-mark" aria-hidden="true">أ</span><span>أثر أكاديمي<small>ATHAR ACADEMY</small></span></Link><span className="auth-eyebrow">أثر في كل خطوة</span><h1>أهلًا بعودتك إلى <span>رحلتك التعليمية.</span></h1><p>مكان واحد لتنظيم المذاكرة، والتدرّب على الاختبارات، والتواصل مع فريق المتابعة.</p><div className="auth-story-points"><span>✦ مساعد ذكي للدراسة</span><span>✦ متابعة تقدمك</span><span>✦ اختبارات وتدريبات</span></div></section><section className="auth-card-wrap"><form className="auth-card" onSubmit={submit} aria-busy={busy}><span className="auth-eyebrow">حسابك في أثر أكاديمي</span><h2>تسجيل الدخول</h2><p className="auth-muted">أدخل بيانات حسابك للوصول إلى لوحة التحكم الخاصة بك.</p><label htmlFor="login-email">البريد الإلكتروني</label><input id="login-email" name="email" type="email" inputMode="email" autoComplete="username" maxLength={254} placeholder="name@example.com" dir="ltr" required disabled={busy}/><label htmlFor="login-password">كلمة المرور</label><div className="auth-password-field"><input id="login-password" name="password" type={showPassword?'text':'password'} autoComplete="current-password" required disabled={busy} onKeyUp={e=>setCapsLock(e.getModifierState('CapsLock'))} onKeyDown={e=>setCapsLock(e.getModifierState('CapsLock'))}/><button type="button" className="auth-reveal" onClick={()=>setShowPassword(v=>!v)} aria-label={showPassword?'إخفاء كلمة المرور':'إظهار كلمة المرور'} aria-pressed={showPassword} disabled={busy}>{showPassword?'إخفاء':'إظهار'}</button></div>{capsLock&&<p className="auth-hint">تنبيه: زر الحروف الكبيرة Caps Lock مفعّل.</p>}<button className="btn auth-submit" type="submit" disabled={busy}>{busy?'جارٍ تسجيل الدخول…':'الدخول إلى حسابي ←'}</button>{message&&<p role="alert" className="auth-error">{message}</p>}<div className="auth-bottom"><span>ليس لديك حساب؟ <Link href="/activate">فعّل اشتراكك</Link></span><Link href="/">الرئيسية</Link></div></form></section></main>;
}
