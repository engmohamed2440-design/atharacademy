import {redirect,notFound} from 'next/navigation';
import Link from 'next/link';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
import TicketReplies from './ticket-replies';
export default async function TicketPage({params}:{params:Promise<{id:string}>}){
 const user=await currentUser();if(!user)redirect('/login');if(!['STUDENT','SUPPORT','SUPER_ADMIN'].includes(user.role))notFound();
 const {id}=await params;const ticket=await db.supportTicket.findUnique({where:{id},include:{replies:{orderBy:{createdAt:'asc'}}}});if(!ticket)notFound();
 if(user.role==='STUDENT'){const student=await db.studentProfile.findUnique({where:{userId:user.id}});if(student?.id!==ticket.studentId)notFound()}
 return <main className="panel"><Link href="/dashboard">العودة إلى اللوحة</Link><h1>{ticket.subject}</h1><div className="card"><p>{ticket.message}</p><p>الحالة: {ticket.status}</p></div><TicketReplies ticketId={ticket.id} closed={ticket.status==='CLOSED'} canManage={user.role==='SUPPORT'||user.role==='SUPER_ADMIN'} initialReplies={ticket.replies.map(r=>({id:r.id,message:r.message,createdAt:r.createdAt.toISOString()}))}/></main>
}
