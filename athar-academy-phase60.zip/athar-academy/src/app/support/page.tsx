import {redirect} from 'next/navigation';
import Link from 'next/link';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
export default async function SupportIndex(){const user=await currentUser();if(!user)redirect('/login');if(!['SUPPORT','SUPER_ADMIN'].includes(user.role))redirect('/dashboard');const tickets=await db.supportTicket.findMany({take:50,orderBy:{updatedAt:'desc'},select:{id:true,subject:true,status:true,createdAt:true}});return <main className="panel"><h1>طلبات الدعم</h1><Link href="/dashboard">العودة</Link><div className="card">{tickets.length===0?<p>لا توجد طلبات دعم حاليًا.</p>:tickets.map(t=><Link key={t.id} href={`/support/${t.id}`} className="student-item"><strong>{t.subject}</strong><span>{t.status} — {t.createdAt.toLocaleDateString('ar-EG')}</span></Link>)}</div></main>}
