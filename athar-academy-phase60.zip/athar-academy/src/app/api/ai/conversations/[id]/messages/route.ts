import {db} from '@/lib/db';
import {requireActiveStudent,verifyOrigin} from '@/lib/guard';
import {answerWithFallback} from '@/lib/ai';
import {reserveAIMessage} from '@/lib/ai-quota';
import {findApprovedExcerpts,knowledgeContext} from '@/lib/knowledge';
import {NextResponse} from 'next/server';
import {errorResponse} from '@/lib/response';
import {z} from 'zod';
const input=z.object({content:z.string().trim().min(1).max(3000)});
async function owned(id:string,studentId:string){return db.aIConversation.findFirst({where:{id,studentId}});}
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){try{const {student}=await requireActiveStudent();const {id}=await params;if(!await owned(id,student.id))return NextResponse.json({error:'غير موجود'},{status:404});const items=await db.aIMessage.findMany({where:{conversationId:id},orderBy:[{createdAt:'desc'},{id:'desc'}],take:100,select:{id:true,role:true,content:true,createdAt:true}});return NextResponse.json({items:items.reverse()},{headers:{'Cache-Control':'no-store'}});}catch(error){return errorResponse(error);}}
export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){
 try{
  verifyOrigin(req);const {student}=await requireActiveStudent();const {id}=await params;
  if(!await owned(id,student.id))return NextResponse.json({error:'غير موجود'},{status:404});
  const parsed=input.safeParse(await req.json());if(!parsed.success)return NextResponse.json({error:'رسالة غير صالحة'},{status:400});
  const recent=await db.aIMessage.findMany({where:{conversationId:id},orderBy:[{createdAt:'desc'},{id:'desc'}],take:18});
  const history=[...recent].reverse().map(m=>({role:m.role as 'user'|'assistant',content:m.content}));
  await reserveAIMessage(student.id,id,parsed.data.content);
  const sources=await findApprovedExcerpts(parsed.data.content);
  const context=knowledgeContext(sources);
  const result=await answerWithFallback([...history,{role:'user',content:parsed.data.content}],async log=>{await db.aIUsageLog.create({data:{studentId:student.id,...log}});},{referenceContext:context});
  const message=await db.aIMessage.create({data:{conversationId:id,role:'assistant',content:result.text,provider:result.provider}});
  await db.aIConversation.update({where:{id},data:{updatedAt:new Date()}});
  return NextResponse.json({id:message.id,content:message.content,provider:result.provider,sources:sources.map(s=>({id:s.id,title:s.title}))});
 }catch(err){
  const code=err instanceof Error?err.message:'';
  if(code==='AI_DAILY_LIMIT')return NextResponse.json({error:'وصلت إلى الحد اليومي للمحادثات'},{status:429});
  if(code==='AI_CONVERSATION_NOT_FOUND')return NextResponse.json({error:'المحادثة غير موجودة'},{status:404});
  if(code==='SUBSCRIPTION_REQUIRED')return errorResponse(err);
  return NextResponse.json({error:code==='FORBIDDEN'?'غير مصرح':'تعذر إرسال الرسالة، حاول لاحقًا'},{status:code==='FORBIDDEN'?403:503});
 }
}
