import { db } from '@/lib/db';
import { requireActiveStudent, verifyOrigin } from '@/lib/guard';
import { NextResponse } from 'next/server';
import { errorResponse } from '@/lib/response';

/** Students can permanently delete only their own AI conversation and messages. */
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    verifyOrigin(req);
    const { student } = await requireActiveStudent();
    const { id } = await params;
    // A scoped delete prevents a time-of-check/time-of-use authorization race.
    const result = await db.aIConversation.deleteMany({ where: { id, studentId: student.id } });
    if (!result.count) return NextResponse.json({ error: 'المحادثة غير موجودة' }, { status: 404 });
    // AIMessage has onDelete:Cascade in Prisma, so its messages are deleted as well.
    return NextResponse.json({ deleted: true });
  } catch (error) {
    return errorResponse(error);
  }
}
