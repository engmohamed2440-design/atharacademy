import { db } from '@/lib/db';
import { requireActiveStudent, verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const { student } = await requireActiveStudent();
    const items = await db.aIConversation.findMany({
      where: { studentId: student.id }, orderBy: { updatedAt: 'desc' }, take: 40,
      select: { id: true, title: true, updatedAt: true },
    });
    return NextResponse.json({ items }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(req: Request) {
  try {
    verifyOrigin(req);
    const { student } = await requireActiveStudent();
    const item = await db.aIConversation.create({
      data: { studentId: student.id }, select: { id: true, title: true },
    });
    return NextResponse.json(item, { status: 201, headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return errorResponse(error);
  }
}
