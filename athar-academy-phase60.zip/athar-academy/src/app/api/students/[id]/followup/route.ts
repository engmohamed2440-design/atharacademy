import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { currentUser, requireRole } from '@/lib/auth';
import { verifyOrigin, requireStudentAccess } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const schema=z.object({rating:z.enum(['EXCELLENT','GOOD','NEEDS_FOLLOWUP','URGENT']),summary:z.string().max(2000).optional(),sharedUpdate:z.string().max(2000).optional(),internalNote:z.string().max(2000).optional(),nextReviewAt:z.string().datetime().optional()});
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){try{verifyOrigin(req);const {id}=await ctx.params;const user=await requireStudentAccess(id);if(user.role!=='FOLLOW_UP')throw new Error('FORBIDDEN');const staff=await db.staffProfile.findUniqueOrThrow({where:{userId:user.id}});const data=schema.parse(await req.json());await db.$transaction(async tx=>{
// Serialize assignment changes and follow-up writes for the same student.
await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id}, 0))`;
const assigned=await tx.studentStaffAssignment.findFirst({where:{studentId:id,staffId:staff.id,endedAt:null},select:{id:true}});
if(!assigned)throw new Error('FORBIDDEN');
await tx.followUpAssessment.create({data:{studentId:id,staffId:staff.id,rating:data.rating,summary:data.summary,sharedUpdate:data.sharedUpdate,nextReviewAt:data.nextReviewAt?new Date(data.nextReviewAt):undefined}});if(data.internalNote)await tx.internalNote.create({data:{studentId:id,staffId:staff.id,content:data.internalNote}})});return NextResponse.json({ok:true})}catch(e){return errorResponse(e)}}
export async function GET(_req:Request,ctx:{params:Promise<{id:string}>}){try{const {id}=await ctx.params;const user=await requireStudentAccess(id);const assessments=await db.followUpAssessment.findMany({where:{studentId:id},orderBy:{createdAt:'desc'},take:30,select:{id:true,rating:true,sharedUpdate:true,createdAt:true,...(user.role==='STUDENT'?{}:{summary:true,nextReviewAt:true})}});return NextResponse.json({assessments},{headers:{'Cache-Control':'no-store'}})}catch(e){return errorResponse(e)}}
