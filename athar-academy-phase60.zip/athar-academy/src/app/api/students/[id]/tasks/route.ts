import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { currentUser, requireRole } from '@/lib/auth';
import { verifyOrigin, requireStudentAccess } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const create=z.object({title:z.string().trim().min(2).max(160),description:z.string().max(2000).optional(),dueAt:z.string().datetime()});
export async function GET(_req:Request,ctx:{params:Promise<{id:string}>}){try{const {id}=await ctx.params;await requireStudentAccess(id);const tasks=await db.studentTask.findMany({where:{studentId:id},orderBy:{dueAt:'asc'},take:100});return NextResponse.json({tasks},{headers:{'Cache-Control':'no-store'}})}catch(e){return errorResponse(e)}}
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){try{verifyOrigin(req);const {id}=await ctx.params;const user=await requireStudentAccess(id);if(!['SUPER_ADMIN','FOLLOW_UP'].includes(user.role))throw new Error('FORBIDDEN');const data=create.parse(await req.json());const task=await db.studentTask.create({data:{studentId:id,title:data.title,description:data.description,dueAt:new Date(data.dueAt)}});return NextResponse.json({id:task.id},{status:201})}catch(e){return errorResponse(e)}}
