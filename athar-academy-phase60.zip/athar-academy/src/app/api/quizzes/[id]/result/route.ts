import {db} from '@/lib/db';
import {requireActiveStudent} from '@/lib/guard';
import {NextResponse} from 'next/server';

// Correct answers are disclosed only after the authenticated student's attempt is submitted.
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}) {
 try {
  const {student}=await requireActiveStudent();
  const {id}=await params;
  const attempt=await db.quizAttempt.findFirst({
   where:{quizId:id,studentId:student.id,submittedAt:{not:null},quiz:{studentId:student.id}},
   orderBy:{submittedAt:'desc'},
   include:{answers:true,quiz:{include:{questions:{orderBy:{position:'asc'}}}}}
  });
  if(!attempt)return NextResponse.json({error:'لا توجد محاولة مكتملة'},{status:404});
  const selected=new Map(attempt.answers.map(a=>[a.questionId,a.selectedIndex]));
  return NextResponse.json({score:attempt.score,total:attempt.total,submittedAt:attempt.submittedAt,
   details:attempt.quiz.questions.map(q=>({id:q.id,correctIndex:q.correctIndex,explanation:q.explanation,selectedIndex:selected.get(q.id)??null}))});
 } catch {return NextResponse.json({error:'غير مصرح'},{status:403});}
}
