import {db} from '@/lib/db';
import {requireActiveStudent} from '@/lib/guard';
import {NextResponse} from 'next/server';

export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}) {
 try {
  const {student}=await requireActiveStudent();
  const {id}=await params;
  const quiz=await db.quiz.findFirst({
   where:{id,studentId:student.id},
   include:{
    questions:{orderBy:{position:'asc'},select:{id:true,prompt:true,type:true,options:true,position:true}},
    attempts:{where:{studentId:student.id},orderBy:{startedAt:'desc'},select:{id:true,submittedAt:true,score:true,total:true}}
   }
  });
  if(!quiz)return NextResponse.json({error:'الاختبار غير موجود'},{status:404});
  return NextResponse.json(quiz);
 } catch {return NextResponse.json({error:'غير مصرح'},{status:403});}
}
