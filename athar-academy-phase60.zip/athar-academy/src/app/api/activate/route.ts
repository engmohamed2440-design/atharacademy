import { NextResponse } from 'next/server';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { hashCode,addMonthsUTC } from '@/lib/codes';
import { createSession } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { checkRateLimit } from '@/lib/rate-limit';
import { errorResponse } from '@/lib/response';
const schema=z.object({code:z.string().min(10).max(100),name:z.string().trim().min(2).max(100),email:z.string().email().max(254),password:z.string().min(12).max(128)});
export async function POST(req:Request){try {verifyOrigin(req);
 const {code,name,email,password}=schema.parse(await req.json());
 await checkRateLimit(req, 'ACTIVATION_ATTEMPT', code, 5);
 const passwordHash=await bcrypt.hash(password,12); const now=new Date();
 const user=await db.$transaction(async tx=>{
 const updated=await tx.subscriptionCode.updateMany({where:{codeHash:hashCode(code),status:'PENDING_ACTIVATION',intendedStudentId:null},data:{status:'ACTIVE',activatedAt:now,expiresAt:null}});
 if(updated.count!==1) throw new Error('INVALID_CODE');
 const subCode=await tx.subscriptionCode.findUniqueOrThrow({where:{codeHash:hashCode(code)}});
 await tx.subscriptionCode.update({where:{id:subCode.id},data:{expiresAt:addMonthsUTC(now,subCode.durationMonths)}});
 const account=await tx.user.create({data:{name,email:email.toLowerCase(),passwordHash,role:'STUDENT',student:{create:{}}},include:{student:true}});
 await tx.subscriptions.create({data:{studentId:account.student!.id,codeId:subCode.id,startsAt:now,endsAt:addMonthsUTC(now,subCode.durationMonths)}});
 await tx.auditLog.create({data:{actorId:account.id,action:'SUBSCRIPTION_ACTIVATED',targetType:'SubscriptionCode',targetId:subCode.id}});
 return account;
 });
 await createSession(user.id);return NextResponse.json({ok:true});
 }catch(e){return errorResponse(e)} }
