import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';
import { currentUser, tokenHash } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';

export async function POST(req: Request) {
  try {
    verifyOrigin(req);
    const user = await currentUser();
    if (!user) throw new Error('FORBIDDEN');
    const token = (await cookies()).get('athar_session')?.value;
    if (!token) throw new Error('FORBIDDEN');
    const current = tokenHash(token);
    const result = await db.session.deleteMany({ where: { userId: user.id, tokenHash: { not: current } } });
    await db.auditLog.create({ data: { actorId: user.id, action: 'OTHER_SESSIONS_REVOKED', targetType: 'Session' } });
    return NextResponse.json({ revoked: result.count });
  } catch (error) { return errorResponse(error); }
}
