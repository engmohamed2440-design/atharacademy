import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const schema=z.object({whatsappUrl:z.union([z.literal(''),z.string().url().refine(v=>new URL(v).hostname==='wa.me'||new URL(v).hostname==='api.whatsapp.com')]),telegramUrl:z.union([z.literal(''),z.string().url().refine(v=>new URL(v).hostname==='t.me')]),defaultMessage:z.string().max(500)});
const keys=['whatsappUrl','telegramUrl','defaultMessage'];
export async function GET(){try{await requireRole(['SUPER_ADMIN']);const settings=await db.platformSetting.findMany({where:{key:{in:keys}}});return NextResponse.json({settings:Object.fromEntries(settings.map(s=>[s.key,s.value]))})}catch(e){return errorResponse(e)}}
export async function PUT(req:Request){try{verifyOrigin(req);const user=await requireRole(['SUPER_ADMIN']);const data=schema.parse(await req.json());await db.$transaction(async tx=>{for(const [key,value] of Object.entries(data))await tx.platformSetting.upsert({where:{key},create:{key,value},update:{value}});await tx.auditLog.create({data:{actorId:user.id,action:'CONTACT_SETTINGS_UPDATED',targetType:'PlatformSetting'}})});return NextResponse.json({ok:true})}catch(e){return errorResponse(e)}}
