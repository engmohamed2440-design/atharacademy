import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';

const schema = z.object({
  studentId: z.string().min(1),
  staffId: z.string().min(1).nullable(), // null explicitly unassigns a student
});

export async function POST(req: Request) {
  try {
    verifyOrigin(req);
    const admin = await requireRole(['SUPER_ADMIN']);
    const { studentId, staffId } = schema.parse(await req.json());
    const result = await db.$transaction(async tx => {
      // Serialize concurrent assignment changes (including those targeting different staff)
      // for the same student. Staff capacity is a soft target, not a hard enrollment limit.
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${studentId}, 0))`;
      const student = await tx.studentProfile.findUnique({ where: { id: studentId } });
      if (!student) throw new Error('STUDENT_NOT_FOUND');
      if (staffId) {
        const staff = await tx.staffProfile.findUnique({
          where: { id: staffId }, include: { user: { select: { active: true, role: true } } },
        });
        if (!staff || !staff.user.active || staff.user.role !== 'FOLLOW_UP') throw new Error('STAFF_UNAVAILABLE');
      }
      const previous = await tx.studentStaffAssignment.findFirst({
        where: { studentId, endedAt: null }, orderBy: { startedAt: 'desc' },
      });
      if ((previous?.staffId ?? null) === staffId) return { changed: false };
      const now = new Date();
      await tx.studentStaffAssignment.updateMany({
        where: { studentId, endedAt: null }, data: { endedAt: now },
      });
      if (staffId) await tx.studentStaffAssignment.create({ data: { studentId, staffId, startedAt: now } });
      await tx.auditLog.create({
        data: {
          actorId: admin.id,
          action: staffId ? 'STUDENT_ASSIGNED' : 'STUDENT_UNASSIGNED',
          targetType: 'StudentProfile', targetId: studentId,
        },
      });
      return { changed: true };
    });
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    if (e instanceof Error && ['STUDENT_NOT_FOUND', 'STAFF_UNAVAILABLE'].includes(e.message)) {
      return NextResponse.json({ error: 'الطالب غير موجود أو عضو المتابعة غير متاح' }, { status: 422 });
    }
    return errorResponse(e);
  }
}
