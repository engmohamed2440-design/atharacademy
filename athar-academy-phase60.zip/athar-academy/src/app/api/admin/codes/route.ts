import { verifyOrigin } from '@/lib/guard';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { generateCode,hashCode } from '@/lib/codes';
import { errorResponse } from '@/lib/response';
const schema = z.object({months:z.union([z.literal(1),z.literal(2),z.literal(3),z.literal(12)]),count:z.number().int().min(1).max(100)});
export async function POST(req:Request) {try {verifyOrigin(req);
 const user=await requireRole(['SUPER_ADMIN']);
 const {months,count}=schema.parse(await req.json());
 const codes=Array.from({length:count},generateCode);
 await db.$transaction(async tx=>{for(const code of codes) await tx.subscriptionCode.create({data:{codeHash:hashCode(code),codeSuffix:code.slice(-5),durationMonths:months}});await tx.auditLog.create({data:{actorId:user.id,action:'CODES_CREATED',targetType:'SubscriptionCode'}})});
 return NextResponse.json({codes,note:'اعرض هذه الأكواد مرة واحدة واحفظها بأمان'},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return errorResponse(e)} }
