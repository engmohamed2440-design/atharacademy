import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { errorResponse } from '@/lib/response';
export async function GET(req:Request){try{await requireRole(['SUPER_ADMIN']);const url=new URL(req.url);const page=Math.max(1,Math.min(10000,Number(url.searchParams.get('page'))||1));const query=(url.searchParams.get('q')||'').trim().slice(0,80);const students=await db.studentProfile.findMany({where:query?{user:{name:{contains:query,mode:'insensitive'}}}:{},take:30,skip:(page-1)*30,orderBy:{user:{createdAt:'desc'}},select:{id:true,user:{select:{name:true,active:true}},assignments:{where:{endedAt:null},select:{staffId:true}}}});return NextResponse.json({students:students.map(s=>({id:s.id,name:s.user.name,active:s.user.active,staffId:s.assignments[0]?.staffId||null})),page,hasMore:students.length===30})}catch(e){return errorResponse(e)}}
