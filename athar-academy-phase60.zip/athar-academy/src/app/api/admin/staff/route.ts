import { NextResponse } from 'next/server';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const createSchema=z.object({name:z.string().trim().min(2).max(100),email:z.string().email().max(254),password:z.string().min(12).max(128),capacity:z.number().int().min(1).max(500).default(20)});
export async function GET(){try{await requireRole(['SUPER_ADMIN']);const members=await db.staffProfile.findMany({take:100,orderBy:{user:{createdAt:'desc'}},include:{user:{select:{name:true,email:true,active:true}},assignments:{where:{endedAt:null},select:{id:true}}}});return NextResponse.json({members:members.map(m=>({id:m.id,name:m.user.name,email:m.user.email,active:m.user.active,capacity:m.capacity,assigned:m.assignments.length}))})}catch(e){return errorResponse(e)}}
export async function POST(req:Request){try{verifyOrigin(req);const admin=await requireRole(['SUPER_ADMIN']);const data=createSchema.parse(await req.json());const passwordHash=await bcrypt.hash(data.password,12);const member=await db.$transaction(async tx=>{const user=await tx.user.create({data:{name:data.name,email:data.email.toLowerCase(),passwordHash,role:'FOLLOW_UP',staff:{create:{capacity:data.capacity}}}});await tx.auditLog.create({data:{actorId:admin.id,action:'STAFF_CREATED',targetType:'User',targetId:user.id}});return user});return NextResponse.json({id:member.id},{status:201})}catch(e){if(e instanceof Error && 'code' in e && e.code==='P2002')return NextResponse.json({error:'البريد الإلكتروني مستخدم بالفعل'},{status:409});return errorResponse(e)}}
