import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';

const schema = z.object({
  active: z.boolean().optional(),
  capacity: z.number().int().min(1).max(500).optional(),
}).strict().refine(value => value.active !== undefined || value.capacity !== undefined, 'No changes supplied');

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    verifyOrigin(req);
    const admin = await requireRole(['SUPER_ADMIN']);
    const { id } = await params;
    const input = schema.parse(await req.json());
    const result = await db.$transaction(async tx => {
      const staff = await tx.staffProfile.findUnique({ where: { id }, include: { user: { select: { role: true } } } });
      if (!staff || staff.user.role !== 'FOLLOW_UP') return null;
      if (input.capacity !== undefined) await tx.staffProfile.update({ where: { id }, data: { capacity: input.capacity } });
      if (input.active !== undefined) {
        await tx.user.update({ where: { id: staff.userId }, data: { active: input.active } });
        if (!input.active) await tx.session.deleteMany({ where: { userId: staff.userId } });
      }
      await tx.auditLog.create({ data: { actorId: admin.id, action: 'STAFF_UPDATED', targetType: 'StaffProfile', targetId: id } });
      return { ok: true };
    });
    if (!result) return NextResponse.json({ error: 'عضو المتابعة غير موجود' }, { status: 404 });
    return NextResponse.json(result, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) { return errorResponse(e); }
}
