import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { errorResponse } from '@/lib/response';
import { csvDocument } from '@/lib/csv';

// Explicitly exclude phone numbers, guardian details, secrets and internal notes.
// Hard cap prevents unbounded memory use and accidental mass disclosure.
export async function GET(req: Request) {
  try {
    const admin = await requireRole(['SUPER_ADMIN']);
    const url = new URL(req.url);
    const rawPage = url.searchParams.get('page') ?? '1';
    if (!/^[1-9]\d{0,3}$/.test(rawPage)) return Response.json({ error: 'صفحة غير صالحة' }, { status: 400 });
    const page = Number(rawPage);
    const q = (url.searchParams.get('q') ?? '').trim();
    if (q.length > 80) return Response.json({ error: 'البحث طويل جدًا' }, { status: 400 });
    const limit = 500;
    const students = await db.studentProfile.findMany({
      where: q ? { user: { name: { contains: q, mode: 'insensitive' } } } : {},
      take: limit,
      skip: (page - 1) * limit,
      orderBy: { id: 'asc' },
      select: {
        id: true,
        user: { select: { name: true, active: true, createdAt: true } },
        assignments: { where: { endedAt: null }, take: 1, select: { staffId: true } },
      },
    });
    await db.auditLog.create({ data: { actorId: admin.id, action: 'EXPORT_STUDENTS_CSV', targetType: 'STUDENT_LIST', targetId: `page:${page};rows:${students.length};filtered:${Boolean(q)}` } });
    const csv = csvDocument([
      ['student_id', 'name', 'account_active', 'created_at', 'assigned_staff_id'],
      ...students.map(s => [s.id, s.user.name, s.user.active, s.user.createdAt.toISOString(), s.assignments[0]?.staffId ?? '']),
    ]);
    return new Response(csv, { status: 200, headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="athar-students-${page}.csv"`,
      'Cache-Control': 'no-store, private',
      'X-Content-Type-Options': 'nosniff',
    } });
  } catch (e) { return errorResponse(e); }
}
