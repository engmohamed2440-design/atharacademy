import {db} from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {verifyOrigin} from '@/lib/guard';
import {errorResponse} from '@/lib/response';
import {NextResponse} from 'next/server';
import {z} from 'zod';

const editSchema=z.object({
 subject:z.string().trim().min(2).max(100),
 unit:z.string().trim().min(1).max(120),
 lesson:z.string().trim().min(1).max(160),
 title:z.string().trim().min(2).max(180),
 content:z.string().trim().min(30).max(10000)
}).strict();
const approvalSchema=z.object({approved:z.boolean()}).strict();
type Context={params:Promise<{id:string}>};

export async function GET(_req:Request,{params}:Context){
 try{
  await requireRole(['SUPER_ADMIN']);
  const {id}=await params;
  const item=await db.knowledgeExcerpt.findUnique({where:{id}});
  if(!item)return NextResponse.json({error:'المرجع غير موجود'},{status:404});
  return NextResponse.json({item},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return errorResponse(e)}
}

export async function PATCH(req:Request,{params}:Context){
 try{
  verifyOrigin(req);
  const actor=await requireRole(['SUPER_ADMIN']);
  const {id}=await params;
  const payload=await req.json();
  const edit=editSchema.safeParse(payload);
  const approval=approvalSchema.safeParse(payload);
  if(!edit.success&&!approval.success)return NextResponse.json({error:'بيانات غير صالحة'},{status:400});
  const updated=await db.$transaction(async tx=>{
   const current=await tx.knowledgeExcerpt.findUnique({where:{id}});
   if(!current)return null;
   // Every substantive edit requires fresh approval before AI retrieval.
   const data=edit.success?{...edit.data,approved:false}:approval.data!;
   const row=await tx.knowledgeExcerpt.update({where:{id},data});
   await tx.auditLog.create({data:{actorId:actor.id,action:edit.success?'KNOWLEDGE_EDITED':'KNOWLEDGE_APPROVAL_CHANGED',targetType:'KnowledgeExcerpt',targetId:id}});
   return row;
  });
  if(!updated)return NextResponse.json({error:'المرجع غير موجود'},{status:404});
  return NextResponse.json({item:updated});
 }catch(e){return errorResponse(e)}
}

export async function DELETE(req:Request,{params}:Context){
 try{
  verifyOrigin(req);
  const actor=await requireRole(['SUPER_ADMIN']);
  const {id}=await params;
  const deleted=await db.$transaction(async tx=>{
   const current=await tx.knowledgeExcerpt.findUnique({where:{id}});
   if(!current)return false;
   await tx.knowledgeExcerpt.delete({where:{id}});
   await tx.auditLog.create({data:{actorId:actor.id,action:'KNOWLEDGE_DELETED',targetType:'KnowledgeExcerpt',targetId:id}});
   return true;
  });
  if(!deleted)return NextResponse.json({error:'المرجع غير موجود'},{status:404});
  return NextResponse.json({ok:true});
 }catch(e){return errorResponse(e)}
}
