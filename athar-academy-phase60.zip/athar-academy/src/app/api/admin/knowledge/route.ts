import {db} from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {verifyOrigin} from '@/lib/guard';
import {errorResponse} from '@/lib/response';
import {NextResponse} from 'next/server';
import {z} from 'zod';
const input=z.object({subject:z.string().trim().min(2).max(100),unit:z.string().trim().min(1).max(120),lesson:z.string().trim().min(1).max(160),title:z.string().trim().min(2).max(180),content:z.string().trim().min(30).max(10000),approved:z.boolean().default(false)});
export async function GET(req:Request){try{await requireRole(['SUPER_ADMIN']);const url=new URL(req.url);const skip=Math.min(100000,Math.max(0,Number(url.searchParams.get('skip'))||0));const items=await db.knowledgeExcerpt.findMany({skip,take:30,orderBy:{createdAt:'desc'}});return NextResponse.json({items})}catch(e){return errorResponse(e)}}
export async function POST(req:Request){try{verifyOrigin(req);const actor=await requireRole(['SUPER_ADMIN']);const data=input.parse(await req.json());const row=await db.$transaction(async tx=>{const row=await tx.knowledgeExcerpt.create({data});await tx.auditLog.create({data:{actorId:actor.id,action:'KNOWLEDGE_CREATED',targetType:'KnowledgeExcerpt',targetId:row.id}});return row});return NextResponse.json({id:row.id},{status:201})}catch(e){return errorResponse(e)}}
