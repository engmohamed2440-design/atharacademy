import { verifyOrigin } from '@/lib/guard';
import { checkRateLimit } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from '@/lib/db';
import { createSession } from '@/lib/auth';
export async function POST(req:Request){try{verifyOrigin(req);
 const {email,password}=z.object({email:z.string().trim().email().max(254).transform(v=>v.toLowerCase()),password:z.string().min(1).max(256)}).parse(await req.json());
 await checkRateLimit(req, 'LOGIN_ATTEMPT', email);
 const user=await db.user.findUnique({where:{email}});
 if(!user || !user.active || !await bcrypt.compare(password,user.passwordHash)) return NextResponse.json({error:'بيانات الدخول غير صحيحة'},{status:401});
 await createSession(user.id);return NextResponse.json({role:user.role});
 }catch(e){const limited=e instanceof Error && e.message==='RATE_LIMITED';return NextResponse.json({error:limited?'محاولات كثيرة، حاول بعد 15 دقيقة':'تعذر تسجيل الدخول'},{status:limited?429:400})}}
