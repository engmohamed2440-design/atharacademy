import { NextResponse } from 'next/server';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
export async function GET(){const user=await currentUser();if(!user)return NextResponse.json({error:'يجب تسجيل الدخول'},{status:401});
 const profile=user.role==='STUDENT'?await db.studentProfile.findUnique({where:{userId:user.id},include:{subscription:{orderBy:{endsAt:'desc'},take:1}}}):null;
 return NextResponse.json({id:user.id,name:user.name,role:user.role,subscription:profile?.subscription[0]??null},{headers:{'Cache-Control':'no-store'}})}
