import { NextResponse } from 'next/server';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { currentUser, createSession } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';

const schema = z.object({
  currentPassword: z.string().min(1).max(256),
  newPassword: z.string().min(12).max(128),
}).refine(v => v.currentPassword !== v.newPassword, {message:'كلمة المرور الجديدة يجب أن تختلف عن الحالية'});

export async function POST(req: Request) {
  try {
    verifyOrigin(req);
    const user = await currentUser();
    if (!user) return NextResponse.json({error:'يجب تسجيل الدخول'}, {status:401});
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) return NextResponse.json({error:'تحقق من بيانات كلمة المرور (12 حرفًا على الأقل)'}, {status:400});
    const {currentPassword,newPassword} = parsed.data;
    if (!await bcrypt.compare(currentPassword,user.passwordHash)) {
      return NextResponse.json({error:'كلمة المرور الحالية غير صحيحة'}, {status:403});
    }
    const newHash = await bcrypt.hash(newPassword,12);
    // Conditional update prevents two concurrent changes from silently overwriting each other.
    const updated = await db.user.updateMany({where:{id:user.id,passwordHash:user.passwordHash,active:true},data:{passwordHash:newHash}});
    if (updated.count !== 1) return NextResponse.json({error:'تم تعديل بيانات الحساب، أعد المحاولة'}, {status:409});
    await db.session.deleteMany({where:{userId:user.id}});
    await db.auditLog.create({data:{actorId:user.id,action:'PASSWORD_CHANGED',targetType:'User',targetId:user.id}});
    await createSession(user.id);
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:'تعذر تغيير كلمة المرور'}, {status:400});
  }
}
