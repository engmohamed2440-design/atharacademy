import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const schema=z.object({subject:z.string().trim().min(3).max(160),message:z.string().trim().min(5).max(3000)});
export async function POST(req:Request){try{verifyOrigin(req);const user=await requireRole(['STUDENT']);const student=await db.studentProfile.findUniqueOrThrow({where:{userId:user.id}});const data=schema.parse(await req.json());const ticket=await db.supportTicket.create({data:{studentId:student.id,...data}});return NextResponse.json({id:ticket.id,status:ticket.status},{status:201})}catch(e){return errorResponse(e)}}
export async function GET(){try{const user=await requireRole(['STUDENT','SUPPORT','SUPER_ADMIN']);let where={};if(user.role==='STUDENT'){const student=await db.studentProfile.findUniqueOrThrow({where:{userId:user.id}});where={studentId:student.id}}const tickets=await db.supportTicket.findMany({where,select:{id:true,subject:true,status:true,createdAt:true,updatedAt:true},orderBy:{createdAt:'desc'},take:50});return NextResponse.json({tickets})}catch(e){return errorResponse(e)}}
