import {NextResponse} from 'next/server';
import {z} from 'zod';
import {db} from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {verifyOrigin} from '@/lib/guard';
import {errorResponse} from '@/lib/response';

const input=z.object({status:z.enum(['OPEN','CLOSED'])}).strict();

// Only support staff and administrators can change ticket state.
export async function PATCH(req:Request,{params}:{params:Promise<{id:string}>}){
 try{
  verifyOrigin(req);
  const user=await requireRole(['SUPPORT','SUPER_ADMIN']);
  const {id}=await params;
  const parsed=input.safeParse(await req.json());
  if(!parsed.success)return NextResponse.json({error:'INVALID_STATUS'},{status:400});
  const changed=await db.$transaction(async tx=>{
   const result=await tx.supportTicket.updateMany({where:{id,status:{not:parsed.data.status}},data:{status:parsed.data.status}});
   if(!result.count)return null;
   await tx.auditLog.create({data:{actorId:user.id,action:'SUPPORT_TICKET_STATUS',targetType:'SupportTicket',targetId:id}});
   return parsed.data.status;
  });
  if(!changed){
   const ticket=await db.supportTicket.findUnique({where:{id},select:{status:true}});
   if(!ticket)return NextResponse.json({error:'NOT_FOUND'},{status:404});
   return NextResponse.json({status:ticket.status,changed:false});
  }
  return NextResponse.json({status:changed,changed:true});
 }catch(e){return errorResponse(e)}
}
