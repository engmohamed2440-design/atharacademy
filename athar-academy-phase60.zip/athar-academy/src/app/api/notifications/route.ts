import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyOrigin } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
export async function GET(){try{const user=await requireRole(['STUDENT','FOLLOW_UP','SUPPORT','SUPER_ADMIN']);const notifications=await db.notification.findMany({where:{userId:user.id},orderBy:{createdAt:'desc'},take:50});return NextResponse.json({notifications},{headers:{'Cache-Control':'no-store'}})}catch(e){return errorResponse(e)}}
export async function PATCH(req:Request){try{verifyOrigin(req);const user=await requireRole(['STUDENT','FOLLOW_UP','SUPPORT','SUPER_ADMIN']);const {id}=z.object({id:z.string().min(1)}).parse(await req.json());const result=await db.notification.updateMany({where:{id,userId:user.id,readAt:null},data:{readAt:new Date()}});if(!result.count)return NextResponse.json({error:'NOT_FOUND'},{status:404});return NextResponse.json({ok:true})}catch(e){return errorResponse(e)}}
