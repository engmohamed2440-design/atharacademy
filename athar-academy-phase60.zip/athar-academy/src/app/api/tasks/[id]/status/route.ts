import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { currentUser, requireRole } from '@/lib/auth';
import { verifyOrigin, requireStudentAccess } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
const schema=z.object({status:z.enum(['TODO','IN_PROGRESS','DONE']),note:z.string().max(1000).optional()});
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){try{verifyOrigin(req);const {id}=await ctx.params;const task=await db.studentTask.findUnique({where:{id}});if(!task)throw new Error('INVALID');const user=await requireStudentAccess(task.studentId);const {status,note}=schema.parse(await req.json());await db.$transaction(async tx=>{await tx.studentTask.update({where:{id},data:{status}});await tx.taskUpdate.create({data:{taskId:id,actorId:user.id,status,note}})});return NextResponse.json({ok:true})}catch(e){return errorResponse(e)}}
