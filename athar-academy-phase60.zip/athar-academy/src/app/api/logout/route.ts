import { verifyOrigin } from '@/lib/guard';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';
import { tokenHash } from '@/lib/auth';
export async function POST(req:Request){verifyOrigin(req);const jar=await cookies();const token=jar.get('athar_session')?.value;if(token)await db.session.deleteMany({where:{tokenHash:tokenHash(token)}});jar.delete('athar_session');return NextResponse.json({ok:true})}
