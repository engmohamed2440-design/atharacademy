import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { currentUser, requireRole } from '@/lib/auth';
import { verifyOrigin, requireStudentAccess } from '@/lib/guard';
import { errorResponse } from '@/lib/response';
export async function GET(req:Request){try{const user=await requireRole(['FOLLOW_UP']);const staff=await db.staffProfile.findUniqueOrThrow({where:{userId:user.id}});const page=Math.min(100,Math.max(1,Number(new URL(req.url).searchParams.get('page')||1)));const assignments=await db.studentStaffAssignment.findMany({where:{staffId:staff.id,endedAt:null},skip:(page-1)*20,take:20,include:{student:{include:{user:{select:{id:true,name:true,active:true}},tasks:{select:{id:true,status:true,dueAt:true},take:5}}}}});return NextResponse.json({students:assignments.map(a=>({id:a.student.id,name:a.student.user.name,active:a.student.user.active,tasks:a.student.tasks})),page},{headers:{'Cache-Control':'no-store'}})}catch(e){return errorResponse(e)}}
