'use client';
import {useEffect} from 'react';
import Link from 'next/link';
export default function ErrorPage({error,reset}:{error:Error & {digest?:string};reset:()=>void}){
 useEffect(()=>{if(process.env.NODE_ENV==='development')console.error(error)},[error]);
 return <main className="system-state" role="alert"><h1>تعذر عرض الصفحة</h1><p>حدث خطأ غير متوقع. يمكنك إعادة المحاولة، أو العودة إلى الصفحة الرئيسية.</p><div className="actions"><button className="btn" onClick={()=>reset()}>إعادة المحاولة</button><Link className="btn outline" href="/">الصفحة الرئيسية</Link></div></main>;
}
