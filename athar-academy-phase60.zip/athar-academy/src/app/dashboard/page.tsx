import {redirect} from 'next/navigation';
import Link from 'next/link';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
import StudentTools from './student-tools';
import DashboardNav from '@/components/dashboard-nav';
export default async function Dashboard(){
 const user=await currentUser();if(!user)redirect('/login');if(user.role==='SUPER_ADMIN')redirect('/admin');if(user.role==='FOLLOW_UP')redirect('/staff');if(user.role==='SUPPORT')redirect('/support');
 const student=await db.studentProfile.findUnique({where:{userId:user.id},include:{subscription:{orderBy:{endsAt:'desc'},take:1},tasks:{orderBy:{dueAt:'asc'},take:30}}});if(!student)redirect('/login');
 const [notices,tickets,assignment]=await Promise.all([db.notification.findMany({where:{userId:user.id},orderBy:{createdAt:'desc'},take:30}),db.supportTicket.findMany({where:{studentId:student.id},orderBy:{createdAt:'desc'},take:30,select:{id:true,subject:true,status:true,createdAt:true}}),db.studentStaffAssignment.findFirst({where:{studentId:student.id,endedAt:null},include:{staff:{include:{user:true}}}})]);
 const feedbackExists=assignment?!!await db.studentFeedback.findUnique({where:{studentId_staffId:{studentId:student.id,staffId:assignment.staffId}},select:{id:true}}):false;
 const sub=student.subscription[0];const now=new Date();const active=!!sub&&sub.status==='ACTIVE'&&sub.startsAt<=now&&sub.endsAt>now;
 const completed=student.tasks.filter(t=>t.status==='DONE').length;
 const overdue=student.tasks.filter(t=>t.status!=='DONE'&&t.dueAt<now).length;
 const unread=notices.filter(n=>!n.readAt).length;
 return <>
 <header className="portal-topbar"><Link href="/dashboard" className="portal-brand"><span className="portal-brand-icon" aria-hidden="true">✦</span><span>أثر أكاديمي<small>مساحة الطالب</small></span></Link><nav className="portal-toplinks" aria-label="روابط الحساب"><Link href="/account">إعدادات الحساب</Link><Link className="btn outline btn-sm" href="/logout">تسجيل الخروج</Link></nav></header>
 <main className="panel portal-shell">
  <section className="portal-hero" aria-labelledby="student-greeting"><div><span className="portal-eyebrow">لوحة التحكم الدراسية</span><h1 id="student-greeting">أهلًا، {user.name} <span aria-hidden="true">✦</span></h1><p>خطوة صغيرة كل يوم تصنع أثرًا كبيرًا. اختر ما تريد إنجازه اليوم.</p><div className="portal-hero-actions"><Link className="btn" href="/ai">اسأل مساعد أثر الذكي <span aria-hidden="true">←</span></Link><Link className="btn outline" href="/quizzes">ابدأ اختبارًا جديدًا</Link></div></div><div className="portal-hero-art" aria-hidden="true"><span>أثر</span><small>في كل خطوة</small></div></section>
  <section className="portal-stat-grid" aria-label="ملخص نشاطك"><article className="portal-stat"><span>حالة الاشتراك</span><strong className={active?'portal-positive':'portal-warning'}>{active?'نشط':'غير نشط'}</strong><small>{sub?`ينتهي ${sub.endsAt.toLocaleDateString('ar-EG')}`:'لا يوجد اشتراك حالي'}</small></article><article className="portal-stat"><span>المهام المكتملة</span><strong>{completed}</strong><small>من أصل {student.tasks.length} مهمة معروضة</small></article><article className="portal-stat"><span>المهام المتأخرة</span><strong>{overdue}</strong><small>تحتاج إلى مراجعتك</small></article><article className="portal-stat"><span>إشعارات جديدة</span><strong>{unread}</strong><small>آخر تحديثات المنصة</small></article></section>
  <DashboardNav heading="ابدأ من هنا" items={[{href:'/ai',label:'مساعد أثر AI',description:'شرح الدروس ومراجعة الإجابات'},{href:'/quizzes',label:'الاختبارات',description:'تدرب على الأسئلة وتابع نتائجك'},{href:'/account',label:'أمان الحساب',description:'كلمة المرور والجلسات النشطة'}]}/>
  <section className="portal-content" aria-label="مهامك وإشعاراتك ودعمك"><StudentTools initialTasks={student.tasks.map(t=>({id:t.id,title:t.title,status:t.status,dueAt:t.dueAt.toISOString()}))} initialNotices={notices.map(n=>({id:n.id,title:n.title,body:n.body,readAt:n.readAt?.toISOString()??null}))} initialTickets={tickets.map(t=>({...t,createdAt:t.createdAt.toISOString()}))} staffName={assignment?.staff.user.name??null} feedbackExists={feedbackExists}/></section>
 </main></>;
}
