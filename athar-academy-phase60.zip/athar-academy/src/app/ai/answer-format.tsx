/** Safe, dependency-free rendering for common educational answer formatting.
 * Never interprets assistant output as HTML or executable Markdown.
 */
export default function AnswerFormat({content}:{content:string}){
 const parts=content.split(/(```[^\n]*\n[\s\S]*?```)/g);
 return <div className="athar-ai-formatted">{parts.map((part,i)=>{
  if(part.startsWith('```')&&part.endsWith('```')){
   const first=part.indexOf('\n');const language=part.slice(3,first).trim().slice(0,24);
   return <div className="athar-ai-code-wrap" key={i}><div className="athar-ai-code-head">{language||'نص برمجي'}</div><pre dir="ltr"><code>{part.slice(first+1,-3).trimEnd()}</code></pre></div>;
  }
  return part.split('\n').map((line,j)=>{
   const heading=line.match(/^(#{1,3})\s+(.+)$/);
   if(heading)return <p className="athar-ai-answer-heading" key={`${i}-${j}`}>{heading[2]}</p>;
   const bullet=line.match(/^\s*([-*•]|\d+[.)])\s+(.+)$/);
   if(bullet)return <p className="athar-ai-answer-list" key={`${i}-${j}`}><span aria-hidden="true">{bullet[1]}</span>{bullet[2]}</p>;
   return <p className="athar-ai-answer-line" key={`${i}-${j}`}>{line||'\u00a0'}</p>;
  });
 })}</div>;
}
