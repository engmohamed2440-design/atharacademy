'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import Link from 'next/link';
import AnswerFormat from './answer-format';

type Conversation={id:string;title:string};
type Message={id:string;role:string;content:string;sources?:{id:string;title:string}[]};
const suggestions=['اشرح لي درسًا من البداية بطريقة سهلة','ساعدني أعمل خطة مذاكرة للأسبوع','اختبرني في درس واختر أسئلة متنوعة','راجع إجابتي ووضح لي أخطائي'];
async function readResponse(response:Response){const body=await response.json().catch(()=>({}));if(!response.ok)throw new Error(typeof body.error==='string'?body.error:'تعذر الاتصال بالخدمة، حاول مرة أخرى');return body;}

export default function AIPage(){
 const [conversations,setConversations]=useState<Conversation[]>([]);
 const [active,setActive]=useState('');
 const [messages,setMessages]=useState<Message[]>([]);
 const [input,setInput]=useState('');
 const [busy,setBusy]=useState(false);
 const [loading,setLoading]=useState(true);
 const [loadingMessages,setLoadingMessages]=useState(false);
 const [error,setError]=useState('');
 const [copied,setCopied]=useState('');
 const [sidebarOpen,setSidebarOpen]=useState(false);
 const [search,setSearch]=useState('');
 const [showScroll,setShowScroll]=useState(false);
 const activeRef=useRef('');
 const endRef=useRef<HTMLDivElement>(null);
 const scrollRef=useRef<HTMLDivElement>(null);
 const inputRef=useRef<HTMLTextAreaElement>(null);
 const requestRef=useRef(0);
 const busyRef=useRef(false);
 const draftsRef=useRef<Record<string,string>>({});
 const [atBottom,setAtBottom]=useState(true);
 const visibleConversations=conversations.filter(c=>(c.title||'محادثة جديدة').toLocaleLowerCase('ar').includes(search.trim().toLocaleLowerCase('ar')));
 const refresh=useCallback(async()=>{try{const data=await readResponse(await fetch('/api/ai/conversations',{cache:'no-store'}));setConversations(data.items??[]);}catch(err){setError(err instanceof Error?err.message:'تعذر تحميل المحادثات');}finally{setLoading(false);}},[]);
 useEffect(()=>{void refresh();},[refresh]);
 useEffect(()=>{if(atBottom)endRef.current?.scrollIntoView({behavior:'smooth',block:'end'});},[messages,busy,atBottom]);
 async function select(id:string){if(busyRef.current)return;draftsRef.current[activeRef.current]=input;const token=++requestRef.current;activeRef.current=id;setActive(id);setInput(draftsRef.current[id]??'');setAtBottom(true);setMessages([]);setLoadingMessages(true);setError('');setSidebarOpen(false);try{const data=await readResponse(await fetch(`/api/ai/conversations/${encodeURIComponent(id)}/messages`,{cache:'no-store'}));if(token===requestRef.current)setMessages(data.items??[]);}catch(err){if(token===requestRef.current)setError(err instanceof Error?err.message:'تعذر تحميل المحادثة');}finally{if(token===requestRef.current)setLoadingMessages(false);}}
 async function create(){if(busyRef.current)return;draftsRef.current[activeRef.current]=input;setError('');try{const c=await readResponse(await fetch('/api/ai/conversations',{method:'POST'}));setConversations(prev=>[c,...prev]);++requestRef.current;activeRef.current=c.id;setActive(c.id);setMessages([]);setInput('');setAtBottom(true);setSidebarOpen(false);inputRef.current?.focus();}catch(err){setError(err instanceof Error?err.message:'تعذر إنشاء محادثة');}}
 async function removeConversation(id:string){if(busyRef.current||!window.confirm('هل تريد حذف هذه المحادثة ورسائلها نهائيًا؟'))return;try{await readResponse(await fetch(`/api/ai/conversations/${encodeURIComponent(id)}`,{method:'DELETE'}));setConversations(prev=>prev.filter(c=>c.id!==id));if(activeRef.current===id){++requestRef.current;activeRef.current='';setActive('');setInput('');setMessages([]);}}catch(err){setError(err instanceof Error?err.message:'تعذر حذف المحادثة');}}
 async function send(e?:React.FormEvent){e?.preventDefault();const content=input.trim(),id=activeRef.current;if(!content||busyRef.current||!id)return;busyRef.current=true;setBusy(true);setError('');setInput('');setAtBottom(true);const tempId=`temp-${Date.now()}`;setMessages(prev=>[...prev,{id:tempId,role:'user',content}]);try{const data=await readResponse(await fetch(`/api/ai/conversations/${encodeURIComponent(id)}/messages`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content})}));setMessages(prev=>[...prev,{id:data.id,role:'assistant',content:data.content,sources:Array.isArray(data.sources)?data.sources:[]}]);void refresh();}catch(err){setError(`${err instanceof Error?err.message:'تعذر إرسال الرسالة'} — تحقق من سجل المحادثة قبل إعادة الإرسال.`);try{const data=await readResponse(await fetch(`/api/ai/conversations/${encodeURIComponent(id)}/messages`,{cache:'no-store'}));setMessages(data.items??[]);setInput(content);}catch{setMessages(prev=>prev.filter(m=>m.id!==tempId));setInput(content);}}finally{busyRef.current=false;setBusy(false);inputRef.current?.focus();}}
 async function copyMessage(message:Message){try{await navigator.clipboard.writeText(message.content);setCopied(message.id);}catch{setError('تعذر النسخ، يمكنك تحديد النص ونسخه يدويًا.');}}
 return <main className="athar-ai" dir="rtl">
  {sidebarOpen&&<button type="button" className="athar-ai-scrim" aria-label="إغلاق قائمة المحادثات" onClick={()=>setSidebarOpen(false)}/>}
  <aside className={`athar-ai-sidebar ${sidebarOpen?'is-open':''}`} aria-label="سجل المحادثات">
   <div className="athar-ai-brand"><span className="athar-ai-mark" aria-hidden="true">✦</span><div><strong>مساعد أثر الذكي</strong><small>مساحتك للفهم والتعلّم</small></div></div>
   <button type="button" className="athar-ai-new" onClick={()=>void create()} disabled={busy}>＋ محادثة جديدة</button>
   <label className="athar-ai-search-label" htmlFor="athar-ai-search">ابحث في محادثاتك</label><input id="athar-ai-search" className="athar-ai-search" type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث بعنوان المحادثة…" autoComplete="off"/><div className="athar-ai-list-heading">المحادثات السابقة</div>
   <nav className="athar-ai-history" aria-label="المحادثات السابقة">{loading?<p className="athar-ai-muted">جاري تحميل المحادثات…</p>:conversations.length===0?<p className="athar-ai-muted">ابدأ محادثتك الأولى مع أثر.</p>:visibleConversations.length===0?<p className="athar-ai-muted">لا توجد محادثات تطابق البحث.</p>:visibleConversations.map(c=><div key={c.id} className={`athar-ai-history-row ${active===c.id?'selected':''}`}><button type="button" onClick={()=>void select(c.id)} disabled={busy} className="athar-ai-history-title" aria-current={active===c.id?'page':undefined} title={c.title}>{c.title||'محادثة جديدة'}</button><button type="button" className="athar-ai-delete" disabled={busy} onClick={()=>void removeConversation(c.id)} aria-label={`حذف المحادثة: ${c.title||'جديدة'}`} title="حذف المحادثة">×</button></div>)}</nav>
   <Link className="athar-ai-back" href="/dashboard">← العودة للوحة الطالب</Link>
  </aside>
  <section className="athar-ai-panel" aria-label="المحادثة مع مساعد أثر">
   <header className="athar-ai-header"><div className="athar-ai-header-title"><button type="button" className="athar-ai-menu" onClick={()=>setSidebarOpen(v=>!v)} aria-expanded={sidebarOpen} aria-label="فتح أو إغلاق قائمة المحادثات">☰</button><span className="athar-ai-avatar" aria-hidden="true">✦</span><div><h1>مساعد أثر AI</h1><p>مساعدك الدراسي باللغة العربية</p></div></div><span className="athar-ai-status"><span aria-hidden="true">●</span> {busy?'جاري إعداد الإجابة':'مساعد دراسي'}</span></header>
   <div ref={scrollRef} className="athar-ai-scroll" onScroll={e=>{const el=e.currentTarget;const far=el.scrollHeight-el.scrollTop-el.clientHeight>180;setShowScroll(far);setAtBottom(!far);}} role="log" aria-label="رسائل المحادثة" aria-live="polite" aria-relevant="additions text">
    {!active&&!loadingMessages?<div className="athar-ai-welcome"><span className="athar-ai-welcome-icon" aria-hidden="true">✦</span><h2>أهلًا بيك في مساعد أثر</h2><p>اسأل عن أي درس، اطلب شرحًا خطوة بخطوة، أو تدرب على أسئلة المنهج. المساعد يساعدك تفهم، مش تحفظ وبس.</p><button type="button" className="athar-ai-new athar-ai-welcome-start" onClick={()=>void create()}>ابدأ محادثة جديدة ←</button></div>:loadingMessages?<div className="athar-ai-center" role="status">جاري تحميل رسائل المحادثة…</div>:messages.length===0?<div className="athar-ai-welcome"><span className="athar-ai-welcome-icon" aria-hidden="true">✦</span><h2>إيه اللي تحب نتعلمه النهارده؟</h2><p>اختار فكرة للبدء أو اكتب سؤالك بنفسك.</p><div className="athar-ai-suggestions">{suggestions.map(s=><button key={s} type="button" onClick={()=>{setInput(s);inputRef.current?.focus();}}>{s} ↗</button>)}</div></div>:<div className="athar-ai-thread">{messages.map(m=><article key={m.id} className={`athar-ai-message ${m.role==='user'?'from-student':'from-assistant'}`}><div className="athar-ai-message-avatar" aria-hidden="true">{m.role==='user'?'أ':'✦'}</div><div className="athar-ai-message-body"><div className="athar-ai-message-label">{m.role==='user'?'أنت':'مساعد أثر'}</div><div className="athar-ai-message-text">{m.role==='assistant'?<AnswerFormat content={m.content}/>:m.content}</div>{m.role==='assistant'&&Boolean(m.sources?.length)&&<div className="athar-ai-sources" aria-label="مراجع الإجابة"><strong>مراجع تعليمية مرتبطة بالسؤال:</strong><ul>{m.sources?.map(source=><li key={source.id}>{source.title}</li>)}</ul></div>}{m.role==='user'&&<button type="button" className="athar-ai-copy" disabled={busy} onClick={()=>{setInput(m.content);inputRef.current?.focus();}} aria-label="استخدام هذا السؤال مرة أخرى">↺ إعادة استخدام السؤال</button>}{m.role==='assistant'&&<button type="button" className="athar-ai-copy" onClick={()=>void copyMessage(m)}>{copied===m.id?'✓ تم النسخ':'⧉ نسخ الرد'}</button>}</div></article>)}{busy&&<div className="athar-ai-thinking" role="status"><span className="athar-ai-thinking-dot"/> أثر بيجهّز ردًا مناسبًا لسؤالك…</div>}</div>}
    <div ref={endRef}/>
   </div>
   {showScroll&&<button className="athar-ai-scroll-bottom" type="button" onClick={()=>{setAtBottom(true);endRef.current?.scrollIntoView({behavior:'smooth',block:'end'});}} aria-label="الانتقال إلى أحدث رسالة">↓ أحدث رسالة</button>}
   <div className="athar-ai-compose"><div aria-live="assertive">{error&&<p className="athar-ai-error" role="alert">{error}</p>}</div><form onSubmit={e=>void send(e)} className="athar-ai-form"><textarea ref={inputRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();void send();}}} placeholder={active?'اكتب سؤالك هنا…':'ابدأ محادثة جديدة للكتابة…'} maxLength={3000} rows={2} disabled={!active||busy} aria-label="اكتب رسالتك لمساعد أثر"/><button type="submit" disabled={!active||busy||!input.trim()} aria-label="إرسال الرسالة">{busy?'انتظر…':'إرسال ←'}</button></form><div className="athar-ai-compose-meta"><span aria-live="off">{input.length} / 3000 حرف</span><span>محادثتك خاصة بحسابك</span></div><p className="athar-ai-disclaimer">Enter للإرسال • Shift + Enter لسطر جديد • راجع المعلومات المهمة من مصادر المنهج، فقد يخطئ الذكاء الاصطناعي.</p></div>
  </section>
 </main>;
}
