import Link from 'next/link';
export default function NotFound(){return <main className="system-state"><h1>الصفحة غير موجودة</h1><p>تأكد من الرابط أو ارجع للصفحة الرئيسية.</p><Link className="btn" href="/">الصفحة الرئيسية</Link></main>}
