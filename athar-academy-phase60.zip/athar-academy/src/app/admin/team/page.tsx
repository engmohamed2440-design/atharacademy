import { redirect } from 'next/navigation';
import Link from 'next/link';
import { currentUser } from '@/lib/auth';
import TeamClient from './team-client';
export const dynamic='force-dynamic';
export default async function TeamPage(){const user=await currentUser();if(!user)redirect('/login');if(user.role!=='SUPER_ADMIN')redirect('/dashboard');return <><header><div className="brand">أثر أكاديمي — إدارة الفريق</div><Link className="btn outline" href="/admin">لوحة المدير</Link></header><main className="panel"><h1>إدارة أعضاء المتابعة وتوزيع الطلاب</h1><TeamClient/></main></>}
