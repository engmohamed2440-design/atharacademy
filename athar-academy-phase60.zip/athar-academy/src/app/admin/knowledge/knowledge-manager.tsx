'use client';
import {useState} from 'react';
type Item={id:string,title:string,subject:string,unit:string,lesson:string,approved:boolean,createdAt:string};
type Fields={subject:string,unit:string,lesson:string,title:string,content:string};
const blank:Fields={subject:'',unit:'',lesson:'',title:'',content:''};
export default function KnowledgeManager({initialItems,total}:{initialItems:Item[],total:number}){
 const [items,setItems]=useState(initialItems),[count,setCount]=useState(total),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [form,setForm]=useState<Fields>(blank),[editing,setEditing]=useState<string|null>(null),[page,setPage]=useState(0);
 async function api(url:string,options?:RequestInit){const res=await fetch(url,{cache:'no-store',...options});const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(typeof data.error==='string'?data.error:'تعذر إتمام العملية');return data;}
 async function refresh(next=page){const data=await api(`/api/admin/knowledge?skip=${next*30}`);setItems(data.items);setPage(next);}
 async function create(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');setMessage('');try{
  if(editing){await api(`/api/admin/knowledge/${encodeURIComponent(editing)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});setMessage('تم تعديل المرجع وإلغاء اعتماده لحين المراجعة');}
  else{await api('/api/admin/knowledge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...form,approved:false})});setCount(n=>n+1);setMessage('تم حفظ المرجع كمسودة');}
  setForm(blank);setEditing(null);await refresh(0);
 }catch(e){setError(e instanceof Error?e.message:'حدث خطأ')}finally{setBusy(false)}}
 async function startEdit(item:Item){setBusy(true);setError('');try{const data=await api(`/api/admin/knowledge/${encodeURIComponent(item.id)}`);const x=data.item;setForm({subject:x.subject,unit:x.unit,lesson:x.lesson,title:x.title,content:x.content});setEditing(item.id);window.scrollTo({top:0,behavior:'smooth'});}catch(e){setError(e instanceof Error?e.message:'حدث خطأ')}finally{setBusy(false)}}
 async function toggle(item:Item){setBusy(true);setError('');setMessage('');try{await api(`/api/admin/knowledge/${encodeURIComponent(item.id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({approved:!item.approved})});setItems(xs=>xs.map(x=>x.id===item.id?{...x,approved:!x.approved}:x));setMessage('تم تحديث حالة الاعتماد')}catch(e){setError(e instanceof Error?e.message:'حدث خطأ')}finally{setBusy(false)}}
 async function remove(item:Item){if(!window.confirm(`حذف المرجع «${item.title}» نهائيًا؟`))return;setBusy(true);setError('');setMessage('');try{await api(`/api/admin/knowledge/${encodeURIComponent(item.id)}`,{method:'DELETE'});setCount(n=>Math.max(0,n-1));if(editing===item.id){setEditing(null);setForm(blank)}await refresh(items.length===1&&page>0?page-1:page);setMessage('تم حذف المرجع')}catch(e){setError(e instanceof Error?e.message:'حدث خطأ')}finally{setBusy(false)}}
 return <>
 <section className="card"><h2>{editing?'تعديل مرجع تعليمي':'إضافة مرجع نصي'}</h2><p>أي تعديل على المحتوى يلغي الاعتماد تلقائيًا لحين مراجعته من جديد.</p>
 <form onSubmit={create} style={{display:'grid',gap:12}}>{(['subject','unit','lesson','title'] as const).map(k=><label key={k}>{({subject:'المادة',unit:'الوحدة',lesson:'الدرس',title:'عنوان المرجع'})[k]}<input required maxLength={k==='subject'?100:k==='unit'?120:k==='lesson'?160:180} value={form[k]} onChange={e=>setForm(x=>({...x,[k]:e.target.value}))}/></label>)}
 <label>النص التعليمي<textarea required minLength={30} maxLength={10000} rows={8} value={form.content} onChange={e=>setForm(x=>({...x,content:e.target.value}))}/></label>
 <div style={{display:'flex',gap:10,flexWrap:'wrap'}}><button className="btn" disabled={busy}>{editing?'حفظ التعديلات كمسودة':'حفظ كمسودة'}</button>{editing&&<button type="button" disabled={busy} onClick={()=>{setEditing(null);setForm(blank)}}>إلغاء التعديل</button>}</div></form></section>
 <section className="card"><h2>المراجع ({count})</h2>{items.length===0?<p>لا توجد مراجع في هذه الصفحة.</p>:<div className="table-wrap"><table><thead><tr><th>العنوان</th><th>المادة</th><th>الدرس</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>{items.map(x=><tr key={x.id}><td>{x.title}</td><td>{x.subject}</td><td>{x.lesson}</td><td>{x.approved?'معتمد':'مسودة'}</td><td><div style={{display:'flex',gap:6,flexWrap:'wrap'}}><button type="button" disabled={busy} onClick={()=>startEdit(x)}>تعديل</button><button type="button" disabled={busy} onClick={()=>toggle(x)}>{x.approved?'إلغاء الاعتماد':'اعتماد'}</button><button type="button" disabled={busy} onClick={()=>remove(x)}>حذف</button></div></td></tr>)}</tbody></table></div>}
 <div style={{display:'flex',gap:10,alignItems:'center',marginTop:12}}><button type="button" disabled={busy||page===0} onClick={()=>refresh(page-1).catch(e=>setError(e.message))}>السابق</button><span>صفحة {page+1}</span><button type="button" disabled={busy||(page+1)*30>=count} onClick={()=>refresh(page+1).catch(e=>setError(e.message))}>التالي</button><button type="button" disabled={busy} onClick={()=>refresh().catch(e=>setError(e.message))}>تحديث</button></div>
 </section>{error&&<p role="alert">{error}</p>}{message&&<p role="status">{message}</p>}</>;
}
