import {redirect} from 'next/navigation';
import Link from 'next/link';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
import KnowledgeManager from './knowledge-manager';
export const dynamic='force-dynamic';
export default async function KnowledgePage(){
 const user=await currentUser();if(!user)redirect('/login');if(user.role!=='SUPER_ADMIN')redirect('/dashboard');
 const items=await db.knowledgeExcerpt.findMany({take:30,orderBy:{createdAt:'desc'},select:{id:true,title:true,subject:true,unit:true,lesson:true,approved:true,createdAt:true}});
 const total=await db.knowledgeExcerpt.count();
 return <><header><div className="brand">إدارة المعرفة — أثر أكاديمي</div><Link href="/admin" className="btn outline">لوحة المدير</Link></header><main className="panel"><h1>المراجع التعليمية</h1><p>المحتوى الجديد غير معتمد افتراضيًا. لا يستخدم المساعد إلا المحتوى الذي وافق عليه المدير.</p><KnowledgeManager initialItems={items.map(x=>({...x,createdAt:x.createdAt.toISOString()}))} total={total}/></main></>;
}
