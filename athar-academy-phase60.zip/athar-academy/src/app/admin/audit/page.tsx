import Link from 'next/link';
import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

/** Admin-only, read-only audit trail with bounded pagination and no sensitive payloads. */
export default async function AuditPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const user = await currentUser();
  if (!user) redirect('/login');
  if (user.role !== 'SUPER_ADMIN') redirect('/dashboard');
  const params = await searchParams;
  const raw = params.page ?? '1';
  const page = /^[1-9]\d{0,3}$/.test(raw) ? Number(raw) : 1;
  const logs = await db.auditLog.findMany({
    take: 51,
    skip: (page - 1) * 50,
    orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    select: {
      id: true, action: true, targetType: true, createdAt: true,
      actor: { select: { name: true, role: true } },
    },
  });
  const hasMore = logs.length > 50;
  return <>
    <header><div className="brand">سجل أنشطة الإدارة</div><Link href="/admin">العودة للإدارة</Link></header>
    <main className="panel">
      <h1>سجل التدقيق</h1>
      <p>سجل للقراءة فقط. لا يعرض كلمات المرور أو رموز الاشتراك أو تفاصيل الطلبات الحساسة.</p>
      <section className="card">
        <div className="table-wrap"><table>
          <thead><tr><th>التاريخ</th><th>المستخدم</th><th>الصلاحية</th><th>العملية</th><th>نوع السجل</th></tr></thead>
          <tbody>{logs.slice(0, 50).map(log => <tr key={log.id}>
            <td>{log.createdAt.toLocaleString('ar-EG')}</td>
            <td>{log.actor?.name ?? 'نظام / حساب محذوف'}</td>
            <td>{log.actor?.role ?? '—'}</td>
            <td>{log.action}</td>
            <td>{log.targetType}</td>
          </tr>)}</tbody>
        </table></div>
        {logs.length === 0 && <p>لا توجد عمليات مسجلة في هذه الصفحة.</p>}
      </section>
      <nav aria-label="صفحات سجل التدقيق">
        {page > 1 && <Link href={`/admin/audit?page=${page - 1}`}>السابق</Link>}
        {' '}<span>صفحة {page}</span>{' '}
        {hasMore && <Link href={`/admin/audit?page=${page + 1}`}>التالي</Link>}
      </nav>
    </main>
  </>;
}
