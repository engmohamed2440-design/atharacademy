'use client';
import {useState} from 'react';
type Settings={whatsappUrl:string;telegramUrl:string;defaultMessage:string};
export default function ContactEditor({initial}:{initial:Settings}){
 const [form,setForm]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState('');
 async function save(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');setSuccess('');
  try{const response=await fetch('/api/admin/contact-settings',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});
   if(!response.ok){const data=await response.json().catch(()=>({}));throw new Error(typeof data.error==='string'?data.error:'تعذر حفظ الإعدادات. تأكد من صحة الروابط.');}
   setSuccess('تم حفظ الإعدادات. ستظهر الروابط في الصفحة الرئيسية.');
  }catch(e){setError(e instanceof Error?e.message:'تعذر الاتصال بالخادم.');}finally{setBusy(false);}
 }
 return <section className="card"><form onSubmit={save} className="student-form">
 <label>رابط واتساب (wa.me أو api.whatsapp.com)<input type="url" value={form.whatsappUrl} placeholder="https://wa.me/201000000000" onChange={e=>setForm(x=>({...x,whatsappUrl:e.target.value}))}/></label>
 <label>رابط تيليجرام (t.me)<input type="url" value={form.telegramUrl} placeholder="https://t.me/example" onChange={e=>setForm(x=>({...x,telegramUrl:e.target.value}))}/></label>
 <label>الرسالة الافتراضية<textarea maxLength={500} rows={4} value={form.defaultMessage} onChange={e=>setForm(x=>({...x,defaultMessage:e.target.value}))}/></label>
 <button className="btn" type="submit" disabled={busy}>{busy?'جارٍ الحفظ…':'حفظ إعدادات التواصل'}</button>
 </form>{error&&<p role="alert" className="message">{error}</p>}{success&&<p role="status">{success}</p>}</section>;
}
