import Link from 'next/link';
import {redirect} from 'next/navigation';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
import ContactEditor from './contact-editor';
export const dynamic='force-dynamic';
export default async function ContactPage(){
 const user=await currentUser();if(!user)redirect('/login');if(user.role!=='SUPER_ADMIN')redirect('/dashboard');
 const rows=await db.platformSetting.findMany({where:{key:{in:['whatsappUrl','telegramUrl','defaultMessage']}}});
 const settings=Object.fromEntries(rows.map(r=>[r.key,r.value]));
 return <><header><div className="brand">أثر أكاديمي — إعدادات التواصل</div><Link className="btn outline" href="/admin">لوحة المدير</Link></header><main className="panel"><h1>إعدادات التواصل العامة</h1><p>تظهر الروابط المعتمدة للزوار في الصفحة الرئيسية. اترك الرابط فارغًا لإخفائه.</p><ContactEditor initial={{whatsappUrl:settings.whatsappUrl??'',telegramUrl:settings.telegramUrl??'',defaultMessage:settings.defaultMessage??''}}/></main></>;
}
