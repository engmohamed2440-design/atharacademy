import { redirect } from 'next/navigation';
import Link from 'next/link';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import CodeIssuer from './code-issuer';
import DashboardNav from '@/components/dashboard-nav';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const user = await currentUser();
  if (!user) redirect('/login');
  if (user.role !== 'SUPER_ADMIN' || !user.active) redirect('/dashboard');

  const now = new Date();
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const [students, staff, unused, active, expiring, openTickets, overdueTasks, latest, recentTickets] = await Promise.all([
    db.studentProfile.count(),
    db.staffProfile.count(),
    db.subscriptionCode.count({ where: { status: 'PENDING_ACTIVATION' } }),
    db.subscriptions.count({ where: { status: 'ACTIVE', endsAt: { gt: now } } }),
    db.subscriptions.count({ where: { status: 'ACTIVE', endsAt: { gt: now, lte: nextWeek } } }),
    db.supportTicket.count({ where: { status: 'OPEN' } }),
    db.studentTask.count({ where: { status: { not: 'DONE' }, dueAt: { lt: now } } }),
    db.studentStaffAssignment.findMany({
      where: { endedAt: null }, take: 10, orderBy: { startedAt: 'desc' },
      include: { student: { include: { user: { select: { name: true } } } }, staff: { include: { user: { select: { name: true } } } } }
    }),
    db.supportTicket.findMany({
      where: { status: 'OPEN' }, take: 5, orderBy: { updatedAt: 'desc' },
      select: { id: true, subject: true, createdAt: true }
    })
  ]);

  return <>
    <header className="admin-topbar"><div className="brand">أثر أكاديمي <span className="admin-role">لوحة المالك</span></div><Link className="btn outline" href="/logout">تسجيل الخروج</Link></header>
    <main className="panel admin-dashboard" id="main-content">
      <div className="admin-intro"><div><p className="admin-eyebrow">إدارة المنصة</p><h1>مرحبًا بك في لوحة المالك</h1><p>ملخص مباشر لحالة الطلاب والاشتراكات والمتابعة والدعم.</p></div><Link className="btn" href="/admin/students">إدارة الطلاب</Link></div>
      <section className="admin-metrics" aria-label="مؤشرات المنصة">
        <div className="admin-metric"><span>إجمالي الطلاب</span><strong>{students.toLocaleString('ar-EG')}</strong><Link href="/admin/students">عرض الطلاب</Link></div>
        <div className="admin-metric"><span>فريق المتابعة</span><strong>{staff.toLocaleString('ar-EG')}</strong><Link href="/admin/team">إدارة الفريق</Link></div>
        <div className="admin-metric"><span>اشتراكات نشطة</span><strong>{active.toLocaleString('ar-EG')}</strong><Link href="/admin/students">الاشتراكات</Link></div>
        <div className="admin-metric"><span>أكواد جاهزة للتفعيل</span><strong>{unused.toLocaleString('ar-EG')}</strong><a href="#subscription-codes">إصدار الأكواد</a></div>
      </section>
      <section className="admin-alerts" aria-label="المهام التي تحتاج مراجعة">
        <div className="admin-alert"><div><span className="admin-alert-icon" aria-hidden="true">◷</span><strong>اشتراكات تنتهي خلال ٧ أيام</strong><p>تابع التجديد قبل انتهاء الاشتراك.</p></div><div className="admin-alert-action"><b>{expiring.toLocaleString('ar-EG')}</b><Link href="/admin/students">مراجعة الطلاب</Link></div></div>
        <div className="admin-alert"><div><span className="admin-alert-icon" aria-hidden="true">✉</span><strong>طلبات دعم مفتوحة</strong><p>رسائل تحتاج ردًا من فريق الدعم.</p></div><div className="admin-alert-action"><b>{openTickets.toLocaleString('ar-EG')}</b><Link href="/support">فتح الدعم</Link></div></div>
        <div className="admin-alert"><div><span className="admin-alert-icon" aria-hidden="true">✓</span><strong>مهام متأخرة</strong><p>مهام طلاب تجاوزت موعدها ولم تكتمل.</p></div><div className="admin-alert-action"><b>{overdueTasks.toLocaleString('ar-EG')}</b><Link href="/admin/students">متابعة الطلاب</Link></div></div>
      </section>
      <DashboardNav items={[
        { href: '/admin/students', label: 'الطلاب والاشتراكات', description: 'استعراض ملفات الطلاب وحالة اشتراكاتهم' },
        { href: '/admin/team', label: 'إدارة فريق المتابعة', description: 'إدارة الفريق وإسناد الطلاب' },
        { href: '/admin/knowledge', label: 'المراجع التعليمية', description: 'مراجعة واعتماد محتوى مساعد أثر' },
        { href: '/support', label: 'طلبات الدعم', description: 'قراءة الرسائل والرد على الطلاب' },
        { href: '/admin/contact', label: 'إعدادات التواصل', description: 'إدارة روابط التواصل العامة' },
        { href: '/admin/audit', label: 'سجل أنشطة الإدارة', description: 'مراجعة التغييرات والإجراءات الإدارية' },
        { href: '/account', label: 'أمان الحساب', description: 'تحديث كلمة المرور والجلسات النشطة' }
      ]} />
      <section className="admin-work-grid">
        <div className="card"><div className="admin-section-title"><h2>أحدث طلبات الدعم المفتوحة</h2><Link href="/support">كل الطلبات</Link></div>{recentTickets.length === 0 ? <p>لا توجد طلبات دعم مفتوحة.</p> : <ul className="admin-link-list">{recentTickets.map(t => <li key={t.id}><Link href={`/support/${t.id}`}>{t.subject}</Link><time dateTime={t.createdAt.toISOString()}>{t.createdAt.toLocaleDateString('ar-EG')}</time></li>)}</ul>}</div>
        <div className="card"><div className="admin-section-title"><h2>أحدث إسنادات المتابعة</h2><Link href="/admin/team">إدارة الإسنادات</Link></div>{latest.length === 0 ? <p>لا توجد إسنادات حتى الآن.</p> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>المتابع</th><th>التاريخ</th></tr></thead><tbody>{latest.map(a => <tr key={a.id}><td>{a.student.user.name}</td><td>{a.staff.user.name}</td><td>{a.startedAt.toLocaleDateString('ar-EG')}</td></tr>)}</tbody></table></div>}</div>
      </section>
      <section id="subscription-codes" className="admin-code-section"><h2>إصدار أكواد الاشتراك</h2><p>أنشئ أكواد التفعيل من النموذج الآمن التالي.</p><CodeIssuer /></section>
    </main>
  </>;
}
