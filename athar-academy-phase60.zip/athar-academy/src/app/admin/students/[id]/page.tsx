import Link from 'next/link';
import {notFound,redirect} from 'next/navigation';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
export const dynamic='force-dynamic';
export default async function StudentDetails({params}:{params:Promise<{id:string}>}){
 const admin=await currentUser();if(!admin)redirect('/login');if(admin.role!=='SUPER_ADMIN')redirect('/dashboard');
 const {id}=await params;
 const student=await db.studentProfile.findUnique({where:{id},select:{id:true,user:{select:{name:true,email:true,active:true,createdAt:true}},subscriptions:{take:10,orderBy:{startsAt:'desc'},select:{status:true,startsAt:true,endsAt:true}},assignments:{take:10,orderBy:{startedAt:'desc'},select:{startedAt:true,endedAt:true,staff:{select:{user:{select:{name:true}}}}}},tasks:{take:20,orderBy:{createdAt:'desc'},select:{title:true,status:true,dueAt:true}},assessments:{take:10,orderBy:{createdAt:'desc'},select:{rating:true,createdAt:true}}}});
 if(!student)notFound();
 return <><header><div className="brand">ملف الطالب</div><Link href="/admin/students">كل الطلاب</Link></header><main className="panel"><h1>{student.user.name}</h1><p>الحساب: {student.user.active?'نشط':'معطل'}</p><p>البريد: {student.user.email||'غير مسجل'}</p><p>تاريخ التسجيل: {student.user.createdAt.toLocaleDateString('ar-EG')}</p><section className="card"><h2>الاشتراكات</h2>{student.subscriptions.length===0?<p>لا توجد اشتراكات</p>:<ul>{student.subscriptions.map((s,i)=><li key={i}>{s.status} — {s.startsAt.toLocaleDateString('ar-EG')} إلى {s.endsAt.toLocaleDateString('ar-EG')}</li>)}</ul>}</section><section className="card"><h2>سجل المتابعة</h2>{student.assignments.length===0?<p>لا توجد إسنادات</p>:<ul>{student.assignments.map((a,i)=><li key={i}>{a.staff.user.name} — {a.startedAt.toLocaleDateString('ar-EG')} {a.endedAt?'(منتهٍ)':'(حالي)'}</li>)}</ul>}</section><section className="card"><h2>أحدث المهام</h2>{student.tasks.length===0?<p>لا توجد مهام</p>:<ul>{student.tasks.map((t,i)=><li key={i}>{t.title} — {t.status}</li>)}</ul>}</section><section className="card"><h2>التقييمات</h2><p>عدد التقييمات الأخيرة: {student.assessments.length}</p></section></main></>;
}
