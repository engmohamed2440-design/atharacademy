import {redirect} from 'next/navigation';
import {cookies} from 'next/headers';
import {db} from '@/lib/db';
import {tokenHash} from '@/lib/auth';
export default async function Logout(){const jar=await cookies();const token=jar.get('athar_session')?.value;if(token)await db.session.deleteMany({where:{tokenHash:tokenHash(token)}});jar.delete('athar_session');redirect('/')}
