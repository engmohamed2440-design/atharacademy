import {redirect} from 'next/navigation';
import Link from 'next/link';
import {currentUser} from '@/lib/auth';
import PasswordForm from './password-form';
import RevokeSessions from './revoke-sessions';
export default async function AccountPage(){
 const user=await currentUser();if(!user)redirect('/login');
 const home=user.role==='SUPER_ADMIN'?'/admin':user.role==='FOLLOW_UP'?'/staff':user.role==='SUPPORT'?'/support':'/dashboard';
 return <><header><div className="brand">أثر أكاديمي</div><Link href={home} className="btn outline">العودة للوحة التحكم</Link></header><main className="panel"><h1>أمان الحساب</h1><p>الحساب: {user.name}</p><section className="card"><h2>تغيير كلمة المرور</h2><p>بعد تغييرها، سيتم إنهاء جلساتك على الأجهزة الأخرى.</p><PasswordForm/></section><section className="card"><h2>الأجهزة الأخرى</h2><p>لو فتحت حسابك من جهاز مش بتستخدمه، تقدر تنهي جلساته من هنا دون تغيير كلمة المرور.</p><RevokeSessions/></section></main></>;
}
