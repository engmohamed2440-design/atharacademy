'use client';
import {useState} from 'react';

export default function RevokeSessions(){
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState('');
 const [failed,setFailed]=useState(false);
 async function revoke(){
  if(busy||!window.confirm('هل تريد تسجيل الخروج من جميع الأجهزة الأخرى؟ سيظل هذا الجهاز مسجلًا.'))return;
  setBusy(true);setMessage('');setFailed(false);
  try{
   const response=await fetch('/api/sessions/revoke-others',{method:'POST',cache:'no-store'});
   const data=await response.json();
   if(!response.ok)throw new Error(data.error||'تعذر إغلاق الجلسات');
   setMessage(`تم إغلاق ${data.revoked} جلسة على الأجهزة الأخرى.`);
  }catch(error){setFailed(true);setMessage(error instanceof Error?error.message:'تعذر الاتصال بالخادم');}
  finally{setBusy(false);}
 }
 return <div><button type="button" className="btn outline" disabled={busy} onClick={revoke}>{busy?'جارٍ إغلاق الجلسات...':'تسجيل الخروج من الأجهزة الأخرى'}</button>{message&&<p role={failed?'alert':'status'}>{message}</p>}</div>;
}
