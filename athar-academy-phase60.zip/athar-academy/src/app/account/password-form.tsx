'use client';
import {useState, type FormEvent} from 'react';
export default function PasswordForm(){
 const [currentPassword,setCurrentPassword]=useState('');
 const [newPassword,setNewPassword]=useState('');
 const [confirm,setConfirm]=useState('');
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState('');
 const [ok,setOk]=useState(false);
 async function submit(e:FormEvent){
  e.preventDefault();setMessage('');setOk(false);
  if(newPassword!==confirm){setMessage('تأكيد كلمة المرور غير مطابق');return;}
  setBusy(true);
  try{
   const response=await fetch('/api/account/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({currentPassword,newPassword})});
   const result=await response.json();
   if(!response.ok)throw new Error(result.error||'تعذر تغيير كلمة المرور');
   setCurrentPassword('');setNewPassword('');setConfirm('');setOk(true);setMessage('تم تغيير كلمة المرور وإغلاق الجلسات الأخرى');
  }catch(e){setMessage(e instanceof Error?e.message:'حدث خطأ');}
  finally{setBusy(false);}
 }
 return <form onSubmit={submit} className="student-form">
  <label>كلمة المرور الحالية<input type="password" autoComplete="current-password" required maxLength={256} value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)}/></label>
  <label>كلمة المرور الجديدة<input type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={newPassword} onChange={e=>setNewPassword(e.target.value)}/></label>
  <label>تأكيد كلمة المرور الجديدة<input type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={confirm} onChange={e=>setConfirm(e.target.value)}/></label>
  <button className="btn" disabled={busy}>{busy?'جارٍ الحفظ...':'تغيير كلمة المرور'}</button>
  {message&&<p role={ok?'status':'alert'}>{message}</p>}
 </form>;
}
