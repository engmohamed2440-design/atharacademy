export default function Loading(){return <main className="system-state" role="status" aria-live="polite"><h1>جاري تحميل الصفحة...</h1><p>برجاء الانتظار قليلًا.</p></main>}
