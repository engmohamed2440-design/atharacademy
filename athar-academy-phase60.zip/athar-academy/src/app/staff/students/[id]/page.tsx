import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import FollowupEditor from './followup-editor';
export const dynamic = 'force-dynamic';

export default async function StaffStudentPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) redirect('/login');
  if (user.role !== 'FOLLOW_UP' || !user.active) redirect('/dashboard');
  const { id } = await params;
  const staff = await db.staffProfile.findUnique({ where: { userId: user.id } });
  if (!staff) notFound();
  const assignment = await db.studentStaffAssignment.findFirst({
    where: { studentId: id, staffId: staff.id, endedAt: null },
    select: { id: true },
  });
  if (!assignment) notFound();
  const [student, tasks, assessments] = await Promise.all([
    db.studentProfile.findUnique({ where: { id }, select: { id: true, user: { select: { name: true, active: true } } } }),
    db.studentTask.findMany({ where: { studentId: id }, orderBy: { dueAt: 'asc' }, take: 50, select: { id: true, title: true, description: true, status: true, dueAt: true } }),
    db.followUpAssessment.findMany({ where: { studentId: id, staffId: staff.id }, orderBy: { createdAt: 'desc' }, take: 10, select: { id: true, rating: true, summary: true, sharedUpdate: true, createdAt: true } }),
  ]);
  if (!student) notFound();
  return <><header><div className="brand">أثر أكاديمي — متابعة الطالب</div><Link className="btn outline" href="/staff">العودة للطلاب</Link></header>
    <main className="panel"><h1>{student.user.name}</h1><p>{student.user.active ? 'حساب نشط' : 'حساب موقوف'}</p>
      <FollowupEditor studentId={id} />
      <section className="card"><h2>المهام</h2>{tasks.length === 0 ? <p>لا توجد مهام بعد.</p> : <ul>{tasks.map(task => <li key={task.id}><strong>{task.title}</strong> — {task.status} — {task.dueAt.toLocaleDateString('ar-EG')}{task.description ? <p>{task.description}</p> : null}</li>)}</ul>}</section>
      <section className="card"><h2>آخر تقارير المتابعة</h2>{assessments.length === 0 ? <p>لم تُسجّل تقارير بعد.</p> : <ul>{assessments.map(a => <li key={a.id}><strong>{a.rating}</strong> — {a.createdAt.toLocaleDateString('ar-EG')}<p>{a.summary || 'بدون ملخص داخلي'}</p>{a.sharedUpdate ? <p>تحديث الطالب: {a.sharedUpdate}</p> : null}</li>)}</ul>}</section>
    </main></>;
}
