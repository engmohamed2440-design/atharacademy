'use client';
import { useState, type FormEvent } from 'react';

type Rating = 'EXCELLENT' | 'GOOD' | 'NEEDS_FOLLOWUP' | 'URGENT';
export default function FollowupEditor({ studentId }: { studentId: string }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueAt, setDueAt] = useState('');
  const [rating, setRating] = useState<Rating>('GOOD');
  const [summary, setSummary] = useState('');
  const [sharedUpdate, setSharedUpdate] = useState('');
  const [internalNote, setInternalNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function submit(url: string, payload: Record<string, unknown>, success: string) {
    setBusy(true); setMessage('');
    try {
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(payload) });
      const result = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof result.error === 'string' ? result.error : 'تعذر حفظ البيانات');
      setMessage(success);
      window.location.reload();
    } catch (e) { setMessage(e instanceof Error ? e.message : 'حدث خطأ أثناء الاتصال'); }
    finally { setBusy(false); }
  }
  function addTask(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const date = new Date(dueAt);
    if (!dueAt || Number.isNaN(date.getTime())) { setMessage('اختر موعدًا صحيحًا للمهمة'); return; }
    void submit(`/api/students/${encodeURIComponent(studentId)}/tasks`, { title, description, dueAt: date.toISOString() }, 'تم إنشاء المهمة');
  }
  function addFollowup(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    void submit(`/api/students/${encodeURIComponent(studentId)}/followup`, { rating, summary, sharedUpdate, internalNote }, 'تم حفظ تقرير المتابعة');
  }
  return <><section className="card"><h2>إضافة مهمة للطالب</h2>
    <form onSubmit={addTask}><label htmlFor="task-title">عنوان المهمة</label><input id="task-title" required minLength={2} maxLength={160} value={title} onChange={e => setTitle(e.target.value)} />
      <label htmlFor="task-description">تفاصيل المهمة</label><textarea id="task-description" maxLength={2000} value={description} onChange={e => setDescription(e.target.value)} />
      <label htmlFor="task-due">موعد التسليم</label><input id="task-due" type="datetime-local" required value={dueAt} onChange={e => setDueAt(e.target.value)} />
      <button className="btn" disabled={busy} type="submit">{busy ? 'جارٍ الحفظ...' : 'إضافة المهمة'}</button></form></section>
    <section className="card"><h2>تسجيل متابعة الطالب</h2><form onSubmit={addFollowup}>
      <label htmlFor="followup-rating">التقييم</label><select id="followup-rating" value={rating} onChange={e => setRating(e.target.value as Rating)}><option value="EXCELLENT">ممتاز</option><option value="GOOD">جيد</option><option value="NEEDS_FOLLOWUP">يحتاج متابعة</option><option value="URGENT">يحتاج تدخلاً عاجلًا</option></select>
      <label htmlFor="followup-summary">ملخص داخلي لفريق المتابعة</label><textarea id="followup-summary" maxLength={2000} value={summary} onChange={e => setSummary(e.target.value)} />
      <label htmlFor="followup-shared">تحديث يظهر للطالب</label><textarea id="followup-shared" maxLength={2000} value={sharedUpdate} onChange={e => setSharedUpdate(e.target.value)} />
      <label htmlFor="followup-note">ملاحظة داخلية (لا تظهر للطالب)</label><textarea id="followup-note" maxLength={2000} value={internalNote} onChange={e => setInternalNote(e.target.value)} />
      <button className="btn" disabled={busy} type="submit">{busy ? 'جارٍ الحفظ...' : 'حفظ تقرير المتابعة'}</button></form></section>
    {message && <p role="status" aria-live="polite">{message}</p>}</>;
}
