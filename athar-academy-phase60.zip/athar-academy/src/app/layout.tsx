import ReadingTools from '@/components/reading-tools';
import './style.css';
export const metadata={title:'أثر أكاديمي | ATHAR ACADEMY',description:'أثر في كل خطوة'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body><a className="skip-to-content" href="#main-content">انتقل إلى المحتوى الرئيسي</a><div id="main-content" tabIndex={-1}>{children}</div><ReadingTools/></body></html>}
