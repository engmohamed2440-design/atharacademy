import { db } from './db';
import { advisoryLockId } from './rate-limit-key';

/**
 * Enforce the daily quiz limit in the same transaction that creates the quiz.
 * A per-student PostgreSQL advisory lock prevents concurrent requests from
 * both observing the last available slot. The lock is released at commit.
 */
export async function createQuizWithinDailyQuota(
  studentId: string,
  input: { subject: string; unit?: string; lesson?: string; difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MIXED' },
  questions: { prompt: string; type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE'; options: string[]; correctIndex: number; explanation: string }[],
  maxPerDay = 5,
) {
  return db.$transaction(async tx => {
    const lockId = advisoryLockId(`quiz-daily:${studentId}`);
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(${lockId}::bigint)`;
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const count = await tx.quiz.count({ where: { studentId, createdAt: { gte: since } } });
    if (count >= maxPerDay) throw new Error('QUIZ_DAILY_LIMIT');
    return tx.quiz.create({
      data: {
        studentId, ...input,
        questions: { create: questions.map((q, position) => ({ ...q, position })) },
        attempts: { create: { studentId } },
      },
      select: { id: true },
    });
  }, { timeout: 15000 });
}
