/** CSV cells are always quoted and spreadsheet formulas are neutralized. */
export function csvCell(value: string | number | boolean | null | undefined): string {
  const raw = value == null ? '' : String(value);
  // Protect against spreadsheet formula injection, including leading whitespace/control chars.
  const dangerous = /^[\s\u0000-\u001f]*[=+@\-]/u.test(raw);
  const safe = dangerous ? `'${raw}` : raw;
  return `"${safe.replace(/"/g, '""')}"`;
}
export function csvDocument(rows: Array<Array<string | number | boolean | null | undefined>>): string {
  return '\uFEFF' + rows.map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
}
