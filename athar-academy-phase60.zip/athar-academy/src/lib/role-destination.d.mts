export declare function roleDestination(role: unknown): '/admin' | '/staff' | '/support' | '/dashboard' | null;
