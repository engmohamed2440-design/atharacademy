/** Centralized server-side subscription eligibility; never trust a browser clock. */
export type SubscriptionSnapshot = {
  status: 'PENDING_ACTIVATION' | 'ACTIVE' | 'EXPIRED' | 'SUSPENDED' | 'REVOKED';
  startsAt: Date;
  endsAt: Date;
  code: { status: 'PENDING_ACTIVATION' | 'ACTIVE' | 'EXPIRED' | 'SUSPENDED' | 'REVOKED' };
};
export function isSubscriptionEligible(subscription: SubscriptionSnapshot, now: Date): boolean {
  return subscription.status === 'ACTIVE' && subscription.code.status === 'ACTIVE' &&
    subscription.startsAt.getTime() <= now.getTime() && subscription.endsAt.getTime() > now.getTime();
}
