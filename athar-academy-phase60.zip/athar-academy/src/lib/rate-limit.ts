import { db } from './db';
import { advisoryLockId, rateLimitIdentity } from './rate-limit-key';

/**
 * Atomic database-backed limiter: serializes requests for the same identity using
 * a transaction-scoped PostgreSQL advisory lock, then counts and records the attempt.
 * Account/code-based limiting works even without a trusted reverse proxy.
 */
export async function checkRateLimit(
  req: Request,
  action: 'LOGIN_ATTEMPT' | 'ACTIVATION_ATTEMPT',
  subject: string,
  maxAttempts = 8,
) {
  const forwarded = process.env.TRUST_PROXY_HEADERS === 'true'
    ? req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || req.headers.get('cf-connecting-ip')?.trim()
    : undefined;
  const { subjectKey, ipKey } = rateLimitIdentity({
    action, subject, ip: forwarded, secret: process.env.RATE_LIMIT_SECRET,
  });
  const since = new Date(Date.now() - 15 * 60 * 1000);
  await db.$transaction(async tx => {
    // Stable order avoids deadlocks when two requests share one of the keys.
    const keys = [...new Set([subjectKey, ipKey].filter((k): k is string => Boolean(k)))].sort();
    for (const key of keys) {
      const lockId = advisoryLockId(key);
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(${lockId}::bigint)`;
    }
    for (const key of keys) {
      const count = await tx.auditLog.count({
        where: { action, targetType: 'RateLimit', targetId: key, createdAt: { gte: since } },
      });
      if (count >= maxAttempts) throw new Error('RATE_LIMITED');
    }
    await tx.auditLog.createMany({
      data: keys.map(key => ({ action, targetType: 'RateLimit', targetId: key })),
    });
  });
}
