import {answerWithFallback} from './ai';
import {validateQuizQuestions} from './quiz-validation.mjs';
import {z} from 'zod';
export const quizInput=z.object({subject:z.string().trim().min(2).max(80),unit:z.string().trim().max(100).optional(),lesson:z.string().trim().max(100).optional(),difficulty:z.enum(['EASY','MEDIUM','HARD','MIXED']),count:z.number().int().min(3).max(15)});
export const generatedQuestion=z.object({prompt:z.string().min(10).max(2000),type:z.enum(['MULTIPLE_CHOICE','TRUE_FALSE']),options:z.array(z.string().min(1).max(300)).min(2).max(4),correctIndex:z.number().int().min(0).max(3),explanation:z.string().min(5).max(1500)}).refine(q=>q.correctIndex<q.options.length&& (q.type!=='TRUE_FALSE'||q.options.length===2)).refine(q=>new Set(q.options.map(o=>o.trim().toLocaleLowerCase())).size===q.options.length,{message:'الخيارات يجب أن تكون مختلفة'});
export const generatedQuiz=z.object({questions:z.array(generatedQuestion).min(3).max(15)});
export async function generateQuiz(input:z.infer<typeof quizInput>,log:(entry:{provider:'deepseek'|'gemini';model:string;latencyMs:number;success:boolean;inputTokens?:number;outputTokens?:number})=>Promise<void>){
 const prompt=`أنشئ اختبارًا تعليميًا لطلاب الصف الثالث الثانوي المصري. المادة: ${input.subject}، الوحدة: ${input.unit||'عام'}، الدرس: ${input.lesson||'عام'}، الصعوبة: ${input.difficulty}، عدد الأسئلة: ${input.count}. أرجع JSON صالح فقط دون markdown بالشكل {"questions":[{"prompt":"...","type":"MULTIPLE_CHOICE","options":["...","...","...","..."],"correctIndex":0,"explanation":"..."}]}. استخدم TRUE_FALSE مع خيارين فقط. تجنب الأسئلة الغامضة، لا تدّعِ أن الأسئلة مأخوذة من مصدر رسمي.`;
 const result=await answerWithFallback([{role:'user',content:prompt}],log);
 const raw=result.text.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
 let data:unknown;try{data=JSON.parse(raw);}catch{throw new Error('INVALID_GENERATION');}
 const validated=generatedQuiz.safeParse(data);
 if(!validated.success||validated.data.questions.length!==input.count)throw new Error('INVALID_GENERATION');
 const normalizedPrompts=validated.data.questions.map(q=>q.prompt.trim().replace(/\s+/g,' ').toLocaleLowerCase());
 if(new Set(normalizedPrompts).size!==normalizedPrompts.length || !validateQuizQuestions(validated.data.questions,input.count))throw new Error('INVALID_GENERATION');
 return validated.data.questions;
}
export function gradeAnswers(questions:{id:string;correctIndex:number}[],answers:{questionId:string;selectedIndex:number}[]){
 const choices=new Map(answers.map(a=>[a.questionId,a.selectedIndex]));
 if(choices.size!==questions.length||answers.length!==questions.length||questions.some(q=>!choices.has(q.id)))throw new Error('INVALID_ANSWERS');
 return questions.map(q=>({questionId:q.id,selectedIndex:choices.get(q.id)!,correct:choices.get(q.id)===q.correctIndex}));
}
