import { createHmac } from 'node:crypto';

/** Opaque, stable identifier. Never store raw emails, activation codes or IPs in audit logs. */
export function rateLimitIdentity({ action, subject, ip, secret }) {
  if (typeof secret !== 'string' || secret.length < 32) throw new Error('RATE_LIMIT_NOT_CONFIGURED');
  if (!['LOGIN_ATTEMPT', 'ACTIVATION_ATTEMPT'].includes(action)) throw new Error('INVALID_ACTION');
  const normalized = String(subject ?? '').trim().toLowerCase();
  if (!normalized || normalized.length > 256) throw new Error('INVALID_SUBJECT');
  const subjectKey = createHmac('sha256', secret).update(`${action}:subject:${normalized}`).digest('hex');
  const ipKey = ip ? createHmac('sha256', secret).update(`${action}:ip:${ip}`).digest('hex') : null;
  return { subjectKey, ipKey };
}

/** PostgreSQL signed bigint advisory lock id derived from a keyed digest. */
export function advisoryLockId(fingerprint) {
  if (!/^[a-f0-9]{64}$/.test(fingerprint)) throw new Error('INVALID_FINGERPRINT');
  return BigInt.asIntN(64, BigInt(`0x${fingerprint.slice(0, 16)}`));
}
