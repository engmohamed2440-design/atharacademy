import { randomBytes, createHash } from 'node:crypto';
export const generateCode = () => 'ATH-' + randomBytes(18).toString('base64url');
export const hashCode = (code:string) => createHash('sha256').update(code.trim()).digest('hex');
export const addMonthsUTC = (date:Date, months:number) => { const result = new Date(date); const day = result.getUTCDate(); result.setUTCDate(1); result.setUTCMonth(result.getUTCMonth()+months); const last = new Date(Date.UTC(result.getUTCFullYear(),result.getUTCMonth()+1,0)).getUTCDate(); result.setUTCDate(Math.min(day,last)); return result; };
