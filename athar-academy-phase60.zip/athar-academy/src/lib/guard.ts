import { currentUser } from './auth';
import { db } from './db';
export function verifyOrigin(req: Request) {
 const origin = req.headers.get('origin');
 const expected = process.env.APP_ORIGIN;
 if (!expected || !origin || new URL(origin).origin !== new URL(expected).origin) throw new Error('FORBIDDEN');
}
export async function requireStudentAccess(studentId:string) {
 const user=await currentUser(); if(!user) throw new Error('FORBIDDEN');
 if(user.role==='SUPER_ADMIN') return user;
 if(user.role==='STUDENT') {const profile=await db.studentProfile.findUnique({where:{userId:user.id}}); if(profile?.id===studentId) return user;}
 if(user.role==='FOLLOW_UP' && user.active) {const staff=await db.staffProfile.findUnique({where:{userId:user.id}}); if(staff && await db.studentStaffAssignment.findFirst({where:{studentId,staffId:staff.id,endedAt:null}})) return user;}
 throw new Error('FORBIDDEN');
}
export async function requireActiveStudent() {
 const user=await currentUser(); if(!user || user.role!=='STUDENT' || !user.active) throw new Error('FORBIDDEN');
 const student=await db.studentProfile.findUnique({where:{userId:user.id}});
 if(!student) throw new Error('FORBIDDEN');
 const now=new Date();
 const eligible=await db.subscriptions.findFirst({where:{studentId:student.id,status:'ACTIVE',startsAt:{lte:now},endsAt:{gt:now},code:{status:'ACTIVE'}},select:{id:true}});
 if(!eligible) throw new Error('SUBSCRIPTION_REQUIRED');
 return {user,student};
}
