import { db } from './db';
import { advisoryLockId } from './rate-limit-key';
import { createHash } from 'node:crypto';

/**
 * Reserve a daily AI request atomically before contacting a paid provider.
 * The persisted user message is the reservation: failed provider calls still
 * consume one request, avoiding unbounded retries against paid APIs.
 */
export async function reserveAIMessage(studentId: string, conversationId: string, content: string, maxPerDay = 40) {
  return db.$transaction(async tx => {
    const lockId = advisoryLockId(createHash('sha256').update(`ai-daily:${studentId}`).digest('hex'));
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(${lockId}::bigint)`;
    const conversation = await tx.aIConversation.findFirst({ where: { id: conversationId, studentId }, select: { id: true } });
    if (!conversation) throw new Error('AI_CONVERSATION_NOT_FOUND');
    const since = new Date(Date.now() - 86400000);
    const used = await tx.aIMessage.count({
      where: { conversation: { studentId }, role: 'user', createdAt: { gte: since } },
    });
    if (used >= maxPerDay) throw new Error('AI_DAILY_LIMIT');
    const message = await tx.aIMessage.create({ data: { conversationId, role: 'user', content }, select: { id: true } });
    // A failed provider call must not leave the conversation hidden at its old position.
    // Set the title on the first message, even if the provider is temporarily unavailable.
    const existingMessages = await tx.aIMessage.count({ where: { conversationId } });
    await tx.aIConversation.update({
      where: { id: conversationId },
      data: { updatedAt: new Date(), ...(existingMessages === 1 ? { title: content.slice(0, 55) } : {}) },
    });
    return message;
  }, { timeout: 15000 });
}
