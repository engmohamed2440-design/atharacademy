/** Check that the application schema exists, not just that PostgreSQL accepts SELECT 1.
 * Only returns a boolean to public callers; never reveal DB details or credentials.
 */
type ModelProbe = { findFirst(args: { select: { id: true } }): Promise<unknown> };
type ReadinessDatabase = {
  user: ModelProbe;
  studentProfile: ModelProbe;
  subscriptionCode: ModelProbe;
  aIConversation: ModelProbe;
  quiz: ModelProbe;
  knowledgeExcerpt: ModelProbe;
};
export async function checkDatabaseReadiness(db: ReadinessDatabase): Promise<boolean> {
  try {
    await Promise.all([
      db.user.findFirst({ select: { id: true } }),
      db.studentProfile.findFirst({ select: { id: true } }),
      db.subscriptionCode.findFirst({ select: { id: true } }),
      db.aIConversation.findFirst({ select: { id: true } }),
      db.quiz.findFirst({ select: { id: true } }),
      db.knowledgeExcerpt.findFirst({ select: { id: true } }),
    ]);
    return true;
  } catch {
    return false;
  }
}
