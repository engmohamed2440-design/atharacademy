import { cookies } from 'next/headers';
import { createHash, randomBytes } from 'node:crypto';
import { db } from './db';
export const tokenHash = (v:string) => createHash('sha256').update(v).digest('hex');
export async function currentUser() {
 const token = (await cookies()).get('athar_session')?.value;
 if (!token) return null;
 const session = await db.session.findUnique({where:{tokenHash:tokenHash(token)},include:{user:true}});
 if (!session || session.expiresAt <= new Date() || !session.user.active) return null;
 return session.user;
}
export async function createSession(userId:string) {
 const token = randomBytes(32).toString('base64url');
 await db.session.create({data:{userId,tokenHash:tokenHash(token),expiresAt:new Date(Date.now()+7*86400000)}});
 (await cookies()).set('athar_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'strict',path:'/',maxAge:7*86400});
}
export async function requireRole(roles: Array<'SUPER_ADMIN'|'FOLLOW_UP'|'STUDENT'|'SUPPORT'>) {
 const user = await currentUser(); if (!user || !roles.includes(user.role)) throw new Error('FORBIDDEN'); return user;
}
