export interface QuizQuestionForValidation {
  prompt: string;
  type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE';
  options: string[];
  correctIndex: number;
}
export function validateQuizQuestions(questions: QuizQuestionForValidation[], expectedCount: number): boolean;
