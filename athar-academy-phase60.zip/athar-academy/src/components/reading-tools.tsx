'use client';

import {useEffect,useState} from 'react';

/** أدوات مساعدة عامة لا تتطلب تسجيل الدخول أو الاتصال بالخادم. */
export default function ReadingTools(){
 const [visible,setVisible]=useState(false);
 useEffect(()=>{
  const update=()=>setVisible(window.scrollY>450);
  update();
  window.addEventListener('scroll',update,{passive:true});
  return ()=>window.removeEventListener('scroll',update);
 },[]);
 if(!visible)return null;
 return <button type="button" className="back-to-top" aria-label="العودة إلى أعلى الصفحة" title="العودة إلى أعلى الصفحة" onClick={()=>window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})}>↑ <span>أعلى الصفحة</span></button>;
}
