import Link from 'next/link';

type NavItem={href:string;label:string;description:string};
export default function DashboardNav({items,heading='الوصول السريع'}:{items:NavItem[];heading?:string}){
 return <nav className="dashboard-nav" aria-label={heading}>
  <div className="dashboard-nav-heading"><h2>{heading}</h2><p>انتقل إلى القسم الذي تحتاجه بسهولة</p></div>
  <div className="dashboard-nav-grid">{items.map(item=><Link key={item.href} className="dashboard-nav-link" href={item.href}>
   <span className="dashboard-nav-label">{item.label}<span className="dashboard-nav-arrow" aria-hidden="true">←</span></span>
   <span className="dashboard-nav-description">{item.description}</span>
  </Link>)}</div>
 </nav>;
}
