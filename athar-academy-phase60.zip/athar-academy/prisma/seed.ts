import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
const db=new PrismaClient();
async function main(){const email=process.env.BOOTSTRAP_ADMIN_EMAIL;const password=process.env.BOOTSTRAP_ADMIN_PASSWORD;if(!email||!password||password.length<16)throw Error('Set BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD (16+ characters)');if(await db.user.count({where:{role:'SUPER_ADMIN'}}))throw Error('Super admin already exists');await db.user.create({data:{email,name:'مدير المنصة',passwordHash:await bcrypt.hash(password,12),role:'SUPER_ADMIN'}});console.log('Admin created');}
main().finally(()=>db.$disconnect());
