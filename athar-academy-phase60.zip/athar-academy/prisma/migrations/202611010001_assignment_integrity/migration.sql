-- Apply only after creating the initial baseline migration from schema.prisma.
-- A student can have at most one current follow-up assignment.
CREATE UNIQUE INDEX IF NOT EXISTS "StudentStaffAssignment_one_active_student"
  ON "StudentStaffAssignment" ("studentId") WHERE "endedAt" IS NULL;
