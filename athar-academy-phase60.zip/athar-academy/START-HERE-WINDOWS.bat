@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js LTS from https://nodejs.org/
  pause
  exit /b 1
)
node scripts\beginner-wizard.mjs
if errorlevel 1 (
  echo Setup encountered an error.
  pause
)
