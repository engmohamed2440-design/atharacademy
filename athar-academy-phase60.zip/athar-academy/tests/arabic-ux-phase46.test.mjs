import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const read=p=>readFileSync(new URL(p,root),'utf8');
test('اللغة العربية واتجاه القراءة مضبوطان في جذر التطبيق',()=>{
 const source=read('src/app/layout.tsx');
 assert.match(source,/lang="ar"/);assert.match(source,/dir="rtl"/);
});
test('رابط تخطي التنقل يصل إلى عنصر المحتوى الرئيسي',()=>{
 const source=read('src/app/layout.tsx');
 assert.match(source,/href="#main-content"/);assert.match(source,/id="main-content"/);
});
test('زر العودة لأعلى الصفحة له تسمية عربية ويزيل مستمع التمرير',()=>{
 const source=read('src/components/reading-tools.tsx');
 assert.match(source,/aria-label="العودة إلى أعلى الصفحة"/);
 assert.match(source,/removeEventListener\('scroll',update\)/);
 assert.match(source,/prefers-reduced-motion/);
});
test('عناصر التنقل تراعي لوحة المفاتيح والشاشات الصغيرة',()=>{
 const source=read('src/app/style.css');
 assert.match(source,/\.skip-to-content:focus/);
 assert.match(source,/\.back-to-top/);
 assert.match(source,/\[dir="rtl"\] textarea/);
});
