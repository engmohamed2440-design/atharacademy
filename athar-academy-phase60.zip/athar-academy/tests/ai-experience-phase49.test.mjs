import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const page=readFileSync(new URL('../src/app/ai/page.tsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/app/style.css',import.meta.url),'utf8');
test('Arabic conversation history can be searched',()=>{assert.match(page,/visibleConversations=conversations\.filter/);assert.match(page,/type="search"/);assert.match(page,/لا توجد محادثات تطابق البحث/);});
test('Long conversations offer a scroll-to-latest action',()=>{assert.match(page,/showScroll&&<button/);assert.match(page,/أحدث رسالة/);assert.match(page,/onScroll=/);});
test('Composer exposes input length and RTL visual styles',()=>{assert.match(page,/input\.length\} \/ 3000 حرف/);assert.match(css,/athar-ai-compose-meta/);assert.match(css,/athar-ai-search/);});
