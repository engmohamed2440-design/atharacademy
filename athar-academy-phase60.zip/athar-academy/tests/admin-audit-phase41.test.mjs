import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
test('audit page requires authenticated super admin', () => {
  const source = read('../src/app/admin/audit/page.tsx');
  assert.match(source, /currentUser\(\)/);
  assert.match(source, /role !== 'SUPER_ADMIN'/);
  assert.match(source, /redirect\('\/login'\)/);
});
test('audit view is bounded and does not select sensitive target IDs', () => {
  const source = read('../src/app/admin/audit/page.tsx');
  assert.match(source, /take: 51/);
  assert.match(source, /logs\.slice\(0, 50\)/);
  assert.doesNotMatch(source, /targetId: true/);
});
test('student CSV export applies bounded search filter', () => {
  const source = read('../src/app/api/admin/exports/students/route.ts');
  assert.match(source, /q\.length > 80/);
  assert.match(source, /contains: q/);
  assert.match(source, /requireRole\(\['SUPER_ADMIN'\]\)/);
});
test('student export link carries search term', () => {
  const source = read('../src/app/admin/students/page.tsx');
  assert.match(source, /exports\/students\?page=1&q=\$\{encodeURIComponent\(q\)\}/);
});
