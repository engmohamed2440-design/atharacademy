import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const page = readFileSync(new URL('../src/app/admin/page.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/app/style.css', import.meta.url), 'utf8');
test('owner dashboard requires super admin and active account', () => {
  assert.match(page, /user\.role !== 'SUPER_ADMIN' \|\| !user\.active/);
});
test('owner dashboard uses actual database aggregates and bounded lists', () => {
  for (const name of ['studentProfile.count', 'staffProfile.count', 'subscriptions.count', 'supportTicket.count', 'studentTask.count']) assert.ok(page.includes(name), name);
  assert.match(page, /take: 5/);
  assert.match(page, /take: 10/);
});
test('operational actions point to existing routes', () => {
  for (const route of ['/admin/students', '/admin/team', '/admin/knowledge', '/admin/contact', '/admin/audit', '/support', '/account']) assert.ok(page.includes(route), route);
});
test('Arabic owner dashboard includes RTL-friendly responsive styling', () => {
  assert.match(page, /لوحة المالك/);
  assert.match(page, /اشتراكات تنتهي خلال ٧ أيام/);
  assert.match(css, /\.admin-metrics/);
  assert.match(css, /@media\(max-width:540px\)/);
});
