import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(p, import.meta.url), 'utf8');
test('restore requires explicit confirmation and refuses populated database', () => {
  const s = read('../scripts/restore-db.sh');
  assert.match(s, /CONFIRM_RESTORE/);
  assert.match(s, /existing.*!= '0'/);
  assert.match(s, /--single-transaction/);
});
test('smoke test checks database health and unauthorized admin access', () => {
  const s = read('../scripts/smoke-test.mjs');
  assert.match(s, /\/api\/health/);
  assert.match(s, /\/api\/admin\/exports\/students/);
  assert.match(s, /\[401, 403\]/);
});
test('production smoke test enforces HTTPS', () => {
  assert.match(read('../scripts/smoke-test.mjs'), /origin\.protocol !== 'https:'/);
});
