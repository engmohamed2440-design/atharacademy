import test from 'node:test';
import assert from 'node:assert/strict';
import { isSubscriptionEligible } from '../src/lib/subscription-policy.ts';
import { addMonthsUTC, generateCode, hashCode } from '../src/lib/codes.ts';
const now = new Date('2026-11-01T12:00:00.000Z');
const valid = {status:'ACTIVE',code:{status:'ACTIVE'},startsAt:new Date('2026-10-01T00:00:00Z'),endsAt:new Date('2026-12-01T00:00:00Z')};
test('active subscription inside validity window is eligible',()=>assert.equal(isSubscriptionEligible(valid,now),true));
for (const status of ['PENDING_ACTIVATION','EXPIRED','SUSPENDED','REVOKED']) {
 test(`subscription status ${status} denies access`,()=>assert.equal(isSubscriptionEligible({...valid,status},now),false));
 test(`code status ${status} denies access`,()=>assert.equal(isSubscriptionEligible({...valid,code:{status}},now),false));
}
test('start boundary is inclusive',()=>assert.equal(isSubscriptionEligible(valid,valid.startsAt),true));
test('end boundary is exclusive',()=>assert.equal(isSubscriptionEligible(valid,valid.endsAt),false));
test('future subscription denies access',()=>assert.equal(isSubscriptionEligible(valid,new Date('2026-09-01T00:00:00Z')),false));
test('month rollover clamps Jan 31 to February 28',()=>assert.equal(addMonthsUTC(new Date('2027-01-31T10:00:00Z'),1).toISOString(),'2027-02-28T10:00:00.000Z'));
test('leap year rollover clamps to February 29',()=>assert.equal(addMonthsUTC(new Date('2028-01-31T10:00:00Z'),1).toISOString(),'2028-02-29T10:00:00.000Z'));
test('generated codes are different and hashed deterministically',()=>{const a=generateCode(),b=generateCode();assert.notEqual(a,b);assert.match(a,/^ATH-[A-Za-z0-9_-]{24}$/);assert.equal(hashCode(a),hashCode(a));assert.notEqual(hashCode(a),a);});
