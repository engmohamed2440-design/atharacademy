import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=(path)=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');
test('Login has Arabic accessible labels, password reveal and loading feedback',()=>{const s=read('src/app/login/page.tsx');for(const term of ['htmlFor="login-email"','htmlFor="login-password"','aria-pressed={showPassword}','aria-busy={busy}','role="alert"','autoComplete="current-password"'])assert.ok(s.includes(term),term)});
test('Activation form respects API password limits and prevents double submit',()=>{const s=read('src/app/activate/page.tsx');for(const term of ['minLength={12}','maxLength={128}','if(busy)return','aria-describedby="activation-password-help"','maxLength={100}','role="alert"'])assert.ok(s.includes(term),term)});
test('Unified auth design includes mobile layout and focus-visible styles',()=>{const s=read('src/app/style.css');assert.ok(s.includes('.auth-page{'));assert.ok(s.includes('@media(max-width:900px)'));assert.ok(s.includes(':focus-visible'))});
