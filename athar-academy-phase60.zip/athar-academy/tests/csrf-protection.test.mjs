import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const middleware = readFileSync(new URL('../src/middleware.ts', import.meta.url), 'utf8');
test('API routes have global middleware matcher', () => assert.match(middleware, /matcher:\s*\['\/api\/:path\*'\]/));
test('mutation origin is checked against configured APP_ORIGIN', () => {
 assert.match(middleware, /process\.env\.APP_ORIGIN/);
 assert.match(middleware, /headers\.get\('origin'\)/);
 assert.match(middleware, /allowed\.origin !== actual\.origin/);
});
test('missing origin is rejected rather than allowed', () => assert.match(middleware, /!expected \|\| !origin/));
test('safe read methods bypass origin checks', () => assert.match(middleware, /'GET', 'HEAD', 'OPTIONS'/));
