import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const ui=readFileSync(new URL('../src/app/ai/page.tsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/app/style.css',import.meta.url),'utf8');
test('Arabic chat interface includes conversation history, accessible composer and suggestions',()=>{for(const term of ['سجل المحادثات','المحادثات السابقة','اكتب رسالتك لمساعد أثر','athar-ai-suggestions','aria-live','dir="rtl"'])assert.ok(ui.includes(term),term);});
test('chat locks switching while requests are in progress and handles stale reads',()=>{assert.match(ui,/if\(busyRef\.current\)return/);assert.match(ui,/token===requestRef\.current/);assert.match(ui,/encodeURIComponent\(id\)/);});
test('chat supports keyboard submission, safe text rendering and failure recovery',()=>{assert.match(ui,/e\.key==='Enter'&&!e\.shiftKey/);assert.match(ui,/setInput\(content\)/);assert.match(ui,/readResponse\(await fetch/);assert.match(ui,/\{m\.content\}/);});
test('chat design adapts to mobile and reduced motion',()=>{assert.match(css,/@media\(max-width:850px\)/);assert.match(css,/\.athar-ai-sidebar\.is-open/);assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);});
