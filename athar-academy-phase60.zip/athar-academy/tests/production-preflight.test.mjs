import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
test('production preflight refuses incomplete deployment',()=>{
 const p=spawnSync(process.execPath,['scripts/production-preflight.mjs'],{cwd:process.cwd(),env:{PATH:process.env.PATH,NODE_ENV:'production'},encoding:'utf8'});
 assert.equal(p.status,1);const report=JSON.parse(p.stdout);assert.equal(report.ready,false);assert.ok(report.errors.some(x=>x.includes('Initial schema migration')));
});
test('baseline script derives SQL from real Prisma schema, not handcrafted placeholder',()=>{
 const s=readFileSync('scripts/create-baseline.sh','utf8');assert.match(s,/prisma migrate diff/);assert.match(s,/--from-empty/);assert.match(s,/--to-schema-datamodel/);
});
test('backup uses custom pg_dump and private file permissions',()=>{
 const s=readFileSync('scripts/backup-db.sh','utf8');assert.match(s,/pg_dump/);assert.match(s,/umask 077/);
});
