import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { checkDatabaseReadiness } from '../src/lib/readiness.ts';

const models = ['user', 'studentProfile', 'subscriptionCode', 'aIConversation', 'quiz', 'knowledgeExcerpt'];
function fakeDb(failing) {
  const calls = [];
  const db = Object.fromEntries(models.map(name => [name, { findFirst: async ({select}) => {
    calls.push(name);
    assert.deepEqual(select, {id:true});
    if (name === failing) throw new Error('Sensitive database connection detail');
    return null;
  } }]));
  return {db, calls};
}
test('readiness passes on an empty but migrated database', async () => {
  const {db,calls} = fakeDb();
  assert.equal(await checkDatabaseReadiness(db), true);
  assert.deepEqual(calls.sort(), [...models].sort());
});
test('readiness fails if any essential table is missing', async () => {
  for (const name of models) assert.equal(await checkDatabaseReadiness(fakeDb(name).db), false, name);
});
test('readiness fails safely when database is unavailable', async () => {
  assert.equal(await checkDatabaseReadiness({}), false);
});
test('readiness endpoint returns only status and prevents caching', () => {
  const src = readFileSync(new URL('../src/app/api/health/ready/route.ts', import.meta.url),'utf8');
  assert.match(src,/status: ready \? 200 : 503/);
  assert.match(src,/Cache-Control.*no-store/);
  assert.doesNotMatch(src,/error\.message|DATABASE_URL/);
});
