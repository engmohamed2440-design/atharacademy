import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const route=readFileSync(new URL('../src/app/api/admin/assignments/route.ts',import.meta.url),'utf8');
const sql=readFileSync(new URL('../prisma/migrations/202611010001_assignment_integrity/migration.sql',import.meta.url),'utf8');
test('assignment changes serialized per student',()=>assert.match(route,/pg_advisory_xact_lock/));
test('inactive staff rejected',()=>assert.match(route,/!staff\.user\.active/));
test('assignment can be removed',()=>assert.match(route,/staffId: z\.string\(\)\.min\(1\)\.nullable\(\)/));
test('unique active assignment index',()=>assert.match(sql,/UNIQUE INDEX[\s\S]*WHERE "endedAt" IS NULL/));
