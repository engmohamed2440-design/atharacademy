import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const ai=readFileSync(new URL('../src/lib/ai.ts',import.meta.url),'utf8');
const route=readFileSync(new URL('../src/app/api/ai/conversations/[id]/messages/route.ts',import.meta.url),'utf8');
test('reference context is supplied separately from student chat turns',()=>{
 assert.match(route,/\{referenceContext:context\}/);
 assert.doesNotMatch(route,/role:'user' as const,content:context/);
 assert.match(ai,/AIRequestOptions/);
 assert.match(ai,/options\.referenceContext/);
});
test('AI responses have a bounded persistence size',()=>{
 assert.equal((ai.match(/text\.slice\(0,16000\)/g)||[]).length,2);
});
