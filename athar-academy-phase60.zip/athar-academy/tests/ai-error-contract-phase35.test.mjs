import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const base = new URL('../src/app/api/ai/conversations/', import.meta.url);
const source = (path) => readFileSync(new URL(path, base), 'utf8');

test('AI conversation list distinguishes expired subscriptions from forbidden access', () => {
  const s = source('route.ts');
  assert.match(s, /errorResponse\(error\)/);
  assert.doesNotMatch(s, /catch\s*\{\s*return NextResponse\.json\(\{error:'غير مصرح'/);
});
test('AI message read does not label database failures as authorization failures', () => {
  const s = source('[id]/messages/route.ts');
  assert.match(s, /catch\(error\)\{return errorResponse\(error\)/);
});
test('AI message write returns subscription status rather than a provider error', () => {
  const s = source('[id]/messages/route.ts');
  assert.match(s, /code==='SUBSCRIPTION_REQUIRED'\)return errorResponse\(err\)/);
});
test('AI delete retains ownership-scoped delete and preserves error types', () => {
  const s = source('[id]/route.ts');
  assert.match(s, /deleteMany\(\{ where: \{ id, studentId: student\.id \} \}\)/);
  assert.match(s, /return errorResponse\(error\)/);
});
