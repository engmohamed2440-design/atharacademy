import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync,existsSync} from 'node:fs';
test('core source files exist',()=>{for(const path of ['prisma/schema.prisma','src/app/api/activate/route.ts','src/lib/auth.ts','.env.example'])assert.ok(existsSync(path))});
test('secrets not embedded in example',()=>{const s=readFileSync('.env.example','utf8');assert.ok(!/sk-[a-zA-Z0-9]{15,}/.test(s))});
test('subscription code uniqueness declared',()=>{const s=readFileSync('prisma/schema.prisma','utf8');assert.match(s,/codeHash String @unique/)});
