import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('admin page restricts server-side access',()=>{const s=read('src/app/admin/page.tsx');assert.match(s,/currentUser\(/);assert.match(s,/user\.role\s*!==\s*['"]SUPER_ADMIN['"]/);});
test('staff page filters assignments by authenticated staff id',()=>{const s=read('src/app/staff/page.tsx');assert.match(s,/user\.role!==['"]FOLLOW_UP['"]/);assert.match(s,/staffId:staff\.id,endedAt:null/);});
test('code issuer posts to protected server endpoint',()=>{const s=read('src/app/admin/code-issuer.tsx');assert.match(s,/fetch\('\/api\/admin\/codes'/);assert.match(read('src/app/api/admin/codes/route.ts'),/requireRole\(\['SUPER_ADMIN'\]\)/);});
