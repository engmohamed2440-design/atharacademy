import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=(path)=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');
test('home page uses real navigation and a feature section',()=>{const page=read('src/app/page.tsx');assert.match(page,/href="\/activate"/);assert.match(page,/href="\/login"/);assert.match(page,/id="features"/);assert.match(page,/href=\{feature.href\}/);});
test('public site supports mobile layout and accessible focus',()=>{const css=read('src/app/style.css');assert.match(css,/@media\(max-width:800px\)/);assert.match(css,/:focus-visible/);assert.match(css,/prefers-reduced-motion/);});
test('activation provides visible error and navigation to login',()=>{const page=read('src/app/activate/page.tsx');assert.match(page,/message&&/);assert.match(page,/href="\/login"/);assert.match(page,/role="alert"/);});
