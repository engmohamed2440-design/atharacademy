import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const component=readFileSync('src/app/ai/answer-format.tsx','utf8');
const page=readFileSync('src/app/ai/page.tsx','utf8');
test('assistant replies use the dedicated safe formatter',()=>{assert.match(page,/import AnswerFormat/);assert.match(page,/<AnswerFormat content=\{m.content\}/);});
test('formatter handles headings, lists and fenced code as React text',()=>{assert.match(component,/athar-ai-answer-heading/);assert.match(component,/athar-ai-answer-list/);assert.match(component,/athar-ai-code-wrap/);assert.doesNotMatch(component,/dangerouslySetInnerHTML|innerHTML/);});
