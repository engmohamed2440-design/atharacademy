import { test } from 'node:test';
import { strict as assert } from 'node:assert';
import { readFileSync } from 'node:fs';
const guard = readFileSync(new URL('../src/lib/guard.ts', import.meta.url),'utf8');
const login = readFileSync(new URL('../src/app/api/login/route.ts', import.meta.url),'utf8');
const activation = readFileSync(new URL('../src/app/api/activate/route.ts', import.meta.url),'utf8');
test('subscription access requires active subscription and active activation code',()=>{
 assert.match(guard,/status:'ACTIVE',startsAt:\{lte:now\},endsAt:\{gt:now\},code:\{status:'ACTIVE'\}/);
});
test('student eligibility is checked server-side',()=>{
 assert.match(guard,/currentUser\(\)/);
 assert.match(guard,/db\.subscriptions\.findFirst/);
});
test('login email is normalized consistently with activation',()=>{
 assert.match(login,/toLowerCase\(\)/);
 assert.match(activation,/email\.toLowerCase\(\)/);
});
test('login request bounds email and password sizes',()=>{
 assert.match(login,/max\(254\)/);
 assert.match(login,/max\(256\)/);
});
