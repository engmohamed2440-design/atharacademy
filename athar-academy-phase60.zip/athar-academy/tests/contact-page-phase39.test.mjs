import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../src/app/',import.meta.url);
const read=p=>readFileSync(new URL(p,root),'utf8');
test('contact page requires admin and reads stored settings',()=>{const s=read('admin/contact/page.tsx');assert.match(s,/SUPER_ADMIN/);assert.match(s,/platformSetting\.findMany/);});
test('contact editor saves via authorized settings endpoint and shows feedback',()=>{const s=read('admin/contact/contact-editor.tsx');assert.match(s,/api\/admin\/contact-settings/);assert.match(s,/method:'PUT'/);assert.match(s,/role="alert"/);assert.match(s,/disabled=\{busy\}/);});
test('homepage renders only configured public contact links safely',()=>{const s=read('page.tsx');assert.match(s,/platformSetting\.findMany/);assert.match(s,/noopener noreferrer/);assert.match(s,/settings\.whatsappUrl/);});
