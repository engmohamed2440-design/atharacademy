import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { csvCell, csvDocument } from '../src/lib/csv.ts';
const route = readFileSync('src/app/api/admin/exports/students/route.ts', 'utf8');
test('CSV quotes embedded commas and quotes', () => assert.equal(csvCell('A,"B"'), '"A,""B"""'));
test('CSV neutralizes spreadsheet formula payloads', () => {
 for (const input of ['=1+1', '+SUM(A1)', '-3+4', '@SUM(1)', '\t=cmd', '\n+1']) {
  assert.equal(csvCell(input), `"'${input}"`);
 }
});
test('CSV uses BOM and CRLF for Excel compatibility', () => assert.equal(csvDocument([['a','b']]), '\uFEFF"a","b"\r\n'));
test('student export restricted to super admin and audited', () => {
 assert.match(route, /requireRole\(\['SUPER_ADMIN'\]\)/);
 assert.match(route, /EXPORT_STUDENTS_CSV/);
 assert.match(route, /Cache-Control.*no-store/);
});
test('student export excludes phone, guardian and internal notes', () => {
 assert.doesNotMatch(route, /select:\s*\{\s*phone:/);
 assert.doesNotMatch(route, /guardianPhone:\s*true|passwordHash:\s*true|notes:\s*true/);
 assert.match(route, /const limit = 500/);
});
