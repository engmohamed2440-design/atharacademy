import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { generateBaseline } from '../scripts/create-baseline.mjs';

function fixture(fn) {
  const dir = mkdtempSync(join(tmpdir(), 'athar-baseline-'));
  try {
    mkdirSync(join(dir, 'node_modules/prisma/build'), {recursive:true});
    mkdirSync(join(dir, 'prisma'), {recursive:true});
    writeFileSync(join(dir, 'node_modules/prisma/build/index.js'), '');
    writeFileSync(join(dir, 'prisma/schema.prisma'), '');
    return fn(dir, join(dir, 'prisma/migrations/202610310000_initial_baseline/migration.sql'));
  } finally { rmSync(dir, {recursive:true,force:true}); }
}
test('baseline is generated from Prisma stdout without a shell', () => fixture((cwd,destination) => {
  let called;
  const runner = (exe,args,opts) => { called={exe,args,opts}; return {status:0,stdout:'CREATE TABLE "User" ("id" TEXT PRIMARY KEY);',stderr:''}; };
  assert.equal(generateBaseline({cwd,destination,runner}),destination);
  assert.match(readFileSync(destination,'utf8'),/CREATE TABLE/);
  assert.equal(called.exe,process.execPath);
  assert.deepEqual(called.args.slice(1,4),['migrate','diff','--from-empty']);
}));
test('baseline generation never overwrites existing migration', () => fixture((cwd,destination) => {
  mkdirSync(join(cwd,'prisma/migrations/202610310000_initial_baseline'),{recursive:true});
  writeFileSync(destination,'existing');
  assert.throws(()=>generateBaseline({cwd,destination,runner:()=>{throw Error('should not run')}}),/already exists/);
  assert.equal(readFileSync(destination,'utf8'),'existing');
}));
test('baseline generation rejects failed and empty Prisma output', () => fixture((cwd,destination) => {
  assert.throws(()=>generateBaseline({cwd,destination,runner:()=>({status:1,stderr:'bad schema'})}),/bad schema/);
  assert.throws(()=>generateBaseline({cwd,destination,runner:()=>({status:0,stdout:'-- Empty'})}),/unexpected baseline/);
  assert.equal(existsSync(destination),false);
}));
