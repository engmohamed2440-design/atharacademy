import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(p, import.meta.url), 'utf8');
test('staff detail page requires current active staff and live assignment', () => {
 const src=read('../src/app/staff/students/[id]/page.tsx');
 assert.match(src, /user\.role !== 'FOLLOW_UP' \|\| !user\.active/);
 assert.match(src, /staffId: staff\.id, endedAt: null/);
 assert.match(src, /if \(!assignment\) notFound\(\)/);
});
test('staff UI connects real task and followup endpoints', () => {
 const src=read('../src/app/staff/students/[id]/followup-editor.tsx');
 assert.match(src, /\/api\/students\/\$\{encodeURIComponent\(studentId\)\}\/tasks/);
 assert.match(src, /\/api\/students\/\$\{encodeURIComponent\(studentId\)\}\/followup/);
 assert.match(src, /disabled=\{busy\}/);
});
test('staff list links to individual student details', () => {
 assert.match(read('../src/app/staff/page.tsx'), /href=\{`\/staff\/students\/\$\{a\.student\.id\}`\}/);
});
