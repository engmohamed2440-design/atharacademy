import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../src/', import.meta.url);
const read = p => readFileSync(new URL(p, root), 'utf8');
test('AI quota is enforced inside a transaction using a per-student advisory lock', () => {
  const s = read('lib/ai-quota.ts');
  assert.match(s, /db\.\$transaction\(/);
  assert.match(s, /pg_advisory_xact_lock/);
  assert.match(s, /ai-daily:\$\{studentId\}/);
  assert.match(s, /used >= maxPerDay/);
});
test('AI reservation checks conversation ownership and creates message within same transaction', () => {
  const s = read('lib/ai-quota.ts');
  assert.match(s, /tx\.aIConversation\.findFirst\(/);
  assert.match(s, /id: conversationId, studentId/);
  assert.match(s, /tx\.aIMessage\.create\(/);
});
test('message route reserves quota before provider call and maps exhausted quota to 429', () => {
  const s = read('app/api/ai/conversations/[id]/messages/route.ts');
  assert.ok(s.indexOf('await reserveAIMessage(') < s.indexOf('await answerWithFallback('));
  assert.match(s, /code==='AI_DAILY_LIMIT'.*status:429/);
});
