import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8');
test('knowledge rows require approval before retrieval',()=>{assert.match(read('../src/lib/knowledge.ts'),/approved:true/);});
test('knowledge management is restricted to super admin',()=>{assert.match(read('../src/app/api/admin/knowledge/route.ts'),/requireRole\(\['SUPER_ADMIN'\]\)/);});
test('knowledge excerpts have bounded prompt size',()=>{assert.match(read('../src/lib/knowledge.ts'),/slice\(0,1800\)/);});
