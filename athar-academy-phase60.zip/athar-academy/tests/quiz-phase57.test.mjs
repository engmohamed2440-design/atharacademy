import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const quiz=readFileSync(new URL('src/lib/quiz.ts',root),'utf8');
const page=readFileSync(new URL('src/app/quizzes/page.tsx',root),'utf8');
test('AI quiz rejects repeated options and repeated question prompts',()=>{assert.match(quiz,/new Set\(q\.options\.map/);assert.match(quiz,/new Set\(normalizedPrompts\)/);});
test('student can search and filter quiz history',()=>{assert.match(page,/quiz-history-search/);assert.match(page,/quiz-history-filter/);assert.match(page,/filteredHistory\.map/);});
test('quiz dashboard shows real completed count and average',()=>{assert.match(page,/completedHistory\.length/);assert.match(page,/averageScore/);});
