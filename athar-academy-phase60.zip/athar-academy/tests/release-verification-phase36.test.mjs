import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'..');
const script=readFileSync(resolve(root,'scripts/verify-release.mjs'),'utf8');
test('release verification is available from npm',()=>{
 const pkg=JSON.parse(readFileSync(resolve(root,'package.json'),'utf8'));
 assert.equal(pkg.scripts['verify:release'],'node scripts/verify-release.mjs');
});
test('release verification stops after failed gate and never claims production readiness',()=>{
 assert.match(script,/if\(!passed\).*break/);
 assert.match(script,/productionReady:false/);
 assert.match(script,/Run integration and browser tests/);
});
test('release verification checks dependencies, tests, prisma, and build',()=>{
 for(const gate of ['scripts/doctor.mjs','npm','validate','build'])assert.ok(script.includes(gate));
});
