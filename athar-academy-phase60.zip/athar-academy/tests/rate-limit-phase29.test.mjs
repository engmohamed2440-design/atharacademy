import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { rateLimitIdentity, advisoryLockId } from '../src/lib/rate-limit-key.ts';
const secret = 's'.repeat(40);
test('account identity normalizes case and whitespace without leaking email', () => {
 const a = rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:' STUDENT@EXAMPLE.COM ',secret});
 const b = rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'student@example.com',secret});
 assert.equal(a.subjectKey,b.subjectKey);
 assert.equal(a.subjectKey.includes('student'),false);
 assert.equal(a.ipKey,null);
});
test('activation and login keys are separated',()=>{
 const a=rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'abc',secret});
 const b=rateLimitIdentity({action:'ACTIVATION_ATTEMPT',subject:'abc',secret});
 assert.notEqual(a.subjectKey,b.subjectKey);
});
test('trusted IP creates an additional independently keyed limit',()=>{
 const a=rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'a@b.com',ip:'192.0.2.1',secret});
 const b=rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'c@d.com',ip:'192.0.2.1',secret});
 assert.equal(a.ipKey,b.ipKey);assert.notEqual(a.subjectKey,b.subjectKey);
});
test('bad configuration and invalid inputs fail closed',()=>{
 assert.throws(()=>rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'x',secret:'short'}));
 assert.throws(()=>rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'  ',secret}));
 assert.throws(()=>advisoryLockId('bad'));
});
test('advisory lock is deterministic and within signed 64-bit range',()=>{
 const key=rateLimitIdentity({action:'LOGIN_ATTEMPT',subject:'abc',secret}).subjectKey;
 const n=advisoryLockId(key);
 assert.equal(n,advisoryLockId(key));assert.ok(n>=-(2n**63n)&&n<2n**63n);
});
test('both entrypoints enforce keyed throttling and DB transaction locks',()=>{
 const root=new URL('../src/',import.meta.url);
 const login=readFileSync(new URL('app/api/login/route.ts',root),'utf8');
 const activate=readFileSync(new URL('app/api/activate/route.ts',root),'utf8');
 const limiter=readFileSync(new URL('lib/rate-limit.ts',root),'utf8');
 assert.match(login,/checkRateLimit\(req, 'LOGIN_ATTEMPT', email\)/);
 assert.match(activate,/checkRateLimit\(req, 'ACTIVATION_ATTEMPT', code, 5\)/);
 assert.match(limiter,/\$transaction/);assert.match(limiter,/pg_advisory_xact_lock/);
});
