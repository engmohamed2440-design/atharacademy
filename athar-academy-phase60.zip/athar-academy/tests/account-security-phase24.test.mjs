import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../src/app/',import.meta.url);
const read=p=>readFileSync(new URL(p,root),'utf8');
test('password update requires origin and authenticated active session',()=>{
 const route=read('api/account/password/route.ts');
 assert.match(route,/verifyOrigin\(req\)/);
 assert.match(route,/currentUser\(\)/);
 assert.match(route,/bcrypt\.compare\(currentPassword,user\.passwordHash\)/);
});
test('password change invalidates other sessions and rotates current session',()=>{
 const route=read('api/account/password/route.ts');
 assert.match(route,/updateMany\(\{where:\{id:user\.id,passwordHash:user\.passwordHash,active:true\}/);
 assert.match(route,/session\.deleteMany\(\{where:\{userId:user\.id\}\}\)/);
 assert.match(route,/createSession\(user\.id\)/);
 assert.match(route,/PASSWORD_CHANGED/);
});
test('account settings requires login and checks confirmation in browser',()=>{
 assert.match(read('account/page.tsx'),/if\(!user\)redirect\('\/login'\)/);
 assert.match(read('account/password-form.tsx'),/newPassword!==confirm/);
});
