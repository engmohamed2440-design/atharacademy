import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('staff creation checks admin role and origin',()=>{const s=read('src/app/api/admin/staff/route.ts');assert.match(s,/verifyOrigin\(req\)/);assert.match(s,/requireRole\(\['SUPER_ADMIN'\]\)/);assert.match(s,/bcrypt\.hash/)});
test('staff creation audit and transaction',()=>{const s=read('src/app/api/admin/staff/route.ts');assert.match(s,/\$transaction/);assert.match(s,/STAFF_CREATED/)});
test('student list restricts admin and paginates',()=>{const s=read('src/app/api/admin/students/route.ts');assert.match(s,/requireRole\(\['SUPER_ADMIN'\]\)/);assert.match(s,/take:30/);assert.match(s,/skip:/)});
test('team page checks role on server',()=>{const s=read('src/app/admin/team/page.tsx');assert.match(s,/role!=='SUPER_ADMIN'/)});
test('assignment endpoint maintains audit and closes old assignments',()=>{const s=read('src/app/api/admin/assignments/route.ts');assert.match(s,/updateMany/);assert.match(s,/STUDENT_ASSIGNED/)});
