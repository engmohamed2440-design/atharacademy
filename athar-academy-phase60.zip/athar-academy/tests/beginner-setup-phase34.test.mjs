import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'..');
const read=p=>readFileSync(resolve(root,p),'utf8');
test('Windows launcher starts wizard from project root',()=>{
  const bat=read('START-HERE-WINDOWS.bat');
  assert.match(bat,/cd \/d "%~dp0"/);
  assert.match(bat,/node scripts\\beginner-wizard\.mjs/);
});
test('wizard requires confirmation before applying migrations',()=>{
  const script=read('scripts/beginner-wizard.mjs');
  assert.match(script,/if \(await confirm\([^\n]+\)\) run\(npm, \['run', 'db:migrate'\]\)/);
  assert.match(script,/existsSync\(resolve\(root, '\.env'\)\)/);
});
test('beginner instructions and easy command are available',()=>{
  assert.ok(existsSync(resolve(root,'START-HERE-AR.md')));
  assert.equal(JSON.parse(read('package.json')).scripts.easy,'node scripts/beginner-wizard.mjs');
});
