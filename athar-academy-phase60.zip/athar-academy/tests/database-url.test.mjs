import test from 'node:test';
import assert from 'node:assert/strict';
import { inspectDatabaseUrl } from '../scripts/check-database-url.mjs';
const base = 'postgresql://student:secret@ep-test.eu-central-1.aws.neon.tech/athar?sslmode=require';
test('accepts a complete encrypted hosted URL without leaking secrets', () => {
 const result = inspectDatabaseUrl(base, { production: true });
 assert.equal(result.ok, true);
 assert.equal(JSON.stringify(result).includes('secret'), false);
});
test('rejects missing or malformed credentials', () => {
 for (const url of ['', 'not-a-url', 'postgresql://student@host/db', 'https://user:pass@host/db']) assert.equal(inspectDatabaseUrl(url).ok, false);
});
test('requires TLS for hosted production database', () => {
 assert.equal(inspectDatabaseUrl(base.replace('?sslmode=require',''), { production: true }).ok, false);
 assert.equal(inspectDatabaseUrl(base.replace('?sslmode=require','')).warnings.length > 0, true);
});
test('warns about Neon pooled migration connection', () => {
 const result = inspectDatabaseUrl(base.replace('ep-test.', 'ep-test-pooler.'));
 assert.match(result.warnings.join(' '), /direct/);
});
test('accepts local development postgres', () => {
 assert.equal(inspectDatabaseUrl('postgresql://athar:pass@localhost:5432/athar').ok, true);
});
