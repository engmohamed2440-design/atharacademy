import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const file=p=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('account exposes other-device logout control',()=>{
 assert.match(file('src/app/account/page.tsx'),/RevokeSessions/);
 assert.match(file('src/app/account/revoke-sessions.tsx'),/\/api\/sessions\/revoke-others/);
});
test('other-device logout gives user feedback and blocks repeated submission',()=>{
 const s=file('src/app/account/revoke-sessions.tsx');
 assert.match(s,/disabled=\{busy\}/);
 assert.match(s,/role=\{failed\?'alert':'status'\}/);
 assert.match(s,/window\.confirm/);
});
test('student export is linked only in administrator page',()=>{
 const s=file('src/app/admin/students/page.tsx');
 assert.match(s,/\/api\/admin\/exports\/students\?page=1/);
 assert.match(s,/SUPER_ADMIN/);
 assert.match(file('src/app/api/admin/exports/students/route.ts'),/requireRole\(\['SUPER_ADMIN'\]\)/);
});
