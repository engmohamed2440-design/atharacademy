import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root=new URL('../src/app/admin/',import.meta.url);
test('knowledge page restricts access to super admins',()=>{const s=readFileSync(new URL('knowledge/page.tsx',root),'utf8');assert.match(s,/SUPER_ADMIN/);assert.match(s,/redirect\('\/dashboard'\)/)});
test('new references default to unapproved',()=>{const s=readFileSync(new URL('knowledge/knowledge-manager.tsx',root),'utf8');assert.match(s,/approved:false/)});
test('approval actions use authenticated API route',()=>{const s=readFileSync(new URL('knowledge/knowledge-manager.tsx',root),'utf8');assert.match(s,/method:'PATCH'/);assert.match(s,/api\/admin\/knowledge/)});
