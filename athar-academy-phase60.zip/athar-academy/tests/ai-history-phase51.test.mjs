import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const route=readFileSync('src/app/api/ai/conversations/[id]/messages/route.ts','utf8');
const quota=readFileSync('src/lib/ai-quota.ts','utf8');
test('chat history fetches the most recent 100 messages, then displays them oldest to newest',()=>{
 assert.match(route,/orderBy:\[\{createdAt:'desc'\},\{id:'desc'\}\],take:100/);
 assert.match(route,/items:items\.reverse\(\)/);
});
test('AI conversation title and recency update when a student message is reserved, even if provider fails',()=>{
 assert.match(quota,/existingMessages === 1/);
 assert.match(quota,/title: content\.slice\(0, 55\)/);
 assert.match(quota,/updatedAt: new Date\(\)/);
});
test('student history remains bounded and requires subscription',()=>{
 assert.match(route,/requireActiveStudent\(\)/);
 assert.match(route,/take:100/);
});
