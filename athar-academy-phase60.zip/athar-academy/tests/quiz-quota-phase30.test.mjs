import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(p, import.meta.url), 'utf8');
const quota = read('../src/lib/quiz-quota.ts');
const route = read('../src/app/api/quizzes/route.ts');
test('quiz creation is guarded by a transaction-scoped advisory lock', () => {
  assert.match(quota, /\$transaction\(async tx/);
  assert.match(quota, /pg_advisory_xact_lock/);
  assert.match(quota, /tx\.quiz\.count/);
  assert.match(quota, /tx\.quiz\.create/);
});
test('quiz lock is scoped to the student and daily limit is enforced', () => {
  assert.match(quota, /quiz-daily:\$\{studentId\}/);
  assert.match(quota, /count >= maxPerDay/);
  assert.match(quota, /QUIZ_DAILY_LIMIT/);
});
test('quiz route uses atomic creation and returns HTTP 429 for quota conflicts', () => {
  assert.match(route, /createQuizWithinDailyQuota\(student\.id,parsed\.data,questions\)/);
  assert.match(route, /e\.message==='QUIZ_DAILY_LIMIT'/);
  assert.match(route, /status:429/);
});
