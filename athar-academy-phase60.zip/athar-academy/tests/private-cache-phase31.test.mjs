import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const configSource = readFileSync(new URL('../next.config.ts', import.meta.url), 'utf8');
const routes = [...configSource.matchAll(/'\/(?:[^']+)\:path\*'/g)].map(x => x[0]);
test('private API and dashboard routes are excluded from shared caches', () => {
  for (const route of ['/api/:path*','/dashboard/:path*','/admin/:path*','/staff/:path*','/account/:path*','/ai/:path*','/quizzes/:path*','/support/:path*']) {
    assert.ok(routes.includes(`'${route}'`), `Missing private route: ${route}`);
  }
});
test('private responses disallow caching and search indexing', () => {
  assert.match(configSource, /Cache-Control.*private, no-store, max-age=0/);
  assert.match(configSource, /X-Robots-Tag.*noindex, nofollow, noarchive/);
});
test('public landing page is not affected by private matcher', () => {
  assert.ok(!routes.includes("'/:path*'"));
});
