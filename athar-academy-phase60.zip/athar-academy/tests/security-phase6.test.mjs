import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const read = p => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('login and activation enforce persistent throttling', () => {
  for (const route of ['src/app/api/login/route.ts','src/app/api/activate/route.ts'])
    assert.match(read(route), /await checkRateLimit\(/);
  const limiter = read('src/lib/rate-limit.ts');
  assert.match(limiter, /(db|tx)\.auditLog\.count/);
  assert.match(read('src/lib/rate-limit-key.ts'), /createHmac\('sha256'/);
});
test('rate limiter does not trust proxy headers by default', () => {
  assert.match(read('.env.example'), /TRUST_PROXY_HEADERS="false"/);
});
test('revoke other sessions preserves current session', () => {
  const route = 'src/app/api/sessions/revoke-others/route.ts';
  assert.ok(existsSync(new URL('../' + route, import.meta.url)));
  assert.match(read(route), /tokenHash: \{ not: current \}/);
  assert.match(read(route), /verifyOrigin\(req\)/);
});
