import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const route=readFileSync(new URL('../src/app/api/admin/knowledge/[id]/route.ts',import.meta.url),'utf8');
const ui=readFileSync(new URL('../src/app/admin/knowledge/knowledge-manager.tsx',import.meta.url),'utf8');
test('knowledge mutations require admin authentication and origin verification',()=>{
 assert.match(route,/verifyOrigin\(req\)/);
 assert.equal((route.match(/requireRole\(\['SUPER_ADMIN'\]\)/g)||[]).length,3);
});
test('editing educational reference revokes approval and records audit',()=>{
 assert.match(route,/edit\.success\?\{\.\.\.edit\.data,approved:false\}/);
 assert.match(route,/KNOWLEDGE_EDITED/);
});
test('deletion is audited in same database transaction',()=>{
 assert.match(route,/export async function DELETE/);
 assert.match(route,/await tx\.knowledgeExcerpt\.delete/);
 assert.match(route,/KNOWLEDGE_DELETED/);
});
test('knowledge manager exposes real edit, delete, approval and paging controls',()=>{
 for(const term of ['startEdit(x)','remove(x)','toggle(x)','refresh(page+1)','refresh(page-1)'])assert.ok(ui.includes(term),term);
});
