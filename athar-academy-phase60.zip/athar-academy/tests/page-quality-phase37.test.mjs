import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {roleDestination} from '../src/lib/role-destination.mjs';
const read=(path)=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');
test('all known roles redirect to their own dashboards',()=>{
 assert.equal(roleDestination('SUPER_ADMIN'),'/admin');
 assert.equal(roleDestination('FOLLOW_UP'),'/staff');
 assert.equal(roleDestination('SUPPORT'),'/support');
 assert.equal(roleDestination('STUDENT'),'/dashboard');
});
test('unknown roles never receive an authenticated landing route',()=>{
 for(const role of ['',null,undefined,'ADMIN','student',{},'__proto__'])assert.equal(roleDestination(role),null);
});
test('login prevents repeated submits and handles transport failures',()=>{
 const src=read('src/app/login/page.tsx');
 assert.match(src,/if\(busy\)return/);assert.match(src,/disabled=\{busy\}/);
 assert.match(src,/catch\{setMessage\(/);assert.match(src,/roleDestination\(result.role\)/);
});
test('app has accessible error, missing-page and loading states',()=>{
 assert.match(read('src/app/error.tsx'),/reset\(\)/);
 assert.match(read('src/app/not-found.tsx'),/الصفحة غير موجودة/);
 assert.match(read('src/app/loading.tsx'),/role="status"/);
});
test('quiz result UI handles missing correction details safely',()=>{
 const src=read('src/app/quizzes/page.tsx');
 assert.doesNotMatch(src,/find\(d=>d.id===q.id\)!/);
 assert.match(src,/تفاصيل التصحيح غير متاحة/);
});
