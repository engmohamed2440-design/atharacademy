import {test} from 'node:test';import {readFileSync,existsSync} from 'node:fs';import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url);const read=p=>readFileSync(new URL(p,root),'utf8');
test('quiz schema contains unique attempt answer constraints',()=>{const s=read('prisma/schema.prisma');assert.match(s,/model QuizAttempt/);assert.match(s,/@@unique\(\[attemptId,questionId\]\)/)});
test('quiz GET does not expose answer keys',()=>{const s=read('src/app/api/quizzes/[id]/route.ts');assert.match(s,/select:\{id:true,prompt:true,type:true,options:true,position:true\}/);assert.doesNotMatch(s,/correctIndex/)});
test('submission uses a transaction and conditional update',()=>{const s=read('src/app/api/quizzes/[id]/submit/route.ts');assert.match(s,/\$transaction/);assert.match(s,/updateMany/)});
test('quiz page exists',()=>assert.ok(existsSync(new URL('src/app/quizzes/page.tsx',root))));
