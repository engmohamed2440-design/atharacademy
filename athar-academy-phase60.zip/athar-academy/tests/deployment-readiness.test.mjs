import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=(p)=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('database binds only to loopback in local compose',()=>assert.match(read('docker-compose.yml'),/127\.0\.0\.1:5432:5432/));
test('database password must be provided explicitly',()=>assert.match(read('docker-compose.yml'),/POSTGRES_PASSWORD:\?Set POSTGRES_PASSWORD/));
test('health endpoint performs database check',()=>assert.match(read('src/app/api/health/route.ts'),/\$queryRaw`SELECT 1`/));
test('health endpoint returns 503 on database failure',()=>assert.match(read('src/app/api/health/route.ts'),/status:503/));
test('security headers prevent framing',()=>assert.match(read('next.config.ts'),/X-Frame-Options/));
