import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const route=readFileSync(new URL('../src/app/api/admin/staff/[id]/route.ts',import.meta.url),'utf8');
const ui=readFileSync(new URL('../src/app/admin/team/team-client.tsx',import.meta.url),'utf8');
test('staff update is restricted to admin and verifies request origin',()=>{assert.match(route,/verifyOrigin\(req\)/);assert.match(route,/requireRole\(\['SUPER_ADMIN'\]\)/)});
test('staff update validates capacity and supports deactivation',()=>{assert.match(route,/\.min\(1\)\.max\(500\)/);assert.match(route,/input\.active/);assert.match(route,/session\.deleteMany/)});
test('staff updates are audited',()=>{assert.match(route,/STAFF_UPDATED/);assert.match(route,/auditLog\.create/)});
test('staff controls invoke update endpoint and expose labels',()=>{assert.match(ui,/api\/admin\/staff\/\$\{/);assert.match(ui,/aria-label=\{`سعة/);assert.match(ui,/تفعيل الحساب/)});
