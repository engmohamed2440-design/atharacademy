import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const page=readFileSync(new URL('../src/app/ai/page.tsx',import.meta.url),'utf8');
const styles=readFileSync(new URL('../src/app/style.css',import.meta.url),'utf8');
test('chat keeps per-conversation drafts',()=>{assert.match(page,/draftsRef=useRef/);assert.match(page,/draftsRef\.current\[activeRef\.current\]=input/);assert.match(page,/setInput\(draftsRef\.current\[id\]/);});
test('chat scroll respects reading position',()=>{assert.match(page,/if\(atBottom\)/);assert.match(page,/setAtBottom\(!far\)/);});
test('student can reuse a question',()=>{assert.match(page,/إعادة استخدام السؤال/);assert.match(page,/setInput\(m\.content\)/);});
test('mobile conversation menu uses accessible backdrop',()=>{assert.match(page,/athar-ai-scrim/);assert.match(styles,/\.athar-ai-scrim\{display:block/);});
