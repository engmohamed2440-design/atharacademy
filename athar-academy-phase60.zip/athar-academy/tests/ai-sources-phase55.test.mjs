import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const ui=readFileSync(new URL('../src/app/ai/page.tsx',import.meta.url),'utf8');
const api=readFileSync(new URL('../src/app/api/ai/conversations/[id]/messages/route.ts',import.meta.url),'utf8');
test('assistant renders titles from returned educational source metadata',()=>{assert.match(ui,/مراجع تعليمية مرتبطة بالسؤال/);assert.match(ui,/source\.title/);assert.match(ui,/Array\.isArray\(data\.sources\)/);});
test('server returns only source id and title, not private excerpt content',()=>{assert.match(api,/sources:sources\.map\(s=>\(\{id:s\.id,title:s\.title\}\)\)/);});
