import test from 'node:test';
import assert from 'node:assert/strict';
import {validateQuizQuestions} from '../src/lib/quiz-validation.mjs';
const mc = (prompt='ما نتيجة جمع اثنين واثنين؟') => ({prompt,type:'MULTIPLE_CHOICE',options:['3','4','5','6'],correctIndex:1});
const tf = (prompt='الأرض تدور حول الشمس') => ({prompt,type:'TRUE_FALSE',options:['صح','خطأ'],correctIndex:0});
test('accepts valid Arabic multiple choice and true/false questions',()=>assert.equal(validateQuizQuestions([mc(),tf()],2),true));
test('rejects duplicate questions after whitespace normalization',()=>assert.equal(validateQuizQuestions([mc(),mc('  ما نتيجة جمع اثنين   واثنين؟  ')],2),false));
test('rejects multiple choice questions with fewer than four choices',()=>assert.equal(validateQuizQuestions([{...mc(),options:['1','2']}],1),false));
test('rejects true/false questions with unrelated options',()=>assert.equal(validateQuizQuestions([{...tf(),options:['نعم','لا']}],1),false));
test('accepts true/false English labels in either order',()=>assert.equal(validateQuizQuestions([{...tf(),options:['false','true'],correctIndex:1}],1),true));
test('rejects out-of-range correct answer and repeated options',()=>{
 assert.equal(validateQuizQuestions([{...mc(),correctIndex:4}],1),false);
 assert.equal(validateQuizQuestions([{...mc(),options:['1','2','2 ','4']}],1),false);
});
