import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const read = p => readFileSync(new URL(p, root), 'utf8');
test('AI deletion requires same-origin and active student', () => {
 const route=read('src/app/api/ai/conversations/[id]/route.ts');
 assert.match(route,/verifyOrigin\(req\)/);
 assert.match(route,/requireActiveStudent\(\)/);
});
test('AI deletion scopes database mutation to authenticated student', () => {
 const route=read('src/app/api/ai/conversations/[id]/route.ts');
 assert.match(route,/deleteMany\(\{\s*where:\s*\{\s*id,\s*studentId:\s*student\.id\s*\}/);
 assert.match(route,/status:\s*404/);
});
test('AI messages cascade when conversation is deleted', () => {
 assert.match(read('prisma/schema.prisma'),/conversation AIConversation @relation\(fields:\[conversationId\],references:\[id\],onDelete:Cascade\)/);
});
test('AI UI supports confirmed deletion and clears selected messages', () => {
 const ui=read('src/app/ai/page.tsx');
 assert.match(ui,/window\.confirm/);
 assert.match(ui,/method:'DELETE'/);
 assert.match(ui,/setMessages\(\[\]\)/);
});
