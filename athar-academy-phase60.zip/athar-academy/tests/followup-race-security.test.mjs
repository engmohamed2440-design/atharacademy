import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(p, 'utf8');
test('follow-up write rechecks assignment inside transaction', () => {
 const s = read('src/app/api/students/[id]/followup/route.ts');
 assert.match(s, /tx\.studentStaffAssignment\.findFirst/);
 assert.match(s, /if\(!assigned\)throw new Error\('FORBIDDEN'\)/);
 assert.ok(s.indexOf('tx.studentStaffAssignment.findFirst') < s.indexOf('tx.followUpAssessment.create'));
});
test('follow-up writes use same student advisory lock as reassignment', () => {
 const a=read('src/app/api/admin/assignments/route.ts');
 const b=read('src/app/api/students/[id]/followup/route.ts');
 assert.match(a, /pg_advisory_xact_lock\(hashtextextended\(\$\{studentId\}, 0\)\)/);
 assert.match(b, /pg_advisory_xact_lock\(hashtextextended\(\$\{id\}, 0\)\)/);
});
