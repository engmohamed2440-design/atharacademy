import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('quiz listing never selects answer keys',()=>{const s=read('src/app/api/quizzes/[id]/route.ts');assert.match(s,/select:\{id:true,prompt:true,type:true,options:true,position:true\}/);assert.doesNotMatch(s,/correctIndex:true/)});
test('result requires a submitted attempt belonging to current student',()=>{const s=read('src/app/api/quizzes/[id]/result/route.ts');assert.match(s,/requireActiveStudent/);assert.match(s,/studentId:student.id/);assert.match(s,/submittedAt:\{not:null\}/)});
test('submission rejects duplicate and foreign question IDs',()=>{const s=read('src/app/api/quizzes/[id]/submit/route.ts');assert.match(s,/validateQuizSubmission\(questions,parsed.data.answers\)/);assert.match(read('src/lib/quiz-submission-validation.mjs'),/byId.has\(answer.questionId\)/)});
test('quiz UI can recover submitted results',()=>{assert.match(read('src/app/quizzes/page.tsx'),/\/result/)});
