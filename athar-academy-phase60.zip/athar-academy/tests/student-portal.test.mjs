import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('student dashboard obtains tasks, notifications and tickets from database',()=>{const s=read('src/app/dashboard/page.tsx');for(const part of ['db.notification.findMany','db.supportTicket.findMany','db.studentStaffAssignment.findFirst','db.studentFeedback.findUnique'])assert.ok(s.includes(part))});
test('student actions call protected server APIs',()=>{const s=read('src/app/dashboard/student-tools.tsx');for(const part of ['/api/tasks/','/api/notifications','/api/support','/api/feedback'])assert.ok(s.includes(part))});
test('ticket page checks ownership before showing replies',()=>{const s=read('src/app/support/[id]/page.tsx');assert.ok(s.includes('student?.id!==ticket.studentId'));assert.ok(s.includes('notFound()'))});
test('support team has a protected ticket inbox',()=>{const s=read('src/app/support/page.tsx');assert.ok(s.includes("['SUPPORT','SUPER_ADMIN']"));assert.ok(s.includes('db.supportTicket.findMany'))});
