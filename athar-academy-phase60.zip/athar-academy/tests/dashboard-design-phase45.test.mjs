import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8');
test('shared dashboard navigation uses semantic links with descriptions',()=>{
 const src=read('../src/components/dashboard-nav.tsx');
 assert.match(src,/<nav className="dashboard-nav" aria-label=/);
 assert.match(src,/items\.map\(/);
 assert.match(src,/<Link key=\{item.href\}/);
 assert.match(src,/item\.description/);
});
test('admin navigation exposes all key operational sections',()=>{
 const src=read('../src/app/admin/page.tsx');
 for(const href of ['/admin/students','/admin/team','/admin/knowledge','/admin/contact','/admin/audit','/account']) assert.ok(src.includes(href),href);
});
test('student navigation exposes AI quizzes and account security',()=>{
 const src=read('../src/app/dashboard/page.tsx');
 for(const href of ['/ai','/quizzes','/account']) assert.ok(src.includes("href:'"+href+"'"),href);
});
test('dashboard navigation supports responsive layout, focus and reduced motion',()=>{
 const css=read('../src/app/style.css');
 for(const rule of ['.dashboard-nav-grid','.dashboard-nav-link:focus-visible','prefers-reduced-motion:reduce','@media(max-width:600px)']) assert.ok(css.includes(rule),rule);
});
