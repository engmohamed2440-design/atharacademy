import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../src/app/',import.meta.url);
const read=p=>readFileSync(new URL(p,root),'utf8');
test('admin student directory requires authenticated super admin',()=>{const s=read('admin/students/page.tsx');assert.match(s,/currentUser\(\)/);assert.match(s,/SUPER_ADMIN/);assert.match(s,/take:31/);assert.match(s,/encodeURIComponent\(q\)/)});
test('student details are scoped to requested profile and protected',()=>{const s=read('admin/students/[id]/page.tsx');assert.match(s,/SUPER_ADMIN/);assert.match(s,/findUnique\(\{where:\{id\}/);assert.match(s,/notFound\(\)/);assert.doesNotMatch(s,/passwordHash|guardianPhone/)});
test('admin dashboard links to student directory',()=>assert.match(read('admin/page.tsx'),/href="\/admin\/students"/));
