import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
for(const name of ['StudentFeedback','Notification','SupportTicket','SupportReply'])test('model '+name,()=>assert.match(read('prisma/schema.prisma'),new RegExp('model '+name+' \{')));
for(const path of ['feedback','notifications','support','support/[id]/replies','admin/contact-settings'])test('route '+path,()=>assert.match(read('src/app/api/'+path+'/route.ts'),/requireRole/));
test('feedback bound to current assignment',()=>assert.match(read('src/app/api/feedback/route.ts'),/endedAt:null/));
test('notification ownership',()=>assert.match(read('src/app/api/notifications/route.ts'),/id,userId:user.id/));
test('ticket ownership',()=>assert.match(read('src/app/api/support/[id]/replies/route.ts'),/ticket.studentId!==student.id/));
