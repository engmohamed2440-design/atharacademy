import type { NextConfig } from 'next';
const nextConfig: NextConfig = {
  poweredByHeader: false,
  async headers() {
    const privateHeaders = [
      {key:'Cache-Control',value:'private, no-store, max-age=0'},
      {key:'Pragma',value:'no-cache'},
      {key:'X-Robots-Tag',value:'noindex, nofollow, noarchive'},
    ];
    return [{source: '/:path*', headers: [
      {key:'X-Content-Type-Options',value:'nosniff'},
      {key:'Referrer-Policy',value:'strict-origin-when-cross-origin'},
      {key:'X-Frame-Options',value:'DENY'},
      {key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},
      {key:'Content-Security-Policy',value:"frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'"},
    ]}, ...['/api/:path*','/account/:path*','/admin/:path*','/dashboard/:path*','/staff/:path*','/support/:path*','/ai/:path*','/quizzes/:path*'].map(source=>({source,headers:privateHeaders}))];
  },
};
export default nextConfig;
